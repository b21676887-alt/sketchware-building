package pro.sketchware.widgets;

import android.app.Activity;
import android.app.AlertDialog;
import android.graphics.Color;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.widget.ImageView;
import android.widget.PopupWindow;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import pro.sketchware.beans.ColorBean;
import pro.sketchware.util.library.Material3LibraryManager;
import pro.sketchware.activities.editor.view.ColorGroupItem;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;

import java.util.ArrayList;
import java.util.HashMap;

import pro.sketchware.util.io.SharedPrefsHelper;
import pro.sketchware.util.DeviceUtil;
import pro.sketchware.util.SketchToast;
import pro.sketchware.core.project.ProjectDataManager;
import pro.sketchware.core.project.SketchwareConstants;
import pro.sketchware.core.project.SketchwarePaths;
import pro.sketchware.core.build.ProjectFilePaths;
import pro.sketchware.util.Helper;
import pro.sketchware.R;
import pro.sketchware.core.resources.ColorModel;
import pro.sketchware.core.resources.ColorResourceResolver;
import pro.sketchware.databinding.ColorPickerBinding;
import pro.sketchware.databinding.ColorPickerCustomAttrBinding;
import pro.sketchware.databinding.ColorPickerSimpleHexBinding;
import pro.sketchware.databinding.ItemAttrBinding;
import pro.sketchware.core.validation.ColorInputValidator;
import pro.sketchware.util.FileUtil;
import pro.sketchware.util.PropertiesUtil;
import pro.sketchware.util.SketchwareUtil;

public class ColorPickerDialog extends PopupWindow {

    private static String sc_id;
    private final ArrayList<ColorBean> colorList = new ArrayList<>();
    private final ArrayList<ColorBean[]> colorGroups = new ArrayList<>();
    private final ArrayList<ResColor> resColors = new ArrayList<>();
    private final ColorPickerBinding binding;
    private final ColorsAdapter colorsAdapter = new ColorsAdapter();
    private Activity activity;
    private ArrayList<Attribute> attributes;
    private OnColorPickedListener colorPickerCallback;
    private materialColorAttr materialColorAttr;
    private ColorInputValidator colorValidator;
    private int selectedGroupIndex;
    private int currentGroupIndex;
    private int selectedColorIndex = -1;
    private SharedPrefsHelper colorPref;
    private boolean hasMaterialColors;
    private Material3LibraryManager material3LibraryManager;
    private ProjectFilePaths projectFilePaths;
    private ColorResourceResolver colorResourceResolver;

    public ColorPickerDialog(Activity activity, int color, boolean isTransparentColor, boolean isNoneColor) {
        super(activity);
        binding = ColorPickerBinding.inflate(activity.getLayoutInflater());
        initialize(activity, getHexColor(color), isTransparentColor, isNoneColor);
    }

    public ColorPickerDialog(Activity activity, String color, boolean isTransparentColor, boolean isNoneColor, String scId) {
        super(activity);
        binding = ColorPickerBinding.inflate(activity.getLayoutInflater());
        sc_id = scId;
        projectFilePaths = new ProjectFilePaths(activity, sc_id);
        projectFilePaths.initializeMetadata(ProjectDataManager.getLibraryManager(sc_id), ProjectDataManager.getFileManager(sc_id), ProjectDataManager.getProjectDataManager(sc_id), pro.sketchware.core.build.ProjectFilePaths.ExportType.SOURCE_CODE_VIEWING);
        material3LibraryManager = new Material3LibraryManager(scId);
        colorResourceResolver = new ColorResourceResolver(scId);
        hasMaterialColors = true;
        initialize(activity, color, isTransparentColor, isNoneColor);
    }

    private String getHexColor(int color) {
        return String.format("#%06X", color);
    }

    private void deleteAllSavedColors() {
        MaterialAlertDialogBuilder dialog = new MaterialAlertDialogBuilder(activity);
        dialog.setIcon(R.drawable.delete_96);
        dialog.setTitle(R.string.picker_color_title_delete_all_custom_color);
        dialog.setMessage(R.string.picker_color_message_delete_all_custom_color);
        dialog.setPositiveButton(R.string.common_word_delete, (v, which) -> {
            colorPref.clearAll();
            colorGroups.set(0, getSavedColorBeans());
            notifyChanges();
            v.dismiss();
        });
        dialog.setNegativeButton(R.string.common_word_cancel, null);
        dialog.show();
    }

    public void setColorPickerCallback(OnColorPickedListener callback) {
        colorPickerCallback = callback;
    }

    public void materialColorAttr(materialColorAttr callback) {
        materialColorAttr = callback;
    }

    public void initialize(Activity activity, String color, boolean isTransparentColor, boolean isNoneColor) {
        this.activity = activity;
        colorPref = new SharedPrefsHelper(activity, "P24");
        initializeColorData(isTransparentColor, isNoneColor);
        initializeResColors();
        initializeAttrsList();

        if (color.equals("NONE")) {
            selectedGroupIndex = colorGroups.size() - 1;
            currentGroupIndex = selectedGroupIndex;
            selectedColorIndex = 0;
        }
        if (color.equals("TRANSPARENT")) {
            selectedGroupIndex = colorGroups.size() - 2;
            currentGroupIndex = selectedGroupIndex;
            selectedColorIndex = 0;
        } else if (color.startsWith("#")) {
            int colorInt = Color.parseColor(color);
            for (int groupIndex = 0; groupIndex < colorGroups.size(); ++groupIndex) {
                ColorBean[] colorBeans = colorGroups.get(groupIndex);

                for (int colorIndex = 0; colorIndex < colorBeans.length; ++colorIndex) {
                    if (colorBeans[colorIndex].colorCode == colorInt) {
                        selectedGroupIndex = groupIndex;
                        currentGroupIndex = groupIndex;
                        selectedColorIndex = colorIndex;
                        break;
                    }
                }
            }
        } else if (color.startsWith("@color/")) {
            selectedGroupIndex = 1;
            currentGroupIndex = 1;
            for (int i = 0; i < resColors.size(); i++) {
                ResColor resColor = resColors.get(i);
                if (("@color/" + resColor.colorName()).equals(color)) {
                    selectedColorIndex = i;
                    break;
                }
            }
            binding.colorList.setAdapter(new resColorsAdapter(resColors, selectedColorIndex));
            binding.colorList.post(() -> binding.colorList.scrollToPosition(selectedColorIndex));
        } else if (color.startsWith("?")) {
            selectedGroupIndex = 2;
            currentGroupIndex = 2;
            for (int i = 0; i < attributes.size(); i++) {
                Attribute attribute = attributes.get(i);
                if (("?" + attribute.name()).equals(color) || ("?attr/" + attribute.name()).equals(color)) {
                    selectedColorIndex = i;
                    break;
                }
            }
            binding.colorList.setAdapter(new AttrAdapter(attributes, selectedColorIndex));
            binding.colorList.post(() -> binding.colorList.scrollToPosition(selectedColorIndex));
        }
        super.setBackgroundDrawable(null);
        super.setAnimationStyle(android.R.style.Animation_Dialog);
        super.setFocusable(true);
        super.setOutsideTouchable(true);
        super.setContentView(binding.getRoot());
        int[] widthAndHeight = DeviceUtil.getScreenResolution(activity);
        super.setWidth(widthAndHeight[0]);
        super.setHeight(widthAndHeight[1]);
        binding.colorList.setHasFixedSize(true);
        binding.colorList.setLayoutManager(new LinearLayoutManager(activity.getApplicationContext()));
        if (binding.colorList.getAdapter() == null)
            binding.colorList.setAdapter(colorsAdapter);
        binding.colorList.setItemAnimator(new DefaultItemAnimator());

        binding.fab.setOnClickListener(view -> {
            if (sc_id != null && currentGroupIndex == 2) {
                showCustomAttrCreatorDialog();
            } else {
                showCustomColorCreatorDialog();
            }
        });

        binding.colorList.getAdapter().notifyItemChanged(selectedColorIndex);
        binding.layoutColorTitle.removeAllViews();

        for (int j = 0; j < colorList.size(); ++j) {
            ColorGroupItem colorGroupItem = new ColorGroupItem(activity);
            ColorBean colorBean = colorList.get(j);
            int finalJ = j;
            colorGroupItem.tvColorName.setOnClickListener(v -> {
                currentGroupIndex = finalJ;
                if (finalJ == 0 && colorGroups.get(finalJ).length == 0) {
                    SketchToast.warning(activity, Helper.getResString(R.string.picker_color_custom_color_not_found), 1).show();
                    return;
                }
                if (finalJ == 1 && colorGroups.get(finalJ).length == 0) {
                    SketchToast.warning(activity, Helper.getResString(R.string.picker_color_xml_is_empty), 1).show();
                    return;
                }
                if (sc_id != null && finalJ == 2 && !material3LibraryManager.isMaterial3Enabled()) {
                    SketchwareUtil.toastError(Helper.getResString(R.string.error_enable_material3));
                    return;
                }
                if (sc_id != null && finalJ == 1) {
                    binding.colorList.setAdapter(new resColorsAdapter(resColors, -1));
                } else if (sc_id != null && finalJ == 2) {
                    binding.colorList.setAdapter(new AttrAdapter(attributes, -1));
                } else {
                    binding.colorList.setAdapter(colorsAdapter);
                }
            });
            colorGroupItem.tvColorName.setText(colorBean.colorName);
            colorGroupItem.tvColorName.setTextColor(colorBean.displayNameColor);
            colorGroupItem.tvColorName.setBackgroundColor(colorBean.colorCode);
            binding.layoutColorTitle.addView(colorGroupItem);
            if (j == selectedGroupIndex) {
                colorGroupItem.imgColorSelector.setImageResource(colorBean.icon);
                colorGroupItem.imgColorSelector.setVisibility(View.VISIBLE);
            } else {
                colorGroupItem.imgColorSelector.setVisibility(View.GONE);
            }

            colorGroupItem.tvColorName.setOnLongClickListener(v -> {
                if (finalJ == 0) deleteAllSavedColors();
                return false;
            });
        }

        Animation animation = binding.getRoot().getAnimation();
        if (animation != null) {
            animation.setAnimationListener(new Animation.AnimationListener() {
                @Override
                public void onAnimationStart(Animation animation) {
                }

                @Override
                public void onAnimationEnd(Animation animation) {
                    smoothScrollToCurrentItem();
                }

                @Override
                public void onAnimationRepeat(Animation animation) {
                }
            });
        }

    }

    private void showCustomColorCreatorDialog() {
        ColorPickerSimpleHexBinding dialogBinding = ColorPickerSimpleHexBinding.inflate(activity.getLayoutInflater());
        colorValidator = new ColorInputValidator(activity, dialogBinding.tiCustomColor, dialogBinding.colorPreview);
        dialogBinding.etCustomColor.setPrivateImeOptions("defaultInputmode=english;");

        new MaterialAlertDialogBuilder(activity)
                .setTitle(Helper.getResString(R.string.save_to_collection))
                .setView(dialogBinding.getRoot())
                .setPositiveButton(Helper.getResString(R.string.common_word_save), (dialog, which) -> {
                    if (colorValidator.isValid()) {
                        String customColor = Helper.getText(dialogBinding.etCustomColor);
                        if (customColor.startsWith("#")) {
                            customColor = customColor.substring(1);
                        }
                        String formattedColor = String.format("#%8s", customColor).replace(" ", "F");
                        savePickedColor(formattedColor.toUpperCase());
                        notifyChanges();
                    }
                })
                .setNegativeButton(Helper.getResString(R.string.common_word_cancel), (dialog, which) -> dialog.dismiss())
                .show();
    }

    private void showCustomAttrCreatorDialog() {
        ColorPickerCustomAttrBinding dialogBinding = ColorPickerCustomAttrBinding.inflate(activity.getLayoutInflater());

        dialogBinding.input.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                String input = s.toString();
                String fullMaterialAttrPrefix = "com.google.android.material.R.attr.";
                String attrPrefix = "R.attr.";

                if (input.startsWith(fullMaterialAttrPrefix)) {
                    input = input.substring(fullMaterialAttrPrefix.length());
                } else if (input.startsWith(attrPrefix)) {
                    input = input.substring(attrPrefix.length());
                } else {
                    dialogBinding.inputLayout.setError(Helper.getResString(R.string.unknown_attr));
                    return;
                }

                Integer lightColorValue = colorResourceResolver.getColorIntFromAttrs(activity, input, 1, false);

                if (lightColorValue == null) {
                    dialogBinding.inputLayout.setError(Helper.getResString(R.string.unknown_attr));
                    return;
                }
                dialogBinding.inputLayout.setError(null);
                int lightColor = lightColorValue;
                Integer darkColorValue = colorResourceResolver.getColorIntFromAttrs(activity, input, 1, true);
                int darkColor = darkColorValue != null ? darkColorValue : lightColor;

                // viewBinding don't support include , so here we should use findViewById
                dialogBinding.getRoot().findViewById(R.id.dark_container).setBackgroundColor(darkColor);
                dialogBinding.getRoot().findViewById(R.id.light_container).setBackgroundColor(lightColor);
                ((TextView) dialogBinding.getRoot().findViewById(R.id.tvAttrName)).setText(input);
                ((TextView) dialogBinding.getRoot().findViewById(R.id.dark_ttl)).setTextColor(lightColor);
                ((TextView) dialogBinding.getRoot().findViewById(R.id.light_ttl)).setTextColor(darkColor);
            }

            @Override
            public void afterTextChanged(Editable s) {
            }
        });

        var dialog = new MaterialAlertDialogBuilder(activity)
                .setTitle(Helper.getResString(R.string.save_to_collection))
                .setView(dialogBinding.getRoot())
                .setPositiveButton(Helper.getResString(R.string.common_word_save), null)
                .setNegativeButton(Helper.getResString(R.string.common_word_cancel), null)
                .show();

        dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            if (dialogBinding.inputLayout.getError() == null && !dialogBinding.input.getText().toString().isEmpty()) {
                String attributeName = ((TextView) dialogBinding.getRoot().findViewById(R.id.tvAttrName)).getText().toString();

                if (isAttrExist(attributeName)) {
                    SketchwareUtil.toastError(Helper.getResString(R.string.attr_already_exist));
                    return;
                }

                String savedAttrs = colorPref.getStringDefault("P24I2");
                String attrsToSave = savedAttrs + "," + attributeName;
                colorPref.put("P24I2", (Object) attrsToSave);
                attributes.add(new Attribute(attributeName, savedAttrs.isEmpty() ? "Custom" : null));
                if (binding.colorList.getAdapter() != null) {
                    binding.colorList.getAdapter().notifyItemInserted(attributes.size());
                }
                binding.colorList.smoothScrollToPosition(attributes.size());
                dialog.dismiss();
            } else {
                SketchwareUtil.toastError(Helper.getResString(R.string.unknown_attr));
            }
        });
    }

    private boolean isAttrExist(String attr) {
        for (Attribute attribute : attributes) {
            if (attribute.name.equals(attr)) {
                return true;
            }
        }
        return false;
    }

    private void showColorRemoveDialog(String color) {
        MaterialAlertDialogBuilder dialog = new MaterialAlertDialogBuilder(activity);
        dialog.setIcon(R.drawable.delete_96);
        dialog.setTitle(R.string.picker_color_title_delete_custom_color);
        dialog.setMessage(R.string.picker_color_message_delete_custom_color);
        dialog.setPositiveButton(R.string.common_word_delete, (v, which) -> {
            removeSavedColor(color);
            notifyChanges();
            v.dismiss();
        });
        dialog.setNegativeButton(R.string.common_word_cancel, null);
        dialog.show();
    }

    private void initializeColorData(boolean isColorTransparent, boolean isColorNone) {
        colorList.add(new ColorBean("#FFF6F6F6", "CUSTOM", "#212121", R.drawable.checked_grey_32));
        if (sc_id != null)
            colorList.add(new ColorBean("#FFF6F6F6", "colors.xml", "#212121", R.drawable.checked_grey_32));
        if (hasMaterialColors)
            colorList.add(new ColorBean("#FFF6F6F6", "Material 3 Colors", "#212121", R.drawable.checked_grey_32));
        colorList.add(SketchwareConstants.COLOR_RED[0]);
        colorList.add(SketchwareConstants.COLOR_PINK[0]);
        colorList.add(SketchwareConstants.COLOR_PURPLE[0]);
        colorList.add(SketchwareConstants.COLOR_DEEP_PURPLE[0]);
        colorList.add(SketchwareConstants.COLOR_INDIGO[0]);
        colorList.add(SketchwareConstants.COLOR_BLUE[0]);
        colorList.add(SketchwareConstants.COLOR_LIGHT_BLUE[0]);
        colorList.add(SketchwareConstants.COLOR_CYAN[0]);
        colorList.add(SketchwareConstants.COLOR_TEAL[0]);
        colorList.add(SketchwareConstants.COLOR_GREEN[0]);
        colorList.add(SketchwareConstants.COLOR_LIGHT_GREEN[0]);
        colorList.add(SketchwareConstants.COLOR_LIME[0]);
        colorList.add(SketchwareConstants.COLOR_YELLOW[0]);
        colorList.add(SketchwareConstants.COLOR_AMBER[0]);
        colorList.add(SketchwareConstants.COLOR_ORANGE[0]);
        colorList.add(SketchwareConstants.COLOR_DEEP_ORANGE[0]);
        colorList.add(SketchwareConstants.COLOR_BROWN[0]);
        colorList.add(SketchwareConstants.COLOR_GREY[0]);
        colorList.add(SketchwareConstants.COLOR_BLUE_GREY[0]);
        colorList.add(SketchwareConstants.COLOR_BLACK[0]);
        colorList.add(SketchwareConstants.COLOR_WHITE[0]);
        colorGroups.add(getSavedColorBeans());
        if (sc_id != null)
            colorGroups.add(SketchwareConstants.COLOR_RED);
        if (hasMaterialColors)
            colorGroups.add(SketchwareConstants.COLOR_RED);
        colorGroups.add(SketchwareConstants.COLOR_RED);
        colorGroups.add(SketchwareConstants.COLOR_PINK);
        colorGroups.add(SketchwareConstants.COLOR_PURPLE);
        colorGroups.add(SketchwareConstants.COLOR_DEEP_PURPLE);
        colorGroups.add(SketchwareConstants.COLOR_INDIGO);
        colorGroups.add(SketchwareConstants.COLOR_BLUE);
        colorGroups.add(SketchwareConstants.COLOR_LIGHT_BLUE);
        colorGroups.add(SketchwareConstants.COLOR_CYAN);
        colorGroups.add(SketchwareConstants.COLOR_TEAL);
        colorGroups.add(SketchwareConstants.COLOR_GREEN);
        colorGroups.add(SketchwareConstants.COLOR_LIGHT_GREEN);
        colorGroups.add(SketchwareConstants.COLOR_LIME);
        colorGroups.add(SketchwareConstants.COLOR_YELLOW);
        colorGroups.add(SketchwareConstants.COLOR_AMBER);
        colorGroups.add(SketchwareConstants.COLOR_ORANGE);
        colorGroups.add(SketchwareConstants.COLOR_DEEP_ORANGE);
        colorGroups.add(SketchwareConstants.COLOR_BROWN);
        colorGroups.add(SketchwareConstants.COLOR_GREY);
        colorGroups.add(SketchwareConstants.COLOR_BLUE_GREY);
        colorGroups.add(SketchwareConstants.COLOR_BLACK);
        colorGroups.add(SketchwareConstants.COLOR_WHITE);
        if (isColorTransparent) {
            colorList.add(SketchwareConstants.COLOR_TRANSPARENT[0]);
            colorGroups.add(SketchwareConstants.COLOR_TRANSPARENT);
        }
        if (isColorNone) {
            colorList.add(SketchwareConstants.COLOR_NONE[0]);
            colorGroups.add(SketchwareConstants.COLOR_NONE);
        }
    }

    private void removeSavedColor(String color) {
        String savedColors = colorPref.getStringDefault("P24I1");
        if (savedColors.contains(color)) {
            String colorToRemove = color + ",";
            String colorToSave = savedColors.replaceAll(colorToRemove, "");
            colorPref.put("P24I1", (Object) colorToSave);
            colorGroups.set(0, getSavedColorBeans());
            notifyChanges();
        }
    }

    private ColorBean[] getSavedColorBeans() {
        String savedColors = colorPref.getStringDefault("P24I1");
        ColorBean[] colorBeansResult;
        if (!savedColors.isEmpty()) {
            String[] colorStrings = savedColors.split(",");
            ColorBean[] colorBeans = new ColorBean[colorStrings.length];
            int index = 0;
            while (index < colorStrings.length) {
                try {
                    int parsedColor = Color.parseColor(colorStrings[index]);
                    int red = Color.red(parsedColor);
                    int green = Color.green(parsedColor);
                    int blue = Color.blue(parsedColor);

                    int count = 0;
                    if (red > 240) count++;
                    if (green > 240) count++;
                    if (blue > 240) count++;


                    colorBeans[index] = new ColorBean(colorStrings[index], "CUSTOM",
                            count >= 2 ? "#212121" : "#ffffff",
                            R.drawable.checked_white_32);

                } catch (Exception e) {
                    colorPref.clearAll();
                    colorBeans = new ColorBean[0];
                    break;
                }
                index++;
            }
            colorBeansResult = colorBeans;
        } else {
            colorBeansResult = new ColorBean[0];
        }

        return colorBeansResult;
    }

    private void smoothScrollToCurrentItem() {
        if (selectedGroupIndex < binding.layoutColorTitle.getChildCount()) {
            View childView = binding.layoutColorTitle.getChildAt(selectedGroupIndex);
            binding.layoutHsvColor.smoothScrollTo((int) childView.getX(), 0);
            binding.colorList.scrollToPosition(selectedColorIndex);
        }
    }

    private void savePickedColor(String color) {
        String savedColors = colorPref.getStringDefault("P24I1");
        if (savedColors.contains(color)) {
            SketchToast.warning(activity, Helper.getResString(R.string.picker_color_already_exist), 0).show();
        } else {
            String colorsToSave = color + "," + savedColors;
            colorPref.put("P24I1", (Object) colorsToSave);
            colorGroups.set(0, getSavedColorBeans());
            notifyChanges();
            selectedGroupIndex = 0;
            smoothScrollToCurrentItem();
        }
    }

    private void notifyChanges() {
        currentGroupIndex = 0;
        selectedGroupIndex = 0;
        selectedColorIndex = 0;
        binding.colorList.getAdapter().notifyDataSetChanged();
    }

    public void initializeAttrsList() {
        if (!hasMaterialColors) return;
        attributes = new ArrayList<>();

        attributes.add(new Attribute("colorSurface", "Surface"));
        attributes.add(new Attribute("colorOnSurface"));
        attributes.add(new Attribute("colorSurfaceVariant"));
        attributes.add(new Attribute("colorOnSurfaceVariant"));
        attributes.add(new Attribute("colorSurfaceInverse"));
        attributes.add(new Attribute("colorOnSurfaceInverse"));

        attributes.add(new Attribute("colorPrimary", "Primary"));
        attributes.add(new Attribute("colorOnPrimary"));
        attributes.add(new Attribute("colorPrimaryContainer"));
        attributes.add(new Attribute("colorOnPrimaryContainer"));

        attributes.add(new Attribute("colorSecondary", "Secondary"));
        attributes.add(new Attribute("colorOnSecondary"));
        attributes.add(new Attribute("colorSecondaryContainer"));
        attributes.add(new Attribute("colorOnSecondaryContainer"));

        attributes.add(new Attribute("colorTertiary", "Tertiary"));
        attributes.add(new Attribute("colorOnTertiary"));
        attributes.add(new Attribute("colorTertiaryContainer"));
        attributes.add(new Attribute("colorOnTertiaryContainer"));

        attributes.add(new Attribute("colorError", "Error"));
        attributes.add(new Attribute("colorOnError"));
        attributes.add(new Attribute("colorErrorContainer"));
        attributes.add(new Attribute("colorOnErrorContainer"));

        String savedAttrs = colorPref.getStringDefault("P24I2");
        if (savedAttrs != null && !savedAttrs.isEmpty()) {
            String[] customAttrs = savedAttrs.split(",");
            for (int i = 0; i < customAttrs.length; i++) {
                String attr = customAttrs[i];
                if (attr.isEmpty()) continue;
                attributes.add(new Attribute(
                        attr,
                        i == 0 ? "Custom" : null));
            }
        }

    }

    private void initializeResColors() {
        if (sc_id == null || projectFilePaths == null)
            return;
        String fileNightPath = SketchwarePaths.getProjectResourceValuesFilePath(sc_id, "-night", "colors.xml");

        ArrayList<ColorModel> colorList = new ArrayList<>();
        ArrayList<ColorModel> colorNightList = new ArrayList<>();

        colorResourceResolver.parseColorsXML(colorList, projectFilePaths.getXMLColor());
        colorResourceResolver.parseColorsXML(colorNightList, FileUtil.readFileIfExist(fileNightPath));

        HashMap<String, String> nightColorsMap = new HashMap<>();
        for (ColorModel nightColorModel : colorNightList) {
            nightColorsMap.put(nightColorModel.getColorName(), nightColorModel.getColorValue());
        }

        for (ColorModel colorModel : colorList) {
            int color = PropertiesUtil.parseColor(colorResourceResolver.getColorValue(activity.getApplicationContext(), colorModel.getColorValue(), 3));
            int colorNight;
            if (nightColorsMap.containsKey(colorModel.getColorName())) {
                colorNight = PropertiesUtil.parseColor(colorResourceResolver.getColorValue(activity.getApplicationContext(), nightColorsMap.get(colorModel.getColorName()), 3, true));
            } else {
                colorNight = -1;
            }
            resColors.add(new ResColor(colorModel.getColorName(), color, colorNight));
        }
    }

    public interface OnColorPickedListener {
        void onColorPicked(int color);

        void onResourceColorPicked(String resourceName, int color);
    }

    public interface materialColorAttr {
        void selectedMaterialColorAttr(String attr, int attrColor);
    }

    public record Attribute(String name, String title) {

        public Attribute(String name) {
            this(name, null);
        }

        public boolean hasTitle() {
            return title != null;
        }

        public String attrTitle() {
            return title + " Colors :";
        }
    }

    public record ResColor(String colorName, int colorValue, int nightColorValue) {
    }

    private class ColorsAdapter extends RecyclerView.Adapter<ColorsAdapter.ColorViewHolder> {

        public ColorsAdapter() {
        }

        @Override
        public int getItemCount() {
            return colorGroups.get(currentGroupIndex).length;
        }

        @Override
        public void onBindViewHolder(ColorViewHolder holder, int position) {
            ColorBean colorBean = ((ColorBean[]) colorGroups.get(currentGroupIndex))[position];

            holder.tvColorCode.setText(colorBean.getColorCode(currentGroupIndex == 0));
            if (position == 0) {
                holder.tvColorName.setText(((ColorBean[]) colorGroups.get(currentGroupIndex))[0].colorName);
            } else {
                holder.tvColorName.setText("");
            }
            if (currentGroupIndex == 1 && sc_id != null) {
                holder.tvColorName.setText(((ColorBean[]) colorGroups.get(currentGroupIndex))[position].colorName);
            }

            holder.tvColorCode.setTextColor(((ColorBean[]) colorGroups.get(currentGroupIndex))[position].displayNameColor);
            holder.tvColorName.setTextColor(((ColorBean[]) colorGroups.get(currentGroupIndex))[position].displayNameColor);
            holder.layoutColorItem.setBackgroundColor(((ColorBean[]) colorGroups.get(currentGroupIndex))[position].colorCode);
            if (position == selectedColorIndex && currentGroupIndex == selectedGroupIndex) {
                holder.imgSelector.setImageResource(((ColorBean[]) colorGroups.get(currentGroupIndex))[position].icon);
                holder.imgSelector.setVisibility(View.VISIBLE);
            } else {
                holder.imgSelector.setVisibility(View.GONE);
            }

        }

        @Override
        @NonNull
        public ColorViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            return new ColorViewHolder(LayoutInflater.from(parent.getContext()).inflate(R.layout.color_picker_item, parent, false));
        }

        private class ColorViewHolder extends RecyclerView.ViewHolder {

            public View layoutColorItem;
            public TextView tvColorCode;
            public TextView tvColorName;
            public ImageView imgSelector;

            public ColorViewHolder(View itemView) {
                super(itemView);
                layoutColorItem = itemView.findViewById(R.id.layout_color_item);
                tvColorCode = itemView.findViewById(R.id.tv_color_code);
                tvColorName = itemView.findViewById(R.id.tv_color_name);
                imgSelector = itemView.findViewById(R.id.img_selector);
                itemView.setOnClickListener(v -> {
                    if (colorPickerCallback != null) {
                        if (Helper.getText(tvColorCode).equals("TRANSPARENT")) {
                            colorPickerCallback.onColorPicked(0);
                        } else if (Helper.getText(tvColorCode).equals("NONE")) {
                            colorPickerCallback.onColorPicked(0xffffff);
                        } else if (currentGroupIndex == 1 && sc_id != null) {
                            colorPickerCallback.onResourceColorPicked((String) tvColorName.getText(), Color.parseColor(Helper.getText(tvColorCode)));
                        } else {
                            colorPickerCallback.onColorPicked(Color.parseColor(Helper.getText(tvColorCode)));
                        }
                    }
                    dismiss();
                });
                itemView.setOnLongClickListener(v -> {
                    if (currentGroupIndex == 0) showColorRemoveDialog(Helper.getText(tvColorCode));
                    return false;
                });
            }
        }
    }

    public class AttrAdapter extends RecyclerView.Adapter<AttrAdapter.AttrViewHolder> {

        private final ArrayList<Attribute> attributeList;

        private final int selectedPosition;

        public AttrAdapter(ArrayList<Attribute> attributeList, int selectedPosition) {
            this.attributeList = attributeList;
            this.selectedPosition = selectedPosition;
        }

        @NonNull
        @Override
        public AttrViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            ItemAttrBinding binding = ItemAttrBinding.inflate(
                    LayoutInflater.from(parent.getContext()), parent, false);
            return new AttrViewHolder(binding);
        }

        @Override
        public void onBindViewHolder(@NonNull AttrViewHolder holder, int position) {
            Attribute attribute = attributeList.get(position);
            holder.binding.tvAttrName.setText(attribute.name());

            int lightColor = PropertiesUtil.parseColor(colorResourceResolver.getColorValueFromAttrs(activity, attribute.name(), 1, false));
            int darkColor = PropertiesUtil.parseColor(colorResourceResolver.getColorValueFromAttrs(activity, attribute.name(), 1, true));

            holder.binding.darkContainer.setBackgroundColor(darkColor);
            holder.binding.lightContainer.setBackgroundColor(lightColor);
            holder.binding.darkTtl.setTextColor(lightColor);
            holder.binding.lightTtl.setTextColor(darkColor);
            holder.binding.title.setVisibility(attribute.hasTitle() ? View.VISIBLE : View.GONE);
            if (attribute.hasTitle()) {
                holder.binding.title.setText(attribute.attrTitle());
            }
            holder.binding.checkedImg.setVisibility(selectedPosition == position ? View.VISIBLE : View.GONE);

            holder.binding.container.setOnClickListener(view -> {
                if (materialColorAttr != null) {
                    materialColorAttr.selectedMaterialColorAttr(attribute.name(), material3LibraryManager.canUseNightVariantColors() ? darkColor : lightColor);
                }
                dismiss();
            });
        }

        @Override
        public int getItemCount() {
            return attributeList.size();
        }

        public static class AttrViewHolder extends RecyclerView.ViewHolder {
            private final ItemAttrBinding binding;

            public AttrViewHolder(@NonNull ItemAttrBinding binding) {
                super(binding.getRoot());
                this.binding = binding;
            }
        }
    }

    public class resColorsAdapter extends RecyclerView.Adapter<resColorsAdapter.resColorsViewHolder> {

        private final ArrayList<ResColor> resColors;

        private final int selectedPosition;

        public resColorsAdapter(ArrayList<ResColor> resColors, int selectedPosition) {
            this.resColors = resColors;
            this.selectedPosition = selectedPosition;
        }

        @NonNull
        @Override
        public resColorsViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            ItemAttrBinding binding = ItemAttrBinding.inflate(
                    LayoutInflater.from(parent.getContext()), parent, false);
            return new resColorsViewHolder(binding);
        }

        @Override
        public void onBindViewHolder(@NonNull resColorsViewHolder holder, int position) {
            ResColor resColor = resColors.get(position);
            holder.binding.tvAttrName.setText(resColor.colorName());
            boolean hasNightColor = resColor.nightColorValue() != -1;
            int reversedColor = getReversedColor(resColor.colorValue());

            if (hasNightColor) {
                holder.binding.darkContainer.setBackgroundColor(resColor.nightColorValue());
                if (resColor.colorValue() != resColor.nightColorValue()) {
                    holder.binding.darkTtl.setTextColor(resColor.colorValue());
                    holder.binding.lightTtl.setTextColor(resColor.nightColorValue());
                } else {
                    holder.binding.darkTtl.setTextColor(reversedColor);
                    holder.binding.lightTtl.setTextColor(getReversedColor(resColor.nightColorValue()));
                }
            } else {
                holder.binding.darkContainer.setBackgroundColor(resColor.colorValue());
                holder.binding.darkTtl.setTextColor(reversedColor);
                holder.binding.lightTtl.setTextColor(reversedColor);
            }
            holder.binding.lightContainer.setBackgroundColor(resColor.colorValue());
            holder.binding.checkedImg.setVisibility(selectedPosition == position ? View.VISIBLE : View.GONE);
            holder.binding.checkedImg.setColorFilter(reversedColor);

            holder.binding.container.setOnClickListener(view -> {
                colorPickerCallback.onResourceColorPicked(resColor.colorName(), resColor.colorValue());
                dismiss();
            });
        }

        private int getReversedColor(int color) {
            int alpha = Color.alpha(color);
            int red = 255 - Color.red(color);
            int green = 255 - Color.green(color);
            int blue = 255 - Color.blue(color);
            return Color.argb(alpha, red, green, blue);
        }

        @Override
        public int getItemCount() {
            return resColors.size();
        }

        public static class resColorsViewHolder extends RecyclerView.ViewHolder {
            private final ItemAttrBinding binding;

            public resColorsViewHolder(@NonNull ItemAttrBinding binding) {
                super(binding.getRoot());
                this.binding = binding;
            }
        }
    }

}

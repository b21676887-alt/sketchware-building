package pro.sketchware.core.project;

import com.google.gson.Gson;

import java.util.HashMap;

import pro.sketchware.core.build.ProjectBuilder;
import pro.sketchware.core.project.SketchwarePaths;
import pro.sketchware.util.Helper;
import pro.sketchware.core.build.BuildProgressReceiver;
import pro.sketchware.util.FileUtil;

public class StringfogHandler {

    private final String config_path;

    public StringfogHandler(String sc_id) {
        config_path = SketchwarePaths.getProjectStringfogConfigPath(sc_id);

        if (!FileUtil.isExistFile(config_path)) FileUtil.writeFile(config_path, getDefaultConfig());
    }

    private static String getDefaultConfig() {
        HashMap<String, String> config = new HashMap<>();
        config.put("enabled", "false");

        return new Gson().toJson(config);
    }

    public boolean isStringfogEnabled() {
        boolean enabled;

        if (FileUtil.isExistFile(config_path)) {
            HashMap<String, String> config = null;

            try {
                config = new Gson().fromJson(FileUtil.readFile(config_path), Helper.TYPE_STRING_MAP);
            } finally {
                Object enabledValue;

                enabled = (config != null)
                        && (enabledValue = config.get("enabled")) != null
                        && enabledValue.equals("true");
            }

            return enabled;
        }

        return false;
    }

    public void setStringfogEnabled(boolean enabled) {
        HashMap<String, String> config;
        try {
            config = new Gson().fromJson(FileUtil.readFile(config_path), Helper.TYPE_STRING_MAP);
        } catch (Exception e) {
            config = new HashMap<>();
        }
        config.put("enabled", Boolean.valueOf(enabled).toString());

        FileUtil.writeFile(config_path, new Gson().toJson(config));
    }

    /**
     * Check if StringFog is enabled for the project, and run it if it is.
     */
    public void start(BuildProgressReceiver progressReceiver, ProjectBuilder builder) {
        if (isStringfogEnabled()) {
            progressReceiver.onProgress("Running StringFog...", 14);
            builder.runStringfog();
        }
    }
}

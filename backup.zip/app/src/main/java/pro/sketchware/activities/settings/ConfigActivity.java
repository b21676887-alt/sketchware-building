package pro.sketchware.activities.settings;

import static pro.sketchware.util.GsonUtils.getGson;

import android.graphics.Typeface;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.preference.PreferenceDataStore;

import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.card.MaterialCardView;
import com.google.android.material.materialswitch.MaterialSwitch;
import com.google.android.material.snackbar.BaseTransientBottomBar;
import com.google.android.material.snackbar.Snackbar;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;
import com.google.gson.JsonParseException;
import com.topjohnwu.superuser.Shell;

import java.io.File;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import pro.sketchware.activities.base.BaseAppCompatActivity;
import pro.sketchware.core.project.SketchwarePaths;
import pro.sketchware.databinding.PreferenceActivityNewBinding;
import pro.sketchware.R;
import pro.sketchware.util.FileUtil;
import pro.sketchware.util.Helper;
import pro.sketchware.util.LogUtil;
import pro.sketchware.util.SketchwareUtil;
import pro.sketchware.util.ThemeUtils;

public class ConfigActivity extends BaseAppCompatActivity {

    public static final File SETTINGS_FILE = new File(SketchwarePaths.getSettingsPath());
    public static final String SETTING_ALWAYS_SHOW_BLOCKS = "always-show-blocks";
    public static final String SETTING_BACKUP_DIRECTORY = "backup-dir";
    public static final String SETTING_ROOT_AUTO_INSTALL_PROJECTS = "root-auto-install-projects";
    public static final String SETTING_ROOT_AUTO_OPEN_AFTER_INSTALLING = "root-auto-open-after-installing";
    public static final String SETTING_BACKUP_FILENAME = "backup-filename";
    public static final String SETTING_SHOW_BUILT_IN_BLOCKS = "built-in-blocks";
    public static final String SETTING_SHOW_EVERY_SINGLE_BLOCK = "show-every-single-block";
    public static final String SETTING_USE_NEW_VERSION_CONTROL = "use-new-version-control";
    public static final String SETTING_USE_ASD_HIGHLIGHTER = "use-asd-highlighter";
    public static final String SETTING_CRITICAL_UPDATE_REMINDER = "critical-update-reminder";
    public static final String SETTING_BLOCKMANAGER_DIRECTORY_PALETTE_FILE_PATH = "palletteDir";
    public static final String SETTING_BLOCKMANAGER_DIRECTORY_BLOCK_FILE_PATH = "blockDir";
    public static final String SETTING_PROJECT_DATA_ENCRYPTION = "project-data-encryption";
    public static final String SETTING_LAST_RESTORE_DIRECTORY = "last-restore-dir";
    public static final String SETTING_TREE_VIEW = "enable-tree-view";
    public static final String SETTING_JAVA_TREE_VIEW = "enable-java-tree-view"; 
    public static final String SETTING_ASSETS_TREE_VIEW = "enable-assets-tree-view"; 
    public static final String SETTING_CPP_TREE_VIEW    = "cpp_tree_view";
    public static final String SETTING_RESOURCE_TREE_VIEW = "enable-resource-tree-view";

    private PreferenceActivityNewBinding binding;

    public static String getBackupPath() {
        return DataStore.getInstance().getString(SETTING_BACKUP_DIRECTORY,
                (String) getDefaultValue(SETTING_BACKUP_DIRECTORY));
    }

    public static String getLastRestoreDirectory() {
        return DataStore.getInstance().getString(SETTING_LAST_RESTORE_DIRECTORY, "");
    }

    public static void setLastRestoreDirectory(String path) {
        DataStore.getInstance().putString(SETTING_LAST_RESTORE_DIRECTORY, path);
    }

    public static String getStringSettingValueOrSetAndGet(String settingKey, String toReturnAndSetIfNotFound) {
        var dataStore = DataStore.getInstance();
        Map<String, Object> settings = dataStore.getSettings();

        Object value = settings.get(settingKey);
        if (value instanceof String s) {
            return s;
        } else {
            dataStore.putString(settingKey, toReturnAndSetIfNotFound);
            dataStore.persist();
            return toReturnAndSetIfNotFound;
        }
    }

    public static String getBackupFileName() {
        return DataStore.getInstance().getString(SETTING_BACKUP_FILENAME, "$projectName v$versionName ($pkgName, $versionCode) $time(yyyy-MM-dd'T'HHmmss)");
    }

    public static boolean isSettingEnabled(String keyName) {
        return DataStore.getInstance().getBoolean(keyName, false);
    }

    public static void setSetting(String key, Object value) {
        var dataStore = DataStore.getInstance();
        if (value instanceof String s) {
            dataStore.putString(key, s);
        } else if (value instanceof Boolean b) {
            dataStore.putBoolean(key, b);
        } else {
            throw new IllegalArgumentException("Unhandled data type " + value.getClass());
        }
        dataStore.persist();
    }

    @NonNull
    private static HashMap<String, Object> readSettings() {
        HashMap<String, Object> settings;

        if (SETTINGS_FILE.exists()) {
            Exception toLog;

            try {
                settings = getGson().fromJson(FileUtil.readFile(SETTINGS_FILE.getAbsolutePath()), Helper.TYPE_MAP);

                if (settings != null) {
                    return settings;
                }

                toLog = new NullPointerException("settings == null");
            } catch (JsonParseException e) {
                toLog = e;
            }

            SketchwareUtil.toastError(Helper.getResString(R.string.config_error_parse_settings));
            LogUtil.e("ConfigActivity", "Failed to parse App Settings.", toLog);
        }
        settings = new HashMap<>();
        restoreDefaultSettings(settings);

        return settings;
    }

    private static void restoreDefaultSettings(HashMap<String, Object> settings) {
        settings.clear();

        List<String> keys = Arrays.asList(
                SETTING_ALWAYS_SHOW_BLOCKS,
                SETTING_BACKUP_DIRECTORY,
                SETTING_ROOT_AUTO_INSTALL_PROJECTS,
                SETTING_ROOT_AUTO_OPEN_AFTER_INSTALLING,
                SETTING_SHOW_BUILT_IN_BLOCKS,
                SETTING_SHOW_EVERY_SINGLE_BLOCK,
                SETTING_USE_NEW_VERSION_CONTROL,
                SETTING_USE_ASD_HIGHLIGHTER,
                SETTING_BLOCKMANAGER_DIRECTORY_PALETTE_FILE_PATH,
                SETTING_BLOCKMANAGER_DIRECTORY_BLOCK_FILE_PATH,
                SETTING_PROJECT_DATA_ENCRYPTION,
                SETTING_TREE_VIEW,
                SETTING_JAVA_TREE_VIEW,
                SETTING_ASSETS_TREE_VIEW,
                SETTING_CPP_TREE_VIEW,
                SETTING_RESOURCE_TREE_VIEW
        );

        for (String key : keys) {
            settings.put(key, getDefaultValue(key));
        }
        FileUtil.writeFile(SETTINGS_FILE.getAbsolutePath(), getGson().toJson(settings));
    }

    public static Object getDefaultValue(String key) {
        return switch (key) {
            case SETTING_ALWAYS_SHOW_BLOCKS,
                 SETTING_ROOT_AUTO_INSTALL_PROJECTS, SETTING_SHOW_BUILT_IN_BLOCKS,
                 SETTING_SHOW_EVERY_SINGLE_BLOCK, SETTING_USE_NEW_VERSION_CONTROL,
                 SETTING_USE_ASD_HIGHLIGHTER, SETTING_PROJECT_DATA_ENCRYPTION,
                 SETTING_TREE_VIEW, SETTING_JAVA_TREE_VIEW, SETTING_ASSETS_TREE_VIEW,
                 SETTING_CPP_TREE_VIEW, SETTING_RESOURCE_TREE_VIEW -> false;
            case SETTING_BACKUP_DIRECTORY ->
                    SketchwarePaths.toExternalStorageRelativePath(SketchwarePaths.getBackupsPath());
            case SETTING_ROOT_AUTO_OPEN_AFTER_INSTALLING -> true;
            case SETTING_BLOCKMANAGER_DIRECTORY_PALETTE_FILE_PATH ->
                    SketchwarePaths.toExternalStorageRelativePath(
                            SketchwarePaths.getBlockManagerPaletteFilePath());
            case SETTING_BLOCKMANAGER_DIRECTORY_BLOCK_FILE_PATH ->
                    SketchwarePaths.toExternalStorageRelativePath(
                            SketchwarePaths.getBlockManagerBlockFilePath());
            default -> throw new IllegalArgumentException("Unknown key '" + key + "'!");
        };
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        enableEdgeToEdgeNoContrast();
        super.onCreate(savedInstanceState);
        
        binding = PreferenceActivityNewBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        ViewCompat.setOnApplyWindowInsetsListener(binding.getRoot(), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return WindowInsetsCompat.CONSUMED;
        });

        binding.topAppBar.setTitle(R.string.settings_title);
        binding.topAppBar.setNavigationOnClickListener(Helper.getBackPressedClickListener(this));

        setupPreferences(binding.content);
    }

    private void setupPreferences(ViewGroup content) {
        content.removeAllViews();

        content.addView(createCategoryHeader(Helper.getResString(R.string.title_general_category)));
        content.addView(createPreferenceCard(
                createSwitchPreference(R.drawable.ic_mtrl_block, R.string.pref_show_all_var_blocks_title, R.string.pref_show_all_var_blocks_summary, SETTING_ALWAYS_SHOW_BLOCKS),
                createSwitchPreference(R.drawable.ic_mtrl_puzzle, R.string.pref_built_in_blocks_title, R.string.pref_built_in_blocks_summary, SETTING_SHOW_BUILT_IN_BLOCKS),
                createSwitchPreference(R.drawable.ic_mtrl_view_module, R.string.pref_show_all_palette_blocks_title, R.string.pref_show_all_palette_blocks_summary, SETTING_SHOW_EVERY_SINGLE_BLOCK),
                createSwitchPreference(R.drawable.ic_mtrl_code, R.string.pref_block_highlighting_title, R.string.pref_block_highlighting_summary, SETTING_USE_ASD_HIGHLIGHTER),
                createSwitchPreference(R.drawable.ic_mtrl_code, R.string.pref_project_encryption_title, R.string.pref_project_encryption_summary, SETTING_PROJECT_DATA_ENCRYP)
        ));

        content.addView(createCategoryHeader(Helper.getResString(R.string.title_explorer_project_category)));
        content.addView(createPreferenceCard(
                createSwitchPreference(R.drawable.ic_mtrl_tree_view, R.string.pref_enable_treeview_title, R.string.pref_enable_treeview_summary, SETTING_TREE_VIEW)
        ));

        content.addView(createCategoryHeader(Helper.getResString(R.string.title_backuprestore_category)));
        TextView[] backupDirDesc = new TextView[1];
        TextView[] backupNameDesc = new TextView[1];
        content.addView(createPreferenceCard(
                createActionPreference(R.drawable.ic_mtrl_folder, R.string.pref_backup_dir_title, getBackupPath(), v -> showBackupDirDialog(backupDirDesc[0]), backupDirDesc),
                createActionPreference(R.drawable.ic_mtrl_file, R.string.pref_backup_filename_title, R.string.pref_backup_filename_summary, v -> showBackupNameDialog(), backupNameDesc)
        ));

        content.addView(createCategoryHeader(Helper.getResString(R.string.title_versioncontrol_category)));
        content.addView(createPreferenceCard(
                createSwitchPreference(R.drawable.ic_mtrl_version_control, R.string.pref_new_version_control_title, R.string.pref_new_version_control_summary, SETTING_USE_NEW_VERSION_CONTROL)
        ));

        content.addView(createCategoryHeader(Helper.getResString(R.string.title_rootfeatures_category)));
        content.addView(createPreferenceCard(
                createSwitchPreference(R.drawable.ic_mtrl_code, R.string.pref_root_install_title, R.string.pref_root_install_summary, SETTING_ROOT_AUTO_INSTALL_PROJECTS),
                createSwitchPreference(R.drawable.ic_mtrl_apk_install, R.string.pref_root_launch_title, R.string.pref_root_launch_summary, SETTING_ROOT_AUTO_OPEN_AFTER_INSTALLING)
        ));
    }

    private View createCategoryHeader(String titleText) {
        TextView tv = new TextView(this);
        tv.setText(titleText);
        tv.setTextSize(14f);
        tv.setTypeface(null, Typeface.BOLD);
        tv.setTextColor(ThemeUtils.getColor(this, R.attr.colorPrimary));
        int padLeft = SketchwareUtil.dpToPx(32);
        tv.setPadding(padLeft, SketchwareUtil.dpToPx(16), padLeft, SketchwareUtil.dpToPx(8));
        return tv;
    }

    private MaterialCardView createPreferenceCard(View... items) {
        MaterialCardView card = new MaterialCardView(this);
        LinearLayout.LayoutParams cardParams = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        cardParams.setMargins(SketchwareUtil.dpToPx(16), 0, SketchwareUtil.dpToPx(16), SketchwareUtil.dpToPx(8));
        card.setLayoutParams(cardParams);
        
        card.setRadius(SketchwareUtil.dpToPx(16));
        card.setCardElevation(0);
        card.setStrokeWidth(SketchwareUtil.dpToPx(1));
        card.setStrokeColor(ThemeUtils.getColor(this, com.google.android.material.R.attr.colorOutlineVariant));
        card.setCardBackgroundColor(ThemeUtils.getColor(this, com.google.android.material.R.attr.colorSurfaceContainerLow));
        card.setClipChildren(true);

        LinearLayout cardContent = new LinearLayout(this);
        cardContent.setOrientation(LinearLayout.VERTICAL);
        cardContent.setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        for (int i = 0; i < items.length; i++) {
            cardContent.addView(items[i]);
            if (i < items.length - 1) {
                View divider = new View(this);
                LinearLayout.LayoutParams divParams = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, SketchwareUtil.dpToPx(1));
                divParams.setMargins(SketchwareUtil.dpToPx(56), 0, SketchwareUtil.dpToPx(16), 0);
                divider.setLayoutParams(divParams);
                divider.setBackgroundColor(ThemeUtils.getColor(this, com.google.android.material.R.attr.colorOutlineVariant));
                cardContent.addView(divider);
            }
        }
        card.addView(cardContent);
        return card;
    }

    private View createSwitchPreference(int iconRes, int titleRes, int descRes, String prefKey) {
        return createSwitchPreference(iconRes, getString(titleRes), getString(descRes), prefKey);
    }
    
    private View createActionPreference(int iconRes, int titleRes, int descRes, View.OnClickListener listener, TextView[] outDescView) {
        return createActionPreference(iconRes, getString(titleRes), getString(descRes), listener, outDescView);
    }
    
    private View createActionPreference(int iconRes, int titleRes, String desc, View.OnClickListener listener, TextView[] outDescView) {
        return createActionPreference(iconRes, getString(titleRes), desc, listener, outDescView);
    }

    private View createSwitchPreference(int iconRes, String title, String desc, String prefKey) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setClickable(true);
        row.setFocusable(true);
        
        TypedValue outValue = new TypedValue();
        getTheme().resolveAttribute(android.R.attr.selectableItemBackground, outValue, true);
        row.setBackgroundResource(outValue.resourceId);
        
        int padH = SketchwareUtil.dpToPx(16);
        int padV = SketchwareUtil.dpToPx(16);
        row.setPadding(padH, padV, padH, padV);

        ImageView icon = new ImageView(this);
        icon.setImageResource(iconRes);
        icon.setColorFilter(ThemeUtils.getColor(this, R.attr.colorOnSurfaceVariant));
        row.addView(icon, new LinearLayout.LayoutParams(SketchwareUtil.dpToPx(24), SketchwareUtil.dpToPx(24)));

        LinearLayout textContainer = new LinearLayout(this);
        textContainer.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams textParams = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1.0f);
        textParams.setMargins(SketchwareUtil.dpToPx(16), 0, SketchwareUtil.dpToPx(16), 0);
        row.addView(textContainer, textParams);

        TextView tvTitle = new TextView(this);
        tvTitle.setText(title);
        tvTitle.setTextSize(16f);
        tvTitle.setTextColor(ThemeUtils.getColor(this, R.attr.colorOnSurface));
        textContainer.addView(tvTitle);

        TextView tvDesc = new TextView(this);
        tvDesc.setText(desc);
        tvDesc.setTextSize(13f);
        tvDesc.setTextColor(ThemeUtils.getColor(this, R.attr.colorOnSurfaceVariant));
        tvDesc.setPadding(0, SketchwareUtil.dpToPx(2), 0, 0);
        textContainer.addView(tvDesc);

        MaterialSwitch mSwitch = new MaterialSwitch(this);
        DataStore ds = DataStore.getInstance();
        mSwitch.setChecked(ds.getBoolean(prefKey, (Boolean) getDefaultValue(prefKey)));
        row.addView(mSwitch);

        row.setOnClickListener(v -> mSwitch.toggle());

        mSwitch.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (prefKey.equals(SETTING_ROOT_AUTO_INSTALL_PROJECTS) && isChecked) {
                Shell.getShell(shell -> {
                    if (!shell.isRoot()) {
                        Snackbar.make(binding.getRoot(), Helper.getResString(R.string.config_error_no_root), BaseTransientBottomBar.LENGTH_SHORT).show();
                        mSwitch.setChecked(false);
                    } else {
                        ds.putBoolean(prefKey, true);
                    }
                });
            } else {
                ds.putBoolean(prefKey, isChecked);
            }
        });

        return row;
    }

    private View createActionPreference(int iconRes, String title, String desc, View.OnClickListener listener, TextView[] outDescView) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setClickable(true);
        row.setFocusable(true);
        
        TypedValue outValue = new TypedValue();
        getTheme().resolveAttribute(android.R.attr.selectableItemBackground, outValue, true);
        row.setBackgroundResource(outValue.resourceId);
        
        int padH = SketchwareUtil.dpToPx(16);
        int padV = SketchwareUtil.dpToPx(16);
        row.setPadding(padH, padV, padH, padV);
        row.setOnClickListener(listener);

        ImageView icon = new ImageView(this);
        icon.setImageResource(iconRes);
        icon.setColorFilter(ThemeUtils.getColor(this, R.attr.colorOnSurfaceVariant));
        row.addView(icon, new LinearLayout.LayoutParams(SketchwareUtil.dpToPx(24), SketchwareUtil.dpToPx(24)));

        LinearLayout textContainer = new LinearLayout(this);
        textContainer.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams textParams = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1.0f);
        textParams.setMargins(SketchwareUtil.dpToPx(16), 0, SketchwareUtil.dpToPx(16), 0);
        row.addView(textContainer, textParams);

        TextView tvTitle = new TextView(this);
        tvTitle.setText(title);
        tvTitle.setTextSize(16f);
        tvTitle.setTextColor(ThemeUtils.getColor(this, R.attr.colorOnSurface));
        textContainer.addView(tvTitle);

        TextView tvDesc = new TextView(this);
        tvDesc.setText(desc);
        tvDesc.setTextSize(13f);
        tvDesc.setTextColor(ThemeUtils.getColor(this, R.attr.colorOnSurfaceVariant));
        tvDesc.setPadding(0, SketchwareUtil.dpToPx(2), 0, 0);
        textContainer.addView(tvDesc);

        if (outDescView != null && outDescView.length > 0) {
            outDescView[0] = tvDesc;
        }

        return row;
    }

    private void showBackupDirDialog(TextView descView) {
        showInputDialog(Helper.getResString(R.string.settings_backup_directory_title), "e.g. " + getDefaultValue(SETTING_BACKUP_DIRECTORY), getBackupPath(), text -> {
            DataStore.getInstance().putString(SETTING_BACKUP_DIRECTORY, text);
            if (descView != null) descView.setText(text);
        });
    }

    private void showBackupNameDialog() {
        String hint = "Variables: $projectName, $versionCode, $versionName, $pkgName, $timeInMs";
        showInputDialog(Helper.getResString(R.string.settings_backup_filename_title), hint, getBackupFileName(), text -> {
            DataStore.getInstance().putString(SETTING_BACKUP_FILENAME, text);
        });
    }

    private void showInputDialog(String title, String hint, String currentVal, OnInputSaved listener) {
        BottomSheetDialog dialog = new BottomSheetDialog(this);
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        int pad = SketchwareUtil.dpToPx(24);
        layout.setPadding(pad, pad, pad, pad);

        TextView tvTitle = new TextView(this);
        tvTitle.setText(title);
        tvTitle.setTextSize(20f);
        tvTitle.setTypeface(null, Typeface.BOLD);
        tvTitle.setTextColor(ThemeUtils.getColor(this, R.attr.colorOnSurface));
        layout.addView(tvTitle);

        TextView tvHint = new TextView(this);
        tvHint.setText(hint);
        tvHint.setTextSize(14f);
        tvHint.setTextColor(ThemeUtils.getColor(this, R.attr.colorOnSurfaceVariant));
        tvHint.setPadding(0, SketchwareUtil.dpToPx(8), 0, SketchwareUtil.dpToPx(16));
        layout.addView(tvHint);

        TextInputLayout til = new TextInputLayout(this);
        til.setBoxBackgroundMode(TextInputLayout.BOX_BACKGROUND_OUTLINE);
        til.setBoxCornerRadii(28f, 28f, 28f, 28f);

        TextInputEditText et = new TextInputEditText(this);
        et.setText(currentVal);
        et.setTextColor(ThemeUtils.getColor(this, R.attr.colorOnSurface));
        til.addView(et);
        layout.addView(til, new LinearLayout.LayoutParams(-1, -2));

        MaterialButton btnSave = new MaterialButton(this);
        btnSave.setText(Helper.getResString(R.string.common_word_save));
        btnSave.setCornerRadius(SketchwareUtil.dpToPx(24));
        LinearLayout.LayoutParams btnParams = new LinearLayout.LayoutParams(-1, -2);
        btnParams.topMargin = SketchwareUtil.dpToPx(16);
        layout.addView(btnSave, btnParams);

        btnSave.setOnClickListener(v -> {
            listener.onSave(et.getText().toString().trim());
            dialog.dismiss();
        });

        dialog.setContentView(layout);
        dialog.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE);
        dialog.show();
    }

    interface OnInputSaved {
        void onSave(String text);
    }

    public static class DataStore extends PreferenceDataStore {
        private static DataStore INSTANCE;
        private final Map<String, Object> settings;

        private DataStore() {
            settings = readSettings();
        }

        public static DataStore getInstance() {
            return INSTANCE == null ? (INSTANCE = new DataStore()) : INSTANCE;
        }

        private Map<String, Object> getSettings() {
            return settings;
        }

        public void persist() {
            FileUtil.writeFile(SETTINGS_FILE.getAbsolutePath(), getGson().toJson(settings));
        }

        @Override
        public void putString(String key, @Nullable String value) {
            if (value == null) {
                settings.remove(key);
            } else {
                settings.put(key, value);
            }
            persist();
        }

        @Nullable
        @Override
        public String getString(String key, @Nullable String defValue) {
            var value = settings.get(key);
            if (value instanceof String s) {
                return s;
            }
            return defValue;
        }

        @Override
        public void putBoolean(String key, boolean value) {
            settings.put(key, value);
            persist();
        }

        @Override
        public boolean getBoolean(String key, boolean defValue) {
            var value = settings.get(key);
            if (value instanceof Boolean b) {
                return b;
            }
            return defValue;
        }
    }
}

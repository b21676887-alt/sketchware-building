package pro.sketchware.activities.editor;

import android.animation.ObjectAnimator;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.Color;
import android.graphics.Typeface;
import android.media.AudioAttributes;
import android.media.SoundPool;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Parcelable;
import android.os.Vibrator;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.util.Pair;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.Choreographer;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.animation.DecelerateInterpolator;
import android.view.inputmethod.EditorInfo;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupMenu;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.OnBackPressedCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.widget.Toolbar;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import pro.sketchware.beans.BlockBean;
import pro.sketchware.beans.BlockCollectionBean;
import pro.sketchware.beans.ComponentBean;
import pro.sketchware.beans.HistoryBlockBean;
import pro.sketchware.beans.MoreBlockCollectionBean;
import pro.sketchware.beans.ProjectFileBean;
import pro.sketchware.beans.ViewBean;
import pro.sketchware.beans.ViewBeans;
import pro.sketchware.activities.editor.component.AddComponentBottomSheet;
import pro.sketchware.activities.editor.logic.BlockPane;
import pro.sketchware.activities.editor.logic.LogicTopMenu;
import pro.sketchware.activities.editor.logic.PaletteBlock;
import pro.sketchware.activities.editor.logic.PaletteSelector;
import pro.sketchware.activities.editor.makeblock.MakeBlockActivity;
import pro.sketchware.activities.editor.manage.ShowBlockCollectionActivity;
import pro.sketchware.activities.editor.view.ViewDummy;
import pro.sketchware.activities.editor.view.ViewLogicEditor;
import pro.sketchware.activities.base.BaseAppCompatActivity;
import pro.sketchware.widgets.ColorPickerDialog;
import com.bumptech.glide.Glide;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.crashlytics.FirebaseCrashlytics;

import java.io.File;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.atomic.AtomicReference;

import pro.sketchware.core.async.BackgroundTasks;
import pro.sketchware.util.io.SharedPrefsHelper;
import pro.sketchware.util.format.FormatUtil;
import pro.sketchware.core.codegen.BlockInterpreter;
import pro.sketchware.util.DeviceUtil;
import pro.sketchware.core.project.BlockCollectionManager;
import pro.sketchware.util.SketchToast;
import pro.sketchware.core.validation.UniqueNameValidator;
import pro.sketchware.core.codegen.LayoutGenerator;
import pro.sketchware.core.project.MoreBlockCollectionManager;
import pro.sketchware.core.block.view.BlockView;
import pro.sketchware.core.block.view.FieldBlockView;
import pro.sketchware.core.block.view.BaseBlockView;
import pro.sketchware.core.block.view.DefinitionBlockView;
import pro.sketchware.core.callback.BlockSizeListener;
import pro.sketchware.core.validation.IdentifierValidator;
import pro.sketchware.core.project.BlockHistoryManager;
import pro.sketchware.core.project.ProjectDataStore;
import pro.sketchware.core.project.ProjectDataManager;
import pro.sketchware.core.project.BuildConfig;
import pro.sketchware.core.project.ResourceManager;
import pro.sketchware.core.async.TaskHost;
import pro.sketchware.util.UIHelper;
import pro.sketchware.core.project.SketchwareConstants;
import pro.sketchware.core.project.BlockConstants;
import pro.sketchware.util.ViewUtil;
import pro.sketchware.core.codegen.StringResource;
import pro.sketchware.core.build.ProjectFilePaths;
import pro.sketchware.activities.editor.logic.ExtraPaletteBlock;
import pro.sketchware.graphics.VectorDrawableLoader;
import pro.sketchware.util.IdGenerator;
import pro.sketchware.activities.editor.makeblock.ReturnMoreblockManager;
import pro.sketchware.activities.editor.makeblock.MoreblockImporterDialog;
import pro.sketchware.core.project.ProjectSettings;
import pro.sketchware.util.Helper;
import pro.sketchware.dialogs.AsdDialog;
import pro.sketchware.activities.editor.makeblock.MoreblockImporter;
import pro.sketchware.util.BlockUtil;
import pro.sketchware.util.LogUtil;
import pro.sketchware.core.build.ViewBindingBuilder;
import pro.sketchware.R;
import pro.sketchware.activities.editor.view.CodeViewerActivity;
import pro.sketchware.activities.resourceseditor.ResourcesEditorActivity;
import pro.sketchware.databinding.ImagePickerItemBinding;
import pro.sketchware.databinding.SearchWithRecyclerViewBinding;
import pro.sketchware.activities.editor.logic.ExtraMenuBean;
import pro.sketchware.util.FilePathUtil;
import pro.sketchware.util.SvgUtils;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import pro.sketchware.logic.LogicSyntaxChecker;
// AI / Clipboard / dialogs
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.ClipData;
import android.content.ClipboardManager;

// AI project classes
import pro.sketchware.network.AiProviderService;
import pro.sketchware.network.AiRequestHandle;
import pro.sketchware.ia.LogicGenTask;
import android.widget.ProgressBar;
//classes BlocksConverter
import mod.sketchlibx.project.editor.BlocksConverter;


@SuppressLint({"ClickableViewAccessibility", "RtlHardcoded", "SetTextI18n", "DefaultLocale"})
public class LogicEditorActivity extends BaseAppCompatActivity implements View.OnClickListener, BlockSizeListener, View.OnTouchListener, MoreblockImporterDialog.CallBack {

    /** Blocks per chunk when loading; larger = fewer frames but more jank per frame. */
    private static final int BLOCK_LOAD_CHUNK_SIZE = 80;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final int[] locationBuffer = new int[2];
    private final FirebaseCrashlytics crashlytics = getFirebaseCrashlytics();
    public ProjectFileBean projectFile;
    public PaletteBlock paletteBlock;
    public BlockPane blockPane;
    public String scId = "";
    public String id = "";
    public String eventName = "";
    private String pendingScrollBlockId = null;
    private Vibrator vibrator;
    private LinearLayout paletteLayout, paletteArea;
    private FloatingActionButton openBlocksMenuButton;
    private LogicTopMenu logicTopMenu;
    private LogicEditorDrawer editorDrawer;
    private ObjectAnimator paletteShowAnimator, paletteHideAnimator, topMenuShowAnimator, topMenuHideAnimator, drawerShowAnimator, drawerHideAnimator;
    private ExtraPaletteBlock extraPaletteBlock;
    private PaletteBuildInterceptor paletteBuildInterceptor;
    private ViewLogicEditor viewLogicEditor;
    private ViewDummy dummy;
    public PaletteSelector paletteSelector;
    private ActivityResultLauncher<Intent> openResourcesEditor;
    private ActivityResultLauncher<Intent> makeBlockLauncher;
    private BlockView dragSourceParent;
    private float posInitY, posInitX, touchOriginX, touchOriginY;
    private int minDist, dummyOffsetX, dragConnectionType, dragParameterIndex;
    private int dummyOffsetY = -30;
    private View currentTouchedView;
    private boolean isVibrationEnabled, isDragged, paletteAnimatorsInitialized, isPaletteVisible, topMenuAnimatorsInitialized, isTopMenuVisible, drawerAnimatorsInitialized, isDrawerVisible;
    private boolean paletteBlocksInitialized = false;
    private ArrayList<BlockBean> savedBlockBean = new ArrayList<>();
    private final Runnable longPressed = this::startDragMode;
    private Boolean isViewBindingEnabled;

    private SvgUtils svgUtils;
    private final FilePathUtil fpu = new FilePathUtil();
    private EditText blockSearchField;
    private int lastSelectedPaletteId = 0;
    private int lastSelectedPaletteColor;
    private boolean isBlockSearchActive = false;
    private boolean suppressSearchTextChange = false;
    private Runnable pendingSearchRunnable;
    private View canvasSearchBar;
    private EditText canvasSearchInput;
    private TextView canvasSearchCount;
    private ArrayList<BlockView> canvasSearchMatches = new ArrayList<>();
    private int canvasSearchIndex = -1;
    private boolean isCanvasSearchActive = false;
    private Runnable pendingCanvasSearchRunnable;
    private OnBackPressedCallback canvasSearchBackCallback;
    private boolean suppressCanvasSearchTextChange = false;
    
    	// Syntax check fields
	private LinearLayout syntaxCheckContainer;
	private ImageView syntaxCheckIcon;
	private TextView syntaxCheckText;
	private final Handler syntaxCheckHandler = new Handler();
	private final Runnable syntaxCheckRunnable = this::runSyntaxCheck;
	// تعديل runSyntaxCheck لاستخدام خيط معالجة آمن وتفادي إنشائه باستمرار
	private final ExecutorService syntaxExecutor = Executors.newSingleThreadExecutor();
	// يحتفظ بمقبض الطلب الجاري حتى نتمكن من إلغائه
	private volatile AiRequestHandle activeAiRequest;

    public interface PaletteBuildInterceptor {
        void addDeprecatedBlock(String message, String type, String opCode);

        void addPaletteCategory(String categoryName, int color);

        void addPaletteLabel(String label, String tag, View.OnClickListener onClickListener);

        View createPaletteBlock(String blockType, String opCode);

        View createPaletteBlockWithSpec(String blockType, String spec, String opCode);

        View createPaletteBlockWithComponent(String blockType, String spec, String opCode, String componentType);
    }

    public static ArrayList<String> getAllJavaFileNames(String projectScId) {
        ArrayList<String> javaFileNames = new ArrayList<>();
        for (ProjectFileBean projectFile : ProjectDataManager.getFileManager(projectScId).getActivities()) {
            javaFileNames.add(projectFile.getJavaName());
        }
        return javaFileNames;
    }

    public static ArrayList<String> getAllXmlFileNames(String projectScId) {
        ArrayList<String> xmlFileNames = new ArrayList<>();
        for (ProjectFileBean projectFile : ProjectDataManager.getFileManager(projectScId).getActivities()) {
            String xmlName = projectFile.getXmlName();
            if (xmlName != null && !xmlName.isEmpty()) {
                xmlFileNames.add(xmlName);
            }
        }
        return xmlFileNames;
    }

    /**
     * Loads event blocks with chunked UI updates to avoid jank when there are many blocks.
     * @param onComplete run when loading is fully done (pane visible, dialog dismissed).
     */
    private void loadEventBlocks(Runnable onComplete) {
        if (crashlytics != null) crashlytics.log("Loading event blocks");
        ArrayList<BlockBean> eventBlocks = ProjectDataManager.getProjectDataManager(scId).getBlocks(projectFile.getJavaName(), id + "_" + eventName);
        if (eventBlocks != null) {
            if (eventBlocks.isEmpty()) {
                runOnUiThread(() -> {
                    if (isFinishing() || isDestroyed()) return;
                    togglePaletteVisibility(isPaletteVisible);
                    if (onComplete != null) onComplete.run();
                });
                return;
            }

            ArrayList<BlockView> createdBlocks = new ArrayList<>();
            HashMap<Integer, BlockView> blockIdsAndBlocks = new HashMap<>();
            for (BlockBean next : eventBlocks) {
                if (eventName.equals("onTextChanged") && next.opCode.equals("getArg") && next.spec.equals("text")) {
                    next.spec = "charSeq";
                }
                BlockView blockView = createBlockView(next);
                createdBlocks.add(blockView);
                blockIdsAndBlocks.put((Integer) blockView.getTag(), blockView);
                blockPane.nextBlockId = Math.max(blockPane.nextBlockId, (Integer) blockView.getTag() + 1);
            }

            runOnUiThread(() -> {
                if (isFinishing() || isDestroyed()) return;
                scheduleChunkedBlockAdd(createdBlocks, eventBlocks, blockIdsAndBlocks, 0, onComplete);
            });
        } else if (onComplete != null) {
            runOnUiThread(() -> {
                if (isFinishing() || isDestroyed()) return;
                onComplete.run();
                triggerSyntaxCheck();
            });
        }
    }

    private void scheduleChunkedBlockAdd(ArrayList<BlockView> createdBlocks, ArrayList<BlockBean> eventBlocks,
                                         HashMap<Integer, BlockView> blockIdsAndBlocks, int startIdx, Runnable onComplete) {
        int endIdx = Math.min(startIdx + BLOCK_LOAD_CHUNK_SIZE, createdBlocks.size());
        for (int idx = startIdx; idx < endIdx; idx++) {
            BlockView blockView = createdBlocks.get(idx);
            blockPane.addBlockNoLayout(blockView);
            blockView.setOnTouchListener(this);
            if (idx == 0) {
                blockPane.getRoot().setNextBlock(blockView);
            }
        }
        blockPane.requestLayout();

        if (endIdx >= createdBlocks.size()) {
            connectBlocksAndLayout(eventBlocks, blockIdsAndBlocks, onComplete);
        } else {
            Choreographer.getInstance().postFrameCallback(frameTimeNanos ->
                    scheduleChunkedBlockAdd(createdBlocks, eventBlocks, blockIdsAndBlocks, endIdx, onComplete));
        }
    }

    private void connectBlocksAndLayout(ArrayList<BlockBean> eventBlocks, HashMap<Integer, BlockView> blockIdsAndBlocks, Runnable onComplete) {
        for (BlockBean blockBean : eventBlocks) {
            BlockView block = blockIdsAndBlocks.get(Integer.valueOf(blockBean.id));
            if (block != null) {
                BlockView subStack1RootBlock;
                if (blockBean.subStack1 >= 0 && (subStack1RootBlock = blockIdsAndBlocks.get(blockBean.subStack1)) != null) {
                    block.setSubstack1Block(subStack1RootBlock);
                }
                BlockView subStack2RootBlock;
                if (blockBean.subStack2 >= 0 && (subStack2RootBlock = blockIdsAndBlocks.get(blockBean.subStack2)) != null) {
                    block.setSubstack2Block(subStack2RootBlock);
                }
                BlockView nextBlock;
                if (blockBean.nextBlock >= 0 && (nextBlock = blockIdsAndBlocks.get(blockBean.nextBlock)) != null) {
                    block.setNextBlock(nextBlock);
                }
                for (int i = 0; i < blockBean.parameters.size() && i < block.childViews.size(); i++) {
                    String parameter = blockBean.parameters.get(i);
                    if (parameter != null && !parameter.isEmpty()) {
                        if (parameter.charAt(0) == '@') {
                            BlockView parameterBlock = blockIdsAndBlocks.get(Integer.valueOf(parameter.substring(1)));
                            if (parameterBlock != null && block.childViews.get(i) instanceof BaseBlockView) {
                                block.replaceParameter((BaseBlockView) block.childViews.get(i), parameterBlock);
                            }
                        } else if (block.childViews.get(i) instanceof FieldBlockView fieldBlock) {
                            fieldBlock.setArgValue(parameter);
                        }
                    }
                }
                block.recalculateToRoot();
            }
        }
        Choreographer.getInstance().postFrameCallback(frameTimeNanos -> {
            blockPane.getRoot().layoutChain();
            blockPane.updatePaneSize();
            if (onComplete != null) onComplete.run();
        });
    }

    private void redo() {
        if (!isDragged) {
            HistoryBlockBean historyBlockBean = BlockHistoryManager.getInstance(scId).redo(buildHistoryKey());
            if (historyBlockBean != null) {
                int actionType = historyBlockBean.getActionType();
                if (actionType == HistoryBlockBean.ACTION_TYPE_ADD) {
                    int[] locationOnScreen = new int[2];
                    blockPane.getLocationOnScreen(locationOnScreen);
                    addBlockBeans(historyBlockBean.getAddedData(), historyBlockBean.getCurrentX() + locationOnScreen[0], historyBlockBean.getCurrentY() + locationOnScreen[1], true);
                    if (historyBlockBean.getCurrentParentData() != null) {
                        connectBlock(historyBlockBean.getCurrentParentData(), true);
                    }
                } else if (actionType == HistoryBlockBean.ACTION_TYPE_UPDATE) {
                    connectBlock(historyBlockBean.getCurrentUpdateData(), true);
                } else if (actionType == HistoryBlockBean.ACTION_TYPE_REMOVE) {
                    ArrayList<BlockBean> removedData = historyBlockBean.getRemovedData();

                    for (int i = removedData.size() - 1; i >= 0; i--) {
                        blockPane.removeBlock(removedData.get(i), false);
                    }
                    if (historyBlockBean.getCurrentParentData() != null) {
                        connectBlock(historyBlockBean.getCurrentParentData(), true);
                    }
                } else if (actionType == HistoryBlockBean.ACTION_TYPE_MOVE) {
                    for (BlockBean afterMoveData : historyBlockBean.getAfterMoveData()) {
                        blockPane.removeBlock(afterMoveData, true);
                    }

                    int[] locationOnScreen = new int[2];
                    blockPane.getLocationOnScreen(locationOnScreen);
                    addBlockBeans(historyBlockBean.getAfterMoveData(), historyBlockBean.getCurrentX() + locationOnScreen[0], historyBlockBean.getCurrentY() + locationOnScreen[1], true);
                    if (historyBlockBean.getCurrentParentData() != null) {
                        connectBlock(historyBlockBean.getCurrentParentData(), true);
                    }

                    if (historyBlockBean.getCurrentOriginalParent() != null) {
                        connectBlock(historyBlockBean.getCurrentOriginalParent(), true);
                    }
                }
            }
            invalidateOptionsMenu();
        }
    }

    public void refreshOptionsMenu() {
        invalidateOptionsMenu();
        triggerSyntaxCheck();
    }

    public void saveBlocks() {
        ProjectDataStore projectDataStore = ProjectDataManager.getProjectDataManager(scId);
        String javaName = projectFile.getJavaName();
        projectDataStore.putBlocks(javaName, id + "_" + eventName, blockPane.getBlocks());
    }

    public void showAddListDialog() {
        MaterialAlertDialogBuilder dialog = new MaterialAlertDialogBuilder(this);
        dialog.setTitle(R.string.logic_editor_title_add_new_list);
        View dialogView = ViewUtil.inflateLayout(this, R.layout.logic_popup_add_list);
        RadioGroup radioGroup = dialogView.findViewById(R.id.rg_type);
        TextInputEditText editText = dialogView.findViewById(R.id.ed_input);
        IdentifierValidator listNameValidator = new IdentifierValidator(getContext(), dialogView.findViewById(R.id.ti_input), BlockConstants.RESERVED_KEYWORDS, BlockConstants.COMPONENT_TYPES, ProjectDataManager.getProjectDataManager(scId).getAllIdentifiers(projectFile));
        dialog.setView(dialogView);
        dialog.setPositiveButton(R.string.common_word_add, (v, which) -> {
            if (listNameValidator.isValid()) {
                int listType = ExtraMenuBean.LIST_TYPE_NUMBER;
                int checkedRadioButtonId = radioGroup.getCheckedRadioButtonId();
                if (checkedRadioButtonId != R.id.rb_int) {
                    if (checkedRadioButtonId == R.id.rb_string) {
                        listType = ExtraMenuBean.LIST_TYPE_STRING;
                    } else if (checkedRadioButtonId == R.id.rb_map) {
                        listType = ExtraMenuBean.LIST_TYPE_MAP;
                    }
                }

                addListVariable(listType, Helper.getText(editText));
                v.dismiss();
            }
        });
        dialog.setNegativeButton(R.string.common_word_cancel, null);
        dialog.show();
    }

    private void showAddNewVariableDialog() {
        MaterialAlertDialogBuilder dialog = new MaterialAlertDialogBuilder(this);
        dialog.setTitle(R.string.logic_editor_title_add_new_variable);

        View customView = ViewUtil.inflateLayout(this, R.layout.logic_popup_add_variable);
        RadioGroup radioGroup = customView.findViewById(R.id.rg_type);
        TextInputEditText editText = customView.findViewById(R.id.ed_input);
        IdentifierValidator nameValidator = new IdentifierValidator(getContext(), customView.findViewById(R.id.ti_input), BlockConstants.RESERVED_KEYWORDS, BlockConstants.COMPONENT_TYPES, ProjectDataManager.getProjectDataManager(scId).getAllIdentifiers(projectFile));
        dialog.setView(customView);
        dialog.setPositiveButton(R.string.common_word_add, (v, which) -> {
            int variableType = ExtraMenuBean.VARIABLE_TYPE_NUMBER;
            if (radioGroup.getCheckedRadioButtonId() == R.id.rb_boolean) {
                variableType = ExtraMenuBean.VARIABLE_TYPE_BOOLEAN;
            } else if (radioGroup.getCheckedRadioButtonId() != R.id.rb_int) {
                if (radioGroup.getCheckedRadioButtonId() == R.id.rb_string) {
                    variableType = ExtraMenuBean.VARIABLE_TYPE_STRING;
                } else if (radioGroup.getCheckedRadioButtonId() == R.id.rb_map) {
                    variableType = ExtraMenuBean.VARIABLE_TYPE_MAP;
                }
            }

            if (nameValidator.isValid()) {
                addVariable(variableType, Helper.getText(editText));
                v.dismiss();
            }
        });
        dialog.setNegativeButton(R.string.common_word_cancel, null);
        dialog.show();
    }

    public void openResourcesEditor() {
        Intent intent = new Intent();
        intent.setClass(getApplicationContext(), ResourcesEditorActivity.class);
        intent.putExtra("sc_id", scId);
        openResourcesEditor.launch(intent);
    }

    public void showMoreBlockImporter() {
        ArrayList<MoreBlockCollectionBean> moreBlocks = MoreBlockCollectionManager.getInstance().getMoreBlocks();
        new MoreblockImporterDialog(this, moreBlocks, this).show();
    }

    public void saveProject() {
        try {
            new Handler(Looper.getMainLooper()).postDelayed(() -> new ProjectSaver(this).execute(), 500L);
        } catch (Exception e) {
            if (crashlytics != null) crashlytics.recordException(e);
        }
    }

    private void undo() {
        if (!isDragged) {
            HistoryBlockBean history = BlockHistoryManager.getInstance(scId).undo(buildHistoryKey());
            if (history != null) {
                int actionType = history.getActionType();
                if (actionType == HistoryBlockBean.ACTION_TYPE_ADD) {
                    ArrayList<BlockBean> addedData = history.getAddedData();
                    for (int i = addedData.size() - 1; i >= 0; i--) {
                        blockPane.removeBlock(addedData.get(i), false);
                    }

                    if (history.getPrevParentData() != null) {
                        history.getPrevParentData().print();
                        connectBlock(history.getPrevParentData(), true);
                    }
                } else if (actionType == HistoryBlockBean.ACTION_TYPE_UPDATE) {
                    connectBlock(history.getPrevUpdateData(), true);
                } else if (actionType == HistoryBlockBean.ACTION_TYPE_REMOVE) {
                    int[] oLocationOnScreen = new int[2];
                    blockPane.getLocationOnScreen(oLocationOnScreen);
                    addBlockBeans(history.getRemovedData(), history.getCurrentX() + oLocationOnScreen[0], history.getCurrentY() + oLocationOnScreen[1], true);

                    if (history.getPrevParentData() != null) {
                        connectBlock(history.getPrevParentData(), true);
                    }
                } else if (actionType == HistoryBlockBean.ACTION_TYPE_MOVE) {
                    for (BlockBean beforeMoveBlock : history.getBeforeMoveData()) {
                        blockPane.removeBlock(beforeMoveBlock, true);
                    }

                    int[] oLocationOnScreen = new int[2];
                    blockPane.getLocationOnScreen(oLocationOnScreen);
                    addBlockBeans(history.getBeforeMoveData(), history.getPrevX() + oLocationOnScreen[0], history.getPrevY() + oLocationOnScreen[1], true);

                    if (history.getPrevParentData() != null) {
                        connectBlock(history.getPrevParentData(), true);
                    }
                    if (history.getPrevOriginalParent() != null) {
                        connectBlock(history.getPrevOriginalParent(), true);
                    }
                }
            }

            invalidateOptionsMenu();
        }
    }

    public BlockView dropBlockOnPane(BlockView rs, int x, int y, boolean isParameter) {
        BlockView droppedBlock = blockPane.dropBlock(rs, x, y, isParameter);
        if (!isParameter) {
            droppedBlock.setOnTouchListener(this);
        }
        return droppedBlock;
    }

    public void addDeprecatedBlock(String message, String type, String opCode) {
        if (paletteBuildInterceptor != null) {
            paletteBuildInterceptor.addDeprecatedBlock(message, type, opCode);
            return;
        }
        paletteBlock.addDeprecatedBlock(message, type, opCode);
    }

    public View createPaletteBlock(String spec, String opCode) {
        if (paletteBuildInterceptor != null) {
            return paletteBuildInterceptor.createPaletteBlock(spec, opCode);
        }
        BaseBlockView paletteBlockView = paletteBlock.addBlock("", spec, opCode);
        paletteBlockView.setTag(opCode);
        paletteBlockView.setClickable(true);
        paletteBlockView.setOnTouchListener(this);
        return paletteBlockView;
    }

    public final View createPaletteBlockWithSpec(String type, String spec, String opCode) {
        if (paletteBuildInterceptor != null) {
            return paletteBuildInterceptor.createPaletteBlockWithSpec(type, spec, opCode);
        }
        BaseBlockView paletteBlockView = paletteBlock.addBlock(type, spec, opCode);
        paletteBlockView.setTag(opCode);
        paletteBlockView.setClickable(true);
        paletteBlockView.setOnTouchListener(this);
        return paletteBlockView;
    }

    public final View createPaletteBlockWithComponent(String type, String spec, String opCode, String componentType) {
        if (paletteBuildInterceptor != null) {
            return paletteBuildInterceptor.createPaletteBlockWithComponent(type, spec, opCode, componentType);
        }
        BaseBlockView paletteBlockView = paletteBlock.addBlock(type, spec, opCode, componentType);
        paletteBlockView.setTag(componentType);
        paletteBlockView.setClickable(true);
        paletteBlockView.setOnTouchListener(this);
        return paletteBlockView;
    }

    private ImageView setImageViewContent(String name) {
        float dp = ViewUtil.dpToPx(this, 1.0f);
        int size = (int) (dp * 48);
        ImageView imageView = new ImageView(this);
        imageView.setLayoutParams(new LinearLayout.LayoutParams(size, size));
        imageView.setScaleType(ImageView.ScaleType.CENTER_CROP);
        imageView.setBackgroundResource(R.drawable.bg_outline);

        if ("NONE".equals(name)) {
            return imageView;
        }

        if ("default_image".equals(name)) {
            int resId = getResources().getIdentifier(name, "drawable", getPackageName());
            if (resId != 0) imageView.setImageResource(resId);
            return imageView;
        }

        File imageFile = new File(ProjectDataManager.getResourceManager(scId).getImagePath(name));
        if (imageFile.exists()) {
            String path = imageFile.getAbsolutePath();
            Uri uri = FileProvider.getUriForFile(this, getPackageName() + ".provider", imageFile);

            if (path.endsWith(".xml")) {
                svgUtils.loadImage(imageView, fpu.getSvgFullPath(scId, name));
            } else {
                Glide.with(this)
                        .load(uri)
                        .signature(ResourceManager.getCacheSignature())
                        .error(R.drawable.ic_remove_grey600_24dp)
                        .into(imageView);
            }
        } else {
            try {
                new VectorDrawableLoader().setImageVectorFromFile(imageView, new VectorDrawableLoader().getVectorFullPath(scId, name), scId);
            } catch (Exception e) {
                imageView.setImageResource(R.drawable.ic_remove_grey600_24dp);
            }
        }

        return imageView;
    }

    public final ArrayList<BlockBean> addBlockBeans(ArrayList<BlockBean> blockBeans, int x, int y, boolean layoutChain) {
        HashMap<Integer, Integer> idMapping = new HashMap<>();
        ArrayList<BlockBean> clonedBlocks = new ArrayList<>();
        for (BlockBean next : blockBeans) {
            if (next.id != null && !next.id.isEmpty()) {
                clonedBlocks.add(next.clone());
            }
        }
        for (BlockBean clonedBlock : clonedBlocks) {
            if (Integer.parseInt(clonedBlock.id) >= 99000000) {
                idMapping.put(Integer.valueOf(clonedBlock.id), blockPane.nextBlockId);
                blockPane.nextBlockId = blockPane.nextBlockId + 1;
            } else {
                idMapping.put(Integer.valueOf(clonedBlock.id), Integer.valueOf(clonedBlock.id));
            }
        }
        int size = clonedBlocks.size();
        while (true) {
            size--;
            if (size < 0) {
                break;
            }
            BlockBean blockBean = clonedBlocks.get(size);
            if (!isBlockValid(blockBean)) {
                clonedBlocks.remove(size);
                idMapping.remove(Integer.valueOf(blockBean.id));
            }
        }
        for (BlockBean block : clonedBlocks) {
            Integer mappedId = idMapping.get(Integer.valueOf(block.id));
            block.id = mappedId != null ? String.valueOf(mappedId) : "";
            for (int j = 0; j < block.parameters.size(); j++) {
                String parameter = block.parameters.get(j);
                if (parameter != null && !parameter.isEmpty() && parameter.charAt(0) == '@') {
                    int parameterId = Integer.parseInt(parameter.substring(1));
                    int parameterAsBlockId = idMapping.getOrDefault(parameterId, 0);
                    if (parameterAsBlockId >= 0) {
                        block.parameters.set(j, '@' + String.valueOf(parameterAsBlockId));
                    } else {
                        block.parameters.set(j, "");
                    }
                }
            }
            if (block.subStack1 >= 0) {
                block.subStack1 = idMapping.getOrDefault(block.subStack1, block.subStack1);
            }
            if (block.subStack2 >= 0) {
                block.subStack2 = idMapping.getOrDefault(block.subStack2, block.subStack2);
            }
            if (block.nextBlock >= 0) {
                block.nextBlock = idMapping.getOrDefault(block.nextBlock, block.nextBlock);
            }
        }
        BlockView firstBlock = null;
        for (int j = 0; j < clonedBlocks.size(); j++) {
            BlockBean blockBean = clonedBlocks.get(j);
            if (blockBean.id != null && !blockBean.id.isEmpty()) {
                BlockView block = createBlockView(blockBean);
                if (j == 0) {
                    firstBlock = block;
                }
                blockPane.addBlock(block, x, y);
                block.setOnTouchListener(this);
            }
        }
        for (BlockBean block : clonedBlocks) {
            if (block.id != null && !block.id.isEmpty()) {
                connectBlock(block, false);
            }
        }
        if (firstBlock != null && layoutChain) {
            firstBlock.getRootBlock().layoutChain();
            blockPane.updatePaneSize();
        }
        return clonedBlocks;
    }

    @Override
    public void onBlockSizeChanged(int width, int height) {
        lastSelectedPaletteId = width;
        lastSelectedPaletteColor = height;
        if (isBlockSearchActive && blockSearchField != null) {
            isBlockSearchActive = false;
            suppressSearchTextChange = true;
            blockSearchField.setText("");
            suppressSearchTextChange = false;
        }
        extraPaletteBlock.setBlock(width, height);
    }

    public void addListVariable(int i, String variableName) {
        ProjectDataManager.getProjectDataManager(scId).addListVariable(projectFile.getJavaName(), i, variableName);
        onBlockSizeChanged(1, ContextCompat.getColor(this, R.color.palette_list));
    }

    public void trackDragSource(BlockView rs) {
        dragSourceParent = null;
        dragParameterIndex = -1;
        dragConnectionType = 0;
        int[] unusedLocation = new int[2];
        BlockView parentBlock = rs.parentBlock;
        if (parentBlock != null) {
            dragSourceParent = parentBlock;
            if (savedBlockBean.isEmpty()) {
                savedBlockBean = blockPane.getBlocks();
            }
        }
        BlockView sourceParent = dragSourceParent;
        if (sourceParent == null) {
            return;
        }
        if (sourceParent.nextBlock == (Integer) rs.getTag()) {
            dragConnectionType = 0;
        } else if (dragSourceParent.subStack1 == (Integer) rs.getTag()) {
            dragConnectionType = 2;
        } else if (dragSourceParent.subStack2 == (Integer) rs.getTag()) {
            dragConnectionType = 3;
        } else if (dragSourceParent.childViews.contains(rs)) {
            dragConnectionType = 5;
            dragParameterIndex = dragSourceParent.childViews.indexOf(rs);
        }
    }

    public void handleBlockFieldClick(BlockView rs, float touchX, float touchY) {
        for (View next : rs.childViews) {
            if ((next instanceof FieldBlockView) && next.getX() < touchX && next.getX() + next.getWidth() > touchX && next.getY() < touchY && next.getY() + next.getHeight() > touchY) {
                new ExtraMenuBean(this).defineMenuSelector((FieldBlockView) next);
                return;
            }
        }
        if (!rs.isDefinitionBlock && isStatementBlock(rs)) {
            showBlockContextMenu(rs);
        }
    }

    private void showBlockContextMenu(BlockView blockView) {
        PopupMenu popup = new PopupMenu(this, blockView);
        popup.getMenu().add(0, 1, 0, blockView.disabled
                ? R.string.block_enable
                : R.string.block_disable);
        if (blockView.hasSubstack()) {
            if (blockView.hasDoubleSubstack()) {
                popup.getMenu().add(0, 2, 1, blockView.collapsed
                        ? R.string.block_expand_if
                        : R.string.block_collapse_if);
                popup.getMenu().add(0, 3, 2, blockView.collapsed2
                        ? R.string.block_expand_else
                        : R.string.block_collapse_else);
            } else {
                popup.getMenu().add(0, 2, 1, blockView.collapsed
                        ? R.string.block_expand
                        : R.string.block_collapse);
            }
        }
        popup.setOnMenuItemClickListener(item -> {
            switch (item.getItemId()) {
                case 1:
                    toggleBlockDisabled(blockView);
                    return true;
                case 2:
                    toggleBlockCollapsed(blockView);
                    return true;
                case 3:
                    toggleBlockCollapsed2(blockView);
                    return true;
            }
            return false;
        });
        popup.show();
    }

    private boolean isStatementBlock(BlockView blockView) {
        String type = blockView.blockType;
        return " ".equals(type) || "c".equals(type) || "e".equals(type) || "f".equals(type);
    }

    private void toggleBlockDisabled(BlockView blockView) {
        BlockBean before = blockView.getBean().clone();
        blockView.disabled = !blockView.disabled;
        for (BlockView child : blockView.getAllChildren()) {
            child.invalidate();
        }
        BlockHistoryManager.getInstance(scId).recordUpdate(buildHistoryKey(), before, blockView.getBean().clone());
        refreshOptionsMenu();
    }

    private void toggleBlockCollapsed(BlockView blockView) {
        BlockBean before = blockView.getBean().clone();
        blockView.setCollapsed(!blockView.collapsed);
        blockView.invalidate();
        blockView.blockPane.updatePaneSize();
        BlockHistoryManager.getInstance(scId).recordUpdate(buildHistoryKey(), before, blockView.getBean().clone());
        refreshOptionsMenu();
    }

    private void toggleBlockCollapsed2(BlockView blockView) {
        BlockBean before = blockView.getBean().clone();
        blockView.setCollapsed2(!blockView.collapsed2);
        blockView.invalidate();
        blockView.blockPane.updatePaneSize();
        BlockHistoryManager.getInstance(scId).recordUpdate(buildHistoryKey(), before, blockView.getBean().clone());
        refreshOptionsMenu();
    }

    public void setFieldValue(FieldBlockView fieldBlock, Object value) {
        BlockBean clone = fieldBlock.parentBlock.getBean().clone();
        fieldBlock.setArgValue(value);
        fieldBlock.parentBlock.recalculateToRoot();
        fieldBlock.parentBlock.getRootBlock().layoutChain();
        fieldBlock.parentBlock.blockPane.updatePaneSize();
        BlockHistoryManager.getInstance(scId).recordUpdate(buildHistoryKey(), clone, fieldBlock.parentBlock.getBean().clone());
        refreshOptionsMenu();
    }

    public void pickImage(FieldBlockView fieldBlock, String propertyKey) {
        boolean selectingBackgroundImage = "property_background_resource".equals(propertyKey);
        boolean selectingImage = !selectingBackgroundImage && "property_image".equals(propertyKey);
        AtomicReference<String> selectedImage = new AtomicReference<>("");

        SearchWithRecyclerViewBinding binding = SearchWithRecyclerViewBinding.inflate(getLayoutInflater());

        MaterialAlertDialogBuilder dialog = new MaterialAlertDialogBuilder(this);
        if (selectingImage) {
            dialog.setTitle(R.string.logic_editor_title_select_image);
        } else if (selectingBackgroundImage) {
            dialog.setTitle(R.string.logic_editor_title_select_image_background);
        }

        binding.recyclerView.setLayoutManager(new LinearLayoutManager(this));

        ArrayList<String> images = ProjectDataManager.getResourceManager(scId).getImageNames();
        images.addAll(new VectorDrawableLoader().getVectorDrawables(scId));
        if (selectingImage) {
            images.add(0, "default_image");
        } else if (selectingBackgroundImage) {
            images.add(0, "NONE");
        }

        ImagePickerAdapter adapter = new ImagePickerAdapter(images, (String) fieldBlock.getArgValue(), selectedImage::set);
        binding.recyclerView.setAdapter(adapter);


        binding.searchInput.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
            }

            @Override
            public void afterTextChanged(Editable s) {
                String query = s.toString().toLowerCase();
                adapter.filter(query);
            }
        });

        dialog.setPositiveButton(R.string.common_word_save, (v, which) -> {
            String selectedImg = selectedImage.get();
            if (!selectedImg.isEmpty()) {
                setFieldValue(fieldBlock, selectedImage.get());
            }
        });

        dialog.setView(binding.getRoot());
        dialog.setNegativeButton(R.string.common_word_cancel, null);
        dialog.show();
    }

    public void showNumberOrStringInput(FieldBlockView fieldBlock, boolean isNumber) {
        MaterialAlertDialogBuilder dialog = new MaterialAlertDialogBuilder(this);
        dialog.setTitle(isNumber ? R.string.logic_editor_title_enter_number_value : R.string.logic_editor_title_enter_string_value);
        View dialogView = ViewUtil.inflateLayout(this, R.layout.property_popup_input_text);
        EditText editText = dialogView.findViewById(R.id.ed_input);
        if (isNumber) {
            editText.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL | InputType.TYPE_NUMBER_FLAG_SIGNED);
            editText.setImeOptions(EditorInfo.IME_ACTION_DONE);
            editText.setMaxLines(1);
        } else {
            editText.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS | InputType.TYPE_TEXT_FLAG_MULTI_LINE);
            editText.setImeOptions(EditorInfo.IME_ACTION_NONE);
        }
        editText.setText(fieldBlock.getArgValue().toString());
        dialog.setView(dialogView);
        dialog.setPositiveButton(R.string.common_word_save, (v, which) -> {
            String text = Helper.getText(editText);
            emptyStringSetter:
            {
                if (isNumber) {
                    try {
                        double d = Double.parseDouble(text);
                        if (!Double.isNaN(d) && !Double.isInfinite(d)) {
                            break emptyStringSetter;
                        }
                    } catch (NumberFormatException e) {
                        LogUtil.e("LogicEditor", "", e);
                    }
                } else if (!text.isEmpty()) {
                    if (text.charAt(0) == '@') {
                        text = " " + text;
                        break emptyStringSetter;
                    }
                }

                text = "";
            }

            setFieldValue(fieldBlock, text);
            v.dismiss();
        });
        dialog.setNegativeButton(R.string.common_word_cancel, null);
        dialog.show();
    }

    public void connectBlock(BlockBean blockBean, boolean doLayout) {
        BlockView block = blockPane.findBlockByString(blockBean.id);
        if (block != null) {
            block.subStack1 = -1;
            block.subStack2 = -1;
            block.nextBlock = -1;

            for (int i = 0; i < blockBean.parameters.size() && i < block.childViews.size(); i++) {
                String parameter = blockBean.parameters.get(i);
                if (parameter != null) {
                    if (!parameter.isEmpty() && parameter.charAt(0) == '@') {
                        int blockId = Integer.parseInt(parameter.substring(1));
                        if (blockId > 0) {
                            BlockView parameterBlock = blockPane.findBlockById(blockId);
                            if (parameterBlock != null && block.childViews.get(i) instanceof BaseBlockView) {
                                block.replaceParameter((BaseBlockView) block.childViews.get(i), parameterBlock);
                            }
                        }
                    } else {
                        if (block.childViews.get(i) instanceof FieldBlockView ss) {
                            String javaName = projectFile.getJavaName();
                            String xmlName = projectFile.getXmlName();
                            if (eventName.equals("onBindCustomView")) {
                                var projectDataStore = ProjectDataManager.getProjectDataManager(scId);
                                var view = projectDataStore.getViewBean(xmlName, id);
                                if (view == null) {
                                    // Event is of a Drawer View
                                    view = projectDataStore.getViewBean("_drawer_" + xmlName, id);
                                }
                                String customView = view.customView;
                                if (customView != null) {
                                    xmlName = ProjectFileBean.getXmlName(customView);
                                }
                            }

                            if (!parameter.isEmpty()) {
                                if (ss.blockType.equals("m")) {
                                    ProjectDataStore projectDataStore = ProjectDataManager.getProjectDataManager(scId);

                                    switch (ss.componentType) {
                                        case "varInt":
                                            projectDataStore.hasVariable(javaName, ExtraMenuBean.VARIABLE_TYPE_NUMBER, parameter);
                                            break;

                                        case "varBool":
                                            projectDataStore.hasVariable(javaName, ExtraMenuBean.VARIABLE_TYPE_BOOLEAN, parameter);
                                            break;

                                        case "varStr":
                                            projectDataStore.hasVariable(javaName, ExtraMenuBean.VARIABLE_TYPE_STRING, parameter);
                                            break;

                                        case "listInt":
                                            projectDataStore.hasListVariable(javaName, ExtraMenuBean.LIST_TYPE_NUMBER, parameter);
                                            break;

                                        case "listStr":
                                            projectDataStore.hasListVariable(javaName, ExtraMenuBean.LIST_TYPE_STRING, parameter);
                                            break;

                                        case "listMap":
                                            projectDataStore.hasListVariable(javaName, ExtraMenuBean.LIST_TYPE_MAP, parameter);
                                            break;

                                        case "list":
                                            boolean hasListVar = projectDataStore.hasListVariable(javaName, ExtraMenuBean.LIST_TYPE_NUMBER, parameter);
                                            if (!hasListVar) {
                                                hasListVar = projectDataStore.hasListVariable(javaName, ExtraMenuBean.LIST_TYPE_STRING, parameter);
                                            }

                                            if (!hasListVar) {
                                                projectDataStore.hasListVariable(javaName, ExtraMenuBean.LIST_TYPE_MAP, parameter);
                                            }
                                            break;

                                        case "view":
                                            projectDataStore.hasView(xmlName, parameter);
                                            break;

                                        case "textview":
                                            projectDataStore.hasTextView(xmlName, parameter);
                                            break;

                                        case "checkbox":
                                            projectDataStore.hasCompoundButtonView(xmlName, parameter);
                                            break;

                                        case "imageview":
                                            projectDataStore.hasViewOfType(xmlName, ViewBean.VIEW_TYPE_WIDGET_IMAGEVIEW, parameter);
                                            break;

                                        case "seekbar":
                                            projectDataStore.hasViewOfType(xmlName, ViewBean.VIEW_TYPE_WIDGET_SEEKBAR, parameter);
                                            break;

                                        case "calendarview":
                                            projectDataStore.hasViewOfType(xmlName, ViewBean.VIEW_TYPE_WIDGET_CALENDARVIEW, parameter);
                                            break;

                                        case "adview":
                                            projectDataStore.hasViewOfType(xmlName, ViewBean.VIEW_TYPE_WIDGET_ADVIEW, parameter);
                                            break;

                                        case "listview":
                                            projectDataStore.hasViewOfType(xmlName, ViewBean.VIEW_TYPE_WIDGET_LISTVIEW, parameter);
                                            break;

                                        case "spinner":
                                            projectDataStore.hasViewOfType(xmlName, ViewBean.VIEW_TYPE_WIDGET_SPINNER, parameter);
                                            break;

                                        case "webview":
                                            projectDataStore.hasViewOfType(xmlName, ViewBean.VIEW_TYPE_WIDGET_WEBVIEW, parameter);
                                            break;

                                        case "switch":
                                            projectDataStore.hasViewOfType(xmlName, ViewBean.VIEW_TYPE_WIDGET_SWITCH, parameter);
                                            break;

                                        case "progressbar":
                                            projectDataStore.hasViewOfType(xmlName, ViewBean.VIEW_TYPE_WIDGET_PROGRESSBAR, parameter);
                                            break;

                                        case "mapview":
                                            projectDataStore.hasViewOfType(xmlName, ViewBean.VIEW_TYPE_WIDGET_MAPVIEW, parameter);
                                            break;

                                        case "intent":
                                            projectDataStore.hasComponent(javaName, ComponentBean.COMPONENT_TYPE_INTENT, parameter);
                                            break;

                                        case "file":
                                            projectDataStore.hasComponent(javaName, ComponentBean.COMPONENT_TYPE_SHAREDPREF, parameter);
                                            break;

                                        case "calendar":
                                            projectDataStore.hasComponent(javaName, ComponentBean.COMPONENT_TYPE_CALENDAR, parameter);
                                            break;

                                        case "timer":
                                            projectDataStore.hasComponent(javaName, ComponentBean.COMPONENT_TYPE_TIMERTASK, parameter);
                                            break;

                                        case "vibrator":
                                            projectDataStore.hasComponent(javaName, ComponentBean.COMPONENT_TYPE_VIBRATOR, parameter);
                                            break;

                                        case "dialog":
                                            projectDataStore.hasComponent(javaName, ComponentBean.COMPONENT_TYPE_DIALOG, parameter);
                                            break;

                                        case "mediaplayer":
                                            projectDataStore.hasComponent(javaName, ComponentBean.COMPONENT_TYPE_MEDIAPLAYER, parameter);
                                            break;

                                        case "soundpool":
                                            projectDataStore.hasComponent(javaName, ComponentBean.COMPONENT_TYPE_SOUNDPOOL, parameter);
                                            break;

                                        case "objectanimator":
                                            projectDataStore.hasComponent(javaName, ComponentBean.COMPONENT_TYPE_OBJECTANIMATOR, parameter);
                                            break;

                                        case "firebase":
                                            projectDataStore.hasComponent(javaName, ComponentBean.COMPONENT_TYPE_FIREBASE, parameter);
                                            break;

                                        case "firebaseauth":
                                            projectDataStore.hasComponent(javaName, ComponentBean.COMPONENT_TYPE_FIREBASE_AUTH, parameter);
                                            break;

                                        case "firebasestorage":
                                            projectDataStore.hasComponent(javaName, ComponentBean.COMPONENT_TYPE_FIREBASE_STORAGE, parameter);
                                            break;

                                        case "gyroscope":
                                            projectDataStore.hasComponent(javaName, ComponentBean.COMPONENT_TYPE_GYROSCOPE, parameter);
                                            break;

                                        case "interstitialad":
                                            projectDataStore.hasComponent(javaName, ComponentBean.COMPONENT_TYPE_INTERSTITIAL_AD, parameter);
                                            break;

                                        case "requestnetwork":
                                            projectDataStore.hasComponent(javaName, ComponentBean.COMPONENT_TYPE_REQUEST_NETWORK, parameter);
                                            break;

                                        case "texttospeech":
                                            projectDataStore.hasComponent(javaName, ComponentBean.COMPONENT_TYPE_TEXT_TO_SPEECH, parameter);
                                            break;

                                        case "speechtotext":
                                            projectDataStore.hasComponent(javaName, ComponentBean.COMPONENT_TYPE_SPEECH_TO_TEXT, parameter);
                                            break;

                                        case "bluetoothconnect":
                                            projectDataStore.hasComponent(javaName, ComponentBean.COMPONENT_TYPE_BLUETOOTH_CONNECT, parameter);
                                            break;

                                        case "locationmanager":
                                            projectDataStore.hasComponent(javaName, ComponentBean.COMPONENT_TYPE_LOCATION_MANAGER, parameter);
                                            break;

                                        case "resource_bg":
                                        case "resource":
                                            for (String imageName : ProjectDataManager.getResourceManager(scId).getImageNames()) {
                                                // Like this in vanilla Sketchware. Don't ask me why.
                                                //noinspection StatementWithEmptyBody
                                                if (parameter.equals(imageName)) {
                                                }
                                            }
                                            break;

                                        case "activity":
                                            for (String activityName : ProjectDataManager.getFileManager(scId).getJavaNames()) {
                                                // Like this in vanilla Sketchware. Don't ask me why.
                                                //noinspection StatementWithEmptyBody
                                                if (parameter.equals(activityName.substring(activityName.indexOf(".java")))) {
                                                }
                                            }
                                            break;

                                        case "sound":
                                            for (String soundName : ProjectDataManager.getResourceManager(scId).getSoundNames()) {
                                                // Like this in vanilla Sketchware. Don't ask me why.
                                                //noinspection StatementWithEmptyBody
                                                if (parameter.equals(soundName)) {
                                                }
                                            }
                                            break;

                                        case "videoad":
                                            projectDataStore.hasComponent(xmlName, ComponentBean.COMPONENT_TYPE_REWARDED_VIDEO_AD, parameter);
                                            break;

                                        case "progressdialog":
                                            projectDataStore.hasComponent(xmlName, ComponentBean.COMPONENT_TYPE_PROGRESS_DIALOG, parameter);
                                            break;

                                        case "datepickerdialog":
                                            projectDataStore.hasComponent(xmlName, ComponentBean.COMPONENT_TYPE_DATE_PICKER_DIALOG, parameter);
                                            break;

                                        case "timepickerdialog":
                                            projectDataStore.hasComponent(xmlName, ComponentBean.COMPONENT_TYPE_TIME_PICKER_DIALOG, parameter);
                                            break;

                                        case "notification":
                                            projectDataStore.hasComponent(xmlName, ComponentBean.COMPONENT_TYPE_NOTIFICATION, parameter);
                                            break;

                                        case "sqlite":
                                            projectDataStore.hasComponent(xmlName, ComponentBean.COMPONENT_TYPE_SQLITE, parameter);
                                            break;

                                        case "radiobutton":
                                            projectDataStore.hasViewOfType(xmlName, ViewBeans.VIEW_TYPE_WIDGET_RADIOBUTTON, parameter);
                                            break;

                                        case "ratingbar":
                                            projectDataStore.hasViewOfType(xmlName, ViewBeans.VIEW_TYPE_WIDGET_RATINGBAR, parameter);
                                            break;

                                        case "videoview":
                                            projectDataStore.hasViewOfType(xmlName, ViewBeans.VIEW_TYPE_WIDGET_VIDEOVIEW, parameter);
                                            break;

                                        case "searchview":
                                            projectDataStore.hasViewOfType(xmlName, ViewBeans.VIEW_TYPE_WIDGET_SEARCHVIEW, parameter);
                                            break;

                                        case "actv":
                                            projectDataStore.hasViewOfType(xmlName, ViewBeans.VIEW_TYPE_WIDGET_AUTOCOMPLETETEXTVIEW, parameter);
                                            break;

                                        case "mactv":
                                            projectDataStore.hasViewOfType(xmlName, ViewBeans.VIEW_TYPE_WIDGET_MULTIAUTOCOMPLETETEXTVIEW, parameter);
                                            break;

                                        case "gridview":
                                            projectDataStore.hasViewOfType(xmlName, ViewBeans.VIEW_TYPE_WIDGET_GRIDVIEW, parameter);
                                            break;

                                        case "tablayout":
                                            projectDataStore.hasViewOfType(xmlName, ViewBeans.VIEW_TYPE_LAYOUT_TABLAYOUT, parameter);
                                            break;

                                        case "viewpager":
                                            projectDataStore.hasViewOfType(xmlName, ViewBeans.VIEW_TYPE_LAYOUT_VIEWPAGER, parameter);
                                            break;

                                        case "bottomnavigation":
                                            projectDataStore.hasViewOfType(xmlName, ViewBeans.VIEW_TYPE_LAYOUT_BOTTOMNAVIGATIONVIEW, parameter);
                                            break;

                                        case "badgeview":
                                            projectDataStore.hasViewOfType(xmlName, ViewBeans.VIEW_TYPE_WIDGET_BADGEVIEW, parameter);
                                            break;

                                        case "patternview":
                                            projectDataStore.hasViewOfType(xmlName, ViewBeans.VIEW_TYPE_WIDGET_PATTERNLOCKVIEW, parameter);
                                            break;

                                        case "sidebar":
                                            projectDataStore.hasViewOfType(xmlName, ViewBeans.VIEW_TYPE_WIDGET_WAVESIDEBAR, parameter);
                                            break;

                                        default:
                                            extraPaletteBlock.hasExtraComponent(ss.componentType, parameter);
                                    }
                                }
                            }

                            ss.setArgValue(parameter);
                            block.recalculateToRoot();
                        }
                    }
                }
            }

            int subStack1RootBlockId = blockBean.subStack1;
            if (subStack1RootBlockId >= 0) {
                BlockView subStack1RootBlock = blockPane.findBlockById(subStack1RootBlockId);
                if (subStack1RootBlock != null) {
                    block.setSubstack1Block(subStack1RootBlock);
                }
            }

            int subStack2RootBlockId = blockBean.subStack2;
            if (subStack2RootBlockId >= 0) {
                BlockView subStack2RootBlock = blockPane.findBlockById(subStack2RootBlockId);
                if (subStack2RootBlock != null) {
                    block.setSubstack2Block(subStack2RootBlock);
                }
            }

            int nextBlockId = blockBean.nextBlock;
            if (nextBlockId >= 0) {
                BlockView nextBlock = blockPane.findBlockById(nextBlockId);
                if (nextBlock != null) {
                    block.setNextBlock(nextBlock);
                    block.recalculateToRoot();
                }
            }

            block.disabled = blockBean.disabled;
            if (block.hasSubstack() && block.collapsed != blockBean.collapsed) {
                block.setCollapsed(blockBean.collapsed);
            }
            if (block.hasDoubleSubstack() && block.collapsed2 != blockBean.collapsed2) {
                block.setCollapsed2(blockBean.collapsed2);
            }
            block.recalculateToRoot();
            if (doLayout) {
                block.getRootBlock().layoutChain();
                blockPane.updatePaneSize();
            }
            for (BlockView child : block.getAllChildren()) {
                child.invalidate();
            }
        }
    }

    public void addPaletteCategory(String categoryName, int i) {
        if (paletteBuildInterceptor != null) {
            paletteBuildInterceptor.addPaletteCategory(categoryName, i);
            return;
        }
        paletteBlock.addCategoryHeader(categoryName, i);
    }

    public void saveBlockToCollection(String collectionName, BlockView rs) {
        ArrayList<String> paramsList;
        ArrayList<BlockView> allChildren = rs.getAllChildren();
        ArrayList<BlockBean> collectionBlocks = new ArrayList<>();
        for (BlockView child : allChildren) {
            BlockBean blockBean = new BlockBean();
            BlockBean bean = child.getBean();
            blockBean.copy(bean);
            blockBean.id = String.format("99%06d", Integer.valueOf(bean.id));
            int subStack1Val = bean.subStack1;
            if (subStack1Val > 0) {
                blockBean.subStack1 = subStack1Val + 99000000;
            }
            int subStack2Val = bean.subStack2;
            if (subStack2Val > 0) {
                blockBean.subStack2 = subStack2Val + 99000000;
            }
            int nextBlockVal = bean.nextBlock;
            if (nextBlockVal > 0) {
                blockBean.nextBlock = nextBlockVal + 99000000;
            }
            blockBean.parameters.clear();
            for (String next : bean.parameters) {
                if (next.length() <= 1 || next.charAt(0) != '@') {
                    paramsList = blockBean.parameters;
                } else {
                    String format = String.format("99%06d", Integer.valueOf(next.substring(1)));
                    paramsList = blockBean.parameters;
                    next = '@' + format;
                }
                paramsList.add(next);
            }
            collectionBlocks.add(blockBean);
        }
        try {
            BlockCollectionManager.getInstance().addBlock(collectionName, collectionBlocks, true);
            editorDrawer.addBlockCollection(collectionName, collectionBlocks).setOnTouchListener(this);
        } catch (Exception e) {
            if (crashlytics != null) crashlytics.recordException(e);
        }
    }

    public void setCopyActive(boolean active) {
        logicTopMenu.setCopyActive(active);
    }

    public final boolean hitTestCopy(float x, float y) {
        return logicTopMenu.isInsideCopyArea(x, y);
    }

    public final boolean isBlockValid(BlockBean blockBean) {
        if (blockBean.opCode.equals("getArg")) {
            return true;
        }
        if (blockBean.opCode.equals("definedFunc")) {
            Iterator<Pair<String, String>> it = ProjectDataManager.getProjectDataManager(scId).getMoreBlocks(projectFile.getJavaName()).iterator();
            boolean found = false;
            while (it.hasNext()) {
                if (blockBean.spec.equals(ReturnMoreblockManager.getMbName(it.next().second))) {
                    found = true;
                }
            }
            return found;
        }
        return true;
    }

    public BlockView createBlockView(BlockBean blockBean) {
        BlockView blockView = new BlockView(this, Integer.parseInt(blockBean.id), blockBean.spec, blockBean.type, blockBean.typeName, blockBean.opCode);
        blockView.disabled = blockBean.disabled;
        return blockView;
    }

    private RadioButton getFontRadioButton(String fontName) {
        RadioButton radioButton = new RadioButton(this);
        radioButton.setText("");
        radioButton.setTag(fontName);
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, (int) (ViewUtil.dpToPx(this, 1.0f) * 60.0f));
        radioButton.setGravity(Gravity.CENTER | Gravity.LEFT);
        radioButton.setLayoutParams(layoutParams);
        return radioButton;
    }

    public void addVariable(int i, String variableName) {
        ProjectDataManager.getProjectDataManager(scId).addVariable(projectFile.getJavaName(), i, variableName);
        onBlockSizeChanged(0, ContextCompat.getColor(this, R.color.palette_variable));
    }

    public void deleteBlock(BlockView rs) {
        blockPane.removeBlockTree(rs);
    }

    public void showColorPicker(FieldBlockView fieldBlock) {
        ColorPickerDialog colorPickerDialog = new ColorPickerDialog(this, (fieldBlock.getArgValue() == null || fieldBlock.getArgValue().toString().isEmpty()) ? "Color.TRANSPARENT" : fieldBlock.getArgValue().toString().replace("0xFF", "#"), true, false, scId);
        colorPickerDialog.setColorPickerCallback(new ColorPickerDialog.OnColorPickedListener() {
            @Override
            public void onColorPicked(int color) {
                if (color == 0) {
                    LogicEditorActivity.this.setFieldValue(fieldBlock, "Color.TRANSPARENT");
                } else {
                    LogicEditorActivity.this.setFieldValue(fieldBlock, String.format("0x%08X", color & (Color.WHITE)));
                }
            }

            @Override
            public void onResourceColorPicked(String resourceName, int color) {
                LogicEditorActivity.this.setFieldValue(fieldBlock, "R.color." + resourceName);
            }
        });
        colorPickerDialog.materialColorAttr((attr, attrColor) -> setFieldValue(fieldBlock, "R.attr." + attr));
        colorPickerDialog.showAtLocation(fieldBlock, Gravity.CENTER, 0, 0);
    }

    public void addPaletteLabel(String label, String tag) {
        if (paletteBuildInterceptor != null) {
            paletteBuildInterceptor.addPaletteLabel(label, tag, this);
            return;
        }
        TextView textView = paletteBlock.addActionLabel(label);
        textView.setTag(tag);
        textView.setSoundEffectsEnabled(true);
        textView.setOnClickListener(this);
    }

    public void addPaletteLabelWithListener(String label, String tag, View.OnClickListener onClickListener) {
        if (paletteBuildInterceptor != null) {
            paletteBuildInterceptor.addPaletteLabel(label, tag, onClickListener);
            return;
        }
        TextView textView = paletteBlock.addActionLabel(label);
        textView.setTag(tag);
        textView.setSoundEffectsEnabled(true);
        textView.setOnClickListener(onClickListener);
    }

    public void setPaletteBuildInterceptor(PaletteBuildInterceptor paletteBuildInterceptor) {
        this.paletteBuildInterceptor = paletteBuildInterceptor;
    }

    public void activeIconDelete(boolean showDeleteIcon) {
        logicTopMenu.setDeleteActive(showDeleteIcon);
    }

    public final boolean hitTestIconDelete(float x, float y) {
        return logicTopMenu.isInsideDeleteArea(x, y);
    }

    public void showSaveToFavorites(BlockView rs) {
        MaterialAlertDialogBuilder dialog = new MaterialAlertDialogBuilder(this);
        dialog.setTitle(R.string.logic_block_favorites_save_title);
        View dialogView = ViewUtil.inflateLayout(this, R.layout.property_popup_save_to_favorite);
        ((TextView) dialogView.findViewById(R.id.tv_favorites_guide)).setText(R.string.logic_block_favorites_save_guide);
        EditText editText = dialogView.findViewById(R.id.ed_input);
        editText.setPrivateImeOptions("defaultInputmode=english;");
        editText.setLines(1);
        editText.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        editText.setImeOptions(EditorInfo.IME_ACTION_DONE);
        UniqueNameValidator blockNameValidator = new UniqueNameValidator(this, dialogView.findViewById(R.id.ti_input), BlockCollectionManager.getInstance().getBlockNames());
        dialog.setView(dialogView);
        dialog.setPositiveButton(R.string.common_word_save, (v, which) -> {
            if (blockNameValidator.isValid()) {
                saveBlockToCollection(Helper.getText(editText), rs);
                v.dismiss();
            }
        });
        dialog.setNegativeButton(R.string.common_word_cancel, null);
        dialog.show();
    }

    public void showStringInput(FieldBlockView fieldBlock) {
        MaterialAlertDialogBuilder dialog = new MaterialAlertDialogBuilder(this);
        dialog.setTitle(R.string.logic_editor_title_enter_string_value);
        View dialogView = ViewUtil.inflateLayout(this, R.layout.property_popup_input_text);
        ((TextInputLayout) dialogView.findViewById(R.id.ti_input)).setHint(Helper.getResString(R.string.property_hint_enter_value));
        EditText editText = dialogView.findViewById(R.id.ed_input);
        editText.setSingleLine(true);
        editText.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS | InputType.TYPE_TEXT_VARIATION_WEB_EMAIL_ADDRESS);
        editText.setImeOptions(EditorInfo.IME_ACTION_DONE);
        editText.setText(fieldBlock.getArgValue().toString());
        dialog.setView(dialogView);
        dialog.setPositiveButton(R.string.common_word_save, (v, which) -> {
            setFieldValue(fieldBlock, Helper.getText(editText));
            v.dismiss();
        });
        dialog.setNegativeButton(R.string.common_word_cancel, null);
        dialog.show();
    }

    public void addMoreBlock(String name, String spec) {
        ProjectDataManager.getProjectDataManager(scId).addMoreBlock(projectFile.getJavaName(), name, spec);
        onBlockSizeChanged(8, ContextCompat.getColor(this, R.color.palette_more_block));
    }

    public void setDetailActive(boolean active) {
        logicTopMenu.setDetailActive(active);
    }

    public final boolean hitTestDetail(float x, float y) {
        return logicTopMenu.isInsideDetailArea(x, y);
    }

    private LinearLayout getFontPreview(String fontName) {
        LinearLayout linearLayout = new LinearLayout(this);
        linearLayout.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, (int) (ViewUtil.dpToPx(this, 1.0f) * 60.0f)));
        linearLayout.setGravity(Gravity.CENTER | Gravity.LEFT);
        linearLayout.setOrientation(LinearLayout.HORIZONTAL);
        TextView name = new TextView(this);
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT);
        layoutParams.weight = 1.0f;
        name.setLayoutParams(layoutParams);
        name.setText(fontName);
        linearLayout.addView(name);
        TextView preview = new TextView(this);
        preview.setLayoutParams(layoutParams);
        preview.setText(Helper.getResString(R.string.font_preview));

        Typeface typeface;
        if (fontName.equalsIgnoreCase("default_font")) {
            typeface = Typeface.DEFAULT;
        } else {
            try {
                typeface = Typeface.createFromFile(ProjectDataManager.getResourceManager(scId).getFontPath(fontName));
            } catch (RuntimeException e) {
                if (crashlytics != null) {
                    crashlytics.log("Loading font preview");
                    crashlytics.recordException(e);
                }
                typeface = Typeface.DEFAULT;
                preview.setText(Helper.getResString(R.string.font_load_failed));
            }
        }

        preview.setTypeface(typeface);
        linearLayout.addView(preview);
        return linearLayout;
    }

    public RadioButton createViewRadioButton(String type, String id) {
        if (isViewBindingEnabled) {
            id = ViewBindingBuilder.generateParameterFromId(id);
        }
        RadioButton radioButton = new RadioButton(this);
        radioButton.setText(type + " : " + id);
        radioButton.setTag(id);
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, (int) (ViewUtil.dpToPx(this, 1.0f) * 40.0f));
        radioButton.setGravity(Gravity.CENTER | Gravity.LEFT);
        radioButton.setLayoutParams(layoutParams);
        return radioButton;
    }

    public void showFontPicker(FieldBlockView fieldBlock) {
        MaterialAlertDialogBuilder dialog = new MaterialAlertDialogBuilder(this);
        dialog.setTitle(R.string.logic_editor_title_select_font);

        View customView = ViewUtil.inflateLayout(this, R.layout.property_popup_selector_color);
        RadioGroup radioGroup = customView.findViewById(R.id.rg);
        LinearLayout linearLayout = customView.findViewById(R.id.content);
        ArrayList<String> fontNames = ProjectDataManager.getResourceManager(scId).getFontNames();
        fontNames.add(0, "default_font");
        for (String fontName : fontNames) {
            RadioButton font = getFontRadioButton(fontName);
            radioGroup.addView(font);
            if (fontName.equals(fieldBlock.getArgValue())) {
                font.setChecked(true);
            }
            LinearLayout fontPreview = getFontPreview(fontName);
            fontPreview.setOnClickListener(v -> font.setChecked(true));
            linearLayout.addView(fontPreview);
        }

        dialog.setView(customView);
        dialog.setPositiveButton(R.string.common_word_select, (v, which) -> {
            for (int i = 0; i < radioGroup.getChildCount(); i++) {
                RadioButton radioButton = (RadioButton) radioGroup.getChildAt(i);
                if (radioButton.isChecked()) {
                    setFieldValue(fieldBlock, radioButton.getTag());
                    break;
                }
            }
            v.dismiss();
        });
        dialog.setNegativeButton(R.string.common_word_cancel, null);
        dialog.show();
    }

    public void setFavoriteActive(boolean active) {
        logicTopMenu.setFavoriteActive(active);
    }

    public final boolean hitTestFavorite(float x, float y) {
        return logicTopMenu.isInsideFavoriteArea(x, y);
    }

    public final RadioButton createRadioButton(String text) {
        RadioButton radioButton = new RadioButton(this);
        radioButton.setText(text);
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        layoutParams.topMargin = (int) ViewUtil.dpToPx(getContext(), 4.0f);
        layoutParams.bottomMargin = (int) ViewUtil.dpToPx(getContext(), 4.0f);
        radioButton.setGravity(Gravity.CENTER | Gravity.LEFT);
        radioButton.setLayoutParams(layoutParams);
        return radioButton;
    }

    public final CheckBox createCheckBox(String text) {
        CheckBox checkBox = new CheckBox(this);
        checkBox.setText(text);
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        layoutParams.topMargin = (int) ViewUtil.dpToPx(getContext(), 4.0f);
        layoutParams.bottomMargin = (int) ViewUtil.dpToPx(getContext(), 4.0f);
        checkBox.setGravity(Gravity.CENTER | Gravity.LEFT);
        checkBox.setLayoutParams(layoutParams);
        return checkBox;
    }

    public void showIntentDataInput(FieldBlockView fieldBlock) {
        MaterialAlertDialogBuilder dialog = new MaterialAlertDialogBuilder(this);
        dialog.setTitle(R.string.logic_editor_title_enter_data_value);
        View dialogView = ViewUtil.inflateLayout(this, R.layout.property_popup_input_intent_data);
        ((TextView) dialogView.findViewById(R.id.tv_desc_intent_usage)).setText(Helper.getResString(R.string.property_description_component_intent_usage));
        EditText editText = dialogView.findViewById(R.id.ed_input);
        ((TextInputLayout) dialogView.findViewById(R.id.ti_input)).setHint(Helper.getResString(R.string.property_hint_enter_value));
        editText.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        editText.setText(fieldBlock.getArgValue().toString());
        dialog.setView(dialogView);
        dialog.setPositiveButton(R.string.common_word_save, (v, which) -> {
            setFieldValue(fieldBlock, Helper.getText(editText));
            v.dismiss();
        });
        dialog.setNegativeButton(R.string.common_word_cancel, null);
        dialog.show();
    }

    public void togglePaletteVisibility(boolean visible) {
        ObjectAnimator objectAnimator;
        if (!paletteAnimatorsInitialized) {
            setupPaletteAnimators(getResources().getConfiguration().orientation);
        }
        if (isPaletteVisible == visible) {
            return;
        }
        isPaletteVisible = visible;
        if (visible && isCanvasSearchActive) {
            closeCanvasSearch();
        }
        cancelPaletteAnimations();
        if (visible) {
            toggleDrawerVisibility(false);
            objectAnimator = paletteShowAnimator;
            if (!paletteBlocksInitialized) {
                paletteBlocksInitialized = true;
                paletteBlock.post(() -> onBlockSizeChanged(0, ContextCompat.getColor(this, R.color.palette_variable)));
            }
        } else {
            objectAnimator = paletteHideAnimator;
        }
        objectAnimator.start();
        layoutEditorForOrientation(getResources().getConfiguration().orientation);
    }

    public void layoutEditorForOrientation(int i) {
        LinearLayout.LayoutParams layoutParams;
        int editorHeight;
        int editorWidth = ViewGroup.LayoutParams.MATCH_PARENT;
        if (isPaletteVisible) {
            int width = getResources().getDisplayMetrics().widthPixels;
            int height = getResources().getDisplayMetrics().heightPixels;
            if (width <= height) {
                width = height;
            }
            if (2 == i) {
                editorWidth = width - ((int) ViewUtil.dpToPx(this, 320.0f));
                editorHeight = ViewGroup.LayoutParams.MATCH_PARENT;
            } else {
                editorHeight = viewLogicEditor.getHeight() - paletteArea.getHeight();
            }
            layoutParams = new LinearLayout.LayoutParams(editorWidth, editorHeight);
        } else {
            layoutParams = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
        }
        viewLogicEditor.setLayoutParams(layoutParams);
        viewLogicEditor.requestLayout();
    }

    public void showViewSelector(FieldBlockView fieldBlock) {
        MaterialAlertDialogBuilder dialog = new MaterialAlertDialogBuilder(this);
        View customView = ViewUtil.inflateLayout(this, R.layout.property_popup_selector_single);
        ViewGroup viewGroup = customView.findViewById(R.id.rg_content);
        String xmlName = projectFile.getXmlName();

        if (eventName.equals("onBindCustomView")) {
            var projectDataStore = ProjectDataManager.getProjectDataManager(scId);
            var view = projectDataStore.getViewBean(xmlName, id);
            if (view == null) {
                view = projectDataStore.getViewBean("_drawer_" + xmlName, id);
            }
            if (view != null && view.customView != null) {
                xmlName = ProjectFileBean.getXmlName(view.customView);
            }
        }

        dialog.setTitle(R.string.logic_editor_title_select_view);
        ArrayList<ViewBean> views = ProjectDataManager.getProjectDataManager(scId).getViews(xmlName);
        for (ViewBean viewBean : views) {
            String convert = viewBean.convert;
            String typeName = convert.isEmpty() ? ViewBean.getViewTypeName(viewBean.type) : IdGenerator.getLastPath(convert);
            if (!convert.equals("include")) {
                Set<String> toNotAdd = new LayoutGenerator(new BuildConfig(), projectFile).readAttributesToReplace(viewBean);
                if (!toNotAdd.contains("android:id")) {
                    String classInfo = fieldBlock.getClassInfo().getClassName();
                    if ((classInfo.equals("CheckBox") && viewBean.getClassInfo().matchesType("CompoundButton")) || viewBean.getClassInfo().matchesType(classInfo)) {
                        viewGroup.addView(createViewRadioButton(typeName, viewBean.id));
                    }
                }
                ExtraMenuBean.setupSearchView(customView, viewGroup);
            }
        }

        for (int i = 0; i < viewGroup.getChildCount(); i++) {
            RadioButton radioButton = (RadioButton) viewGroup.getChildAt(i);
            String argValue = fieldBlock.getArgValue().toString();
            if (argValue.equals(radioButton.getTag().toString())) {
                radioButton.setChecked(true);
                break;
            }
        }

        dialog.setView(customView);
        dialog.setNeutralButton(R.string.common_word_code_editor, (v, which) -> {
            AsdDialog editor = new AsdDialog(this);
            editor.setContent(fieldBlock.getArgValue().toString());
            editor.show();
            editor.setOnSaveClickListener(this, false, fieldBlock, editor);
            editor.setOnCancelClickListener(editor);
            v.dismiss();
        });
        dialog.setPositiveButton(R.string.common_word_select, (v, which) -> {
            for (int i = 0; i < viewGroup.getChildCount(); i++) {
                RadioButton radioButton = (RadioButton) viewGroup.getChildAt(i);
                if (radioButton.isChecked()) {
                    setFieldValue(fieldBlock, radioButton.getTag());
                    break;
                }
            }
            v.dismiss();
        });
        dialog.setNegativeButton(R.string.common_word_cancel, null);
        dialog.show();
    }

    public void toggleLayoutVisibility(boolean visible) {
        logicTopMenu.toggleLayoutVisibility(visible);
    }

    @Override
    public void finish() {
        BlockHistoryManager.getInstance(scId).removeHistory(buildHistoryKey());
        super.finish();
    }

    private Context getContext() {
        return this;
    }

    public void handleOrientationChange(int i) {
        RelativeLayout.LayoutParams layoutParams;
        int orientation;
        if (2 == i) {
            paletteArea.setLayoutParams(new LinearLayout.LayoutParams((int) ViewUtil.dpToPx(this, 320.0f), ViewGroup.LayoutParams.MATCH_PARENT));
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            params.gravity = Gravity.CENTER | Gravity.BOTTOM;
            int dimension = (int) getResources().getDimension(R.dimen.action_button_margin);
            params.setMargins(dimension, dimension, dimension, dimension);
            openBlocksMenuButton.setLayoutParams(params);
            layoutParams = new RelativeLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT);
            layoutParams.addRule(RelativeLayout.ALIGN_PARENT_TOP);
            layoutParams.addRule(RelativeLayout.ALIGN_PARENT_RIGHT);
            layoutParams.topMargin = DeviceUtil.getToolbarHeight(getContext());
            orientation = LinearLayout.HORIZONTAL;
        } else {
            paletteArea.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, (int) ViewUtil.dpToPx(this, 240.0f)));
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            params.gravity = Gravity.CENTER | Gravity.RIGHT;
            int buttonMargin = (int) getResources().getDimension(R.dimen.action_button_margin);
            params.setMargins(buttonMargin, buttonMargin, buttonMargin, buttonMargin);
            openBlocksMenuButton.setLayoutParams(params);
            layoutParams = new RelativeLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            layoutParams.addRule(RelativeLayout.ALIGN_PARENT_LEFT);
            layoutParams.addRule(RelativeLayout.ALIGN_PARENT_BOTTOM);
            orientation = LinearLayout.VERTICAL;
        }
        paletteLayout.setOrientation(orientation);
        paletteLayout.setLayoutParams(layoutParams);
        setupPaletteAnimators(i);
        layoutEditorForOrientation(i);
    }

    public void toggleDrawerVisibility(boolean visible) {
        if (!drawerAnimatorsInitialized) {
            initDrawerAnimators();
        }
        if (isDrawerVisible != visible) {
            isDrawerVisible = visible;
            cancelDrawerAnimations();
            (visible ? drawerShowAnimator : drawerHideAnimator).start();
        }
    }

    public void setupPaletteAnimators(int i) {
        boolean wasPaletteVisible = isPaletteVisible;
        if (i == 2) {
            if (!wasPaletteVisible) {
                paletteLayout.setTranslationX(ViewUtil.dpToPx(this, 320.0F));
            } else {
                paletteLayout.setTranslationX(0.0F);
            }
            paletteLayout.setTranslationY(0.0F);
        } else {
            if (!wasPaletteVisible) {
                paletteLayout.setTranslationX(0.0F);
                paletteLayout.setTranslationY(ViewUtil.dpToPx(this, 240.0F));
            } else {
                paletteLayout.setTranslationX(0.0F);
                paletteLayout.setTranslationY(0.0F);
            }
        }

        if (i == 2) {
            paletteShowAnimator = ObjectAnimator.ofFloat(paletteLayout, View.TRANSLATION_X, 0.0F);
            paletteHideAnimator = ObjectAnimator.ofFloat(paletteLayout, View.TRANSLATION_X, ViewUtil.dpToPx(this, 320.0F));
        } else {
            paletteShowAnimator = ObjectAnimator.ofFloat(paletteLayout, View.TRANSLATION_Y, 0.0F);
            paletteHideAnimator = ObjectAnimator.ofFloat(paletteLayout, View.TRANSLATION_Y, ViewUtil.dpToPx(this, 240.0F));
        }

        paletteShowAnimator.setDuration(500L);
        paletteShowAnimator.setInterpolator(new DecelerateInterpolator());
        paletteHideAnimator.setDuration(300L);
        paletteHideAnimator.setInterpolator(new DecelerateInterpolator());
        paletteAnimatorsInitialized = true;
    }

    public void showSoundPicker(FieldBlockView fieldBlock) {
        MaterialAlertDialogBuilder dialog = new MaterialAlertDialogBuilder(this);
        dialog.setTitle(R.string.logic_editor_title_select_sound);

        View customView = ViewUtil.inflateLayout(this, R.layout.property_popup_selector_single);
        RadioGroup radioGroup = customView.findViewById(R.id.rg_content);
        SoundPool soundPool = new SoundPool.Builder()
                .setMaxStreams(1)
                .setAudioAttributes(new AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                        .build())
                .build();
        soundPool.setOnLoadCompleteListener((pool, sampleId, status) -> {
            if (pool != null) {
                pool.play(sampleId, 1, 1, 1, 0, 1);
            }
        });

        for (String soundName : ProjectDataManager.getResourceManager(scId).getSoundNames()) {
            RadioButton sound = createRadioButton(soundName);
            radioGroup.addView(sound);
            if (soundName.equals(fieldBlock.getArgValue())) {
                sound.setChecked(true);
            }
            sound.setOnClickListener(v -> soundPool.load(ProjectDataManager.getResourceManager(scId).getSoundPath(Helper.getText(sound)), 1));
        }
        dialog.setView(customView);
        dialog.setPositiveButton(R.string.common_word_select, (v, which) -> {
            RadioButton checkedRadioButton = radioGroup.findViewById(radioGroup.getCheckedRadioButtonId());
            setFieldValue(fieldBlock, Helper.getText(checkedRadioButton));
            v.dismiss();
        });
        dialog.setNegativeButton(R.string.common_word_cancel, null);
        dialog.show();
    }

    public void toggleTopMenuVisibility(boolean visible) {
        logicTopMenu.setDeleteActive(false);
        logicTopMenu.setCopyActive(false);
        logicTopMenu.setFavoriteActive(false);
        logicTopMenu.setDetailActive(false);
        if (!topMenuAnimatorsInitialized) {
            initTopMenuAnimators();
        }
        if (isTopMenuVisible == visible) {
            return;
        }
        isTopMenuVisible = visible;
        cancelTopMenuAnimations();
        (visible ? topMenuShowAnimator : topMenuHideAnimator).start();
    }

    public void showTypefaceSelector(FieldBlockView fieldBlock) {
        MaterialAlertDialogBuilder dialog = new MaterialAlertDialogBuilder(this);
        dialog.setTitle(R.string.logic_editor_title_select_typeface);
        View dialogView = ViewUtil.inflateLayout(this, R.layout.property_popup_selector_single);
        RadioGroup radioGroup = dialogView.findViewById(R.id.rg_content);
        for (Pair<Integer, String> pair : SketchwareConstants.getPropertyPairs("property_text_style")) {
            RadioButton radioButton = createRadioButton(pair.second);
            radioGroup.addView(radioButton);
            if (pair.second.equals(fieldBlock.getArgValue())) {
                radioButton.setChecked(true);
            }
        }
        dialog.setView(dialogView);
        dialog.setPositiveButton(R.string.common_word_save, (v, which) -> {
            int childCount = radioGroup.getChildCount();
            for (int i = 0; i < childCount; i++) {
                RadioButton radioButton = (RadioButton) radioGroup.getChildAt(i);
                if (radioButton.isChecked()) {
                    setFieldValue(fieldBlock, Helper.getText(radioButton));
                    break;
                }
            }

            v.dismiss();
        });
        dialog.setNegativeButton(R.string.common_word_cancel, null);
        dialog.show();
    }

    public void cancelDrawerAnimations() {
        if (drawerShowAnimator.isRunning()) {
            drawerShowAnimator.cancel();
        }
        if (drawerHideAnimator.isRunning()) {
            drawerHideAnimator.cancel();
        }
    }

    public void removeListVariable(String variableName) {
        ProjectDataManager.getProjectDataManager(scId).removeListVariable(projectFile.getJavaName(), variableName);
        onBlockSizeChanged(1, ContextCompat.getColor(this, R.color.palette_list));
    }

    public void cancelTopMenuAnimations() {
        if (topMenuShowAnimator.isRunning()) {
            topMenuShowAnimator.cancel();
        }
        if (topMenuHideAnimator.isRunning()) {
            topMenuHideAnimator.cancel();
        }
    }

    public void removeVariable(String variableName) {
        ProjectDataManager.getProjectDataManager(scId).removeVariable(projectFile.getJavaName(), variableName);
        onBlockSizeChanged(0, ContextCompat.getColor(this, R.color.palette_variable));
    }

    public void renameVariable(String oldName, String newName) {
        saveBlocks();
        ProjectDataManager.getProjectDataManager(scId).renameVariable(projectFile.getJavaName(), oldName, newName);
        onBlockSizeChanged(0, ContextCompat.getColor(this, R.color.palette_variable));
    }

    public void renameListVariable(String oldName, String newName) {
        saveBlocks();
        ProjectDataManager.getProjectDataManager(scId).renameListVariable(projectFile.getJavaName(), oldName, newName);
        onBlockSizeChanged(1, ContextCompat.getColor(this, R.color.palette_list));
    }

    public void cancelPaletteAnimations() {
        if (paletteShowAnimator.isRunning()) {
            paletteShowAnimator.cancel();
        }
        if (paletteHideAnimator.isRunning()) {
            paletteHideAnimator.cancel();
        }
    }

    public void showDeleteFavoriteDialog(String blockName) {
        MaterialAlertDialogBuilder dialog = new MaterialAlertDialogBuilder(this);
        dialog.setTitle(R.string.logic_block_favorites_delete_title);
        dialog.setMessage(R.string.logic_block_favorites_delete_message);
        dialog.setPositiveButton(R.string.common_word_delete, (v, which) -> {
            BlockCollectionManager.getInstance().removeBlock(blockName, true);
            editorDrawer.removeBlockCollection(blockName);
            v.dismiss();
        });
        dialog.setNegativeButton(R.string.common_word_cancel, null);
        dialog.show();
    }

    public void showBlockCollection(String blockName) {
        Intent intent = new Intent(getContext(), ShowBlockCollectionActivity.class);
        intent.putExtra("block_name", blockName);
        startActivity(intent);
    }

    public boolean isDrawerEnabled() {
        return true;
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode == Activity.RESULT_OK) {
            if (requestCode == 224) {
                onBlockSizeChanged(7, ContextCompat.getColor(this, R.color.palette_component));
            }
        }
    }

    @Override
    public void onClick(View v) {
        if (!UIHelper.isClickThrottled()) {
            Object tag = v.getTag();
            if (tag != null) {
                if (tag.equals("variableAdd")) {
                    showAddNewVariableDialog();
                } else if (tag.equals("openResourcesEditor")) {
                    openResourcesEditor();
                } else if (tag.equals("listAdd")) {
                    showAddListDialog();
                } else if (tag.equals("blockAdd")) {
                    Intent intent = new Intent(this, MakeBlockActivity.class);
                    intent.putExtra("sc_id", scId);
                    intent.putExtra("project_file", projectFile);
                    intent.setFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP);
                    makeBlockLauncher.launch(intent);
                } else if (tag.equals("componentAdd")) {
                    AddComponentBottomSheet addComponentBottomSheet = AddComponentBottomSheet.newInstance(scId, projectFile, () -> onBlockSizeChanged(7, ContextCompat.getColor(this, R.color.palette_component)));
                    addComponentBottomSheet.show(getSupportFragmentManager(), null);
                } else if (tag.equals("blockImport")) {
                    showMoreBlockImporter();
                }
            }
            int id = v.getId();
            if (id == R.id.btn_delete) {
                setResult(Activity.RESULT_OK, new Intent());
                finish();
            } else if (id == R.id.btn_cancel) {
                setResult(Activity.RESULT_CANCELED);
                finish();
            }
        }
    }

    @Override
    public void onConfigurationChanged(@NonNull Configuration configuration) {
        super.onConfigurationChanged(configuration);
        handleOrientationChange(configuration.orientation);
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        lastSelectedPaletteColor = ContextCompat.getColor(this, R.color.palette_variable);
        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                if (isDrawerVisible) {
                    toggleDrawerVisibility(false);
                    return;
                }
                if (isPaletteVisible) {
                    togglePaletteVisibility(false);
                    return;
                }
                showLoadingDialog();
                if (!isTopMenuEnabled()) {
                    return;
                }
                saveProject();
            }
        });
        openResourcesEditor = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(), result -> {
                    if (result.getResultCode() == RESULT_OK) {
                        extraPaletteBlock.invalidateStringsCache();
                        paletteSelector.performClickPalette(-1);
                    }
                });
        makeBlockLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(), result -> {
                    if (result.getResultCode() == Activity.RESULT_OK && result.getData() != null) {
                        addMoreBlock(result.getData().getStringExtra("block_name"), result.getData().getStringExtra("block_spec"));
                    }
                });
        setContentView(R.layout.logic_editor);
        if (!super.isStoragePermissionGranted()) {
            finish();
        }
        Parcelable parcelable;
        if (savedInstanceState == null) {
            scId = getIntent().getStringExtra("sc_id");
            id = getIntent().getStringExtra("id");
            eventName = getIntent().getStringExtra("event");
            pendingScrollBlockId = getIntent().getStringExtra("scroll_to_block_id");
            parcelable = getIntent().getParcelableExtra("project_file");
        } else {
            scId = savedInstanceState.getString("sc_id");
            id = savedInstanceState.getString("id");
            eventName = savedInstanceState.getString("event");
            pendingScrollBlockId = savedInstanceState.getString("scroll_to_block_id");
            parcelable = savedInstanceState.getParcelable("project_file");
        }
        if (parcelable == null) {
            finish();
            return;
        }
        isViewBindingEnabled = new ProjectSettings(scId).getValue(ProjectSettings.SETTING_ENABLE_VIEWBINDING, "false").equals("true");
        projectFile = (ProjectFileBean) parcelable;
        dummyOffsetY = (int) ViewUtil.dpToPx(getContext(), (float) dummyOffsetY);
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        toolbar.setNavigationOnClickListener(v -> {
            if (!UIHelper.isClickThrottled()) {
                getOnBackPressedDispatcher().onBackPressed();
            }
        });
        isVibrationEnabled = new SharedPrefsHelper(getContext(), "P12").getBoolean("P12I0", true);
        minDist = ViewConfiguration.get(getContext()).getScaledTouchSlop();
        vibrator = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
        String eventText = getIntent().getStringExtra("event_text");
        toolbar.setTitle(id.equals("_fab") ? "fab" : ReturnMoreblockManager.getMbName(id));
        toolbar.setSubtitle(eventText);
        paletteSelector = findViewById(R.id.palette_selector);
        paletteSelector.setOnBlockCategorySelectListener(this);
        paletteSelector.post(() -> paletteBlocksInitialized = true);
        paletteBlock = findViewById(R.id.palette_block);
        dummy = findViewById(R.id.dummy);
        viewLogicEditor = findViewById(R.id.editor);
        blockPane = viewLogicEditor.getBlockPane();
        paletteLayout = findViewById(R.id.layout_palette);
        paletteArea = findViewById(R.id.area_palette);
        openBlocksMenuButton = findViewById(R.id.fab_toggle_palette);
        openBlocksMenuButton.setOnClickListener(v -> togglePaletteVisibility(!isPaletteVisible));
        logicTopMenu = findViewById(R.id.top_menu);
        editorDrawer = findViewById(R.id.right_drawer);
        blockSearchField = findViewById(R.id.search_header);
        blockSearchField.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {}

            @Override
            public void afterTextChanged(Editable s) {
                if (suppressSearchTextChange) return;
                if (pendingSearchRunnable != null) {
                    handler.removeCallbacks(pendingSearchRunnable);
                }
                String query = s.toString().trim();
                if (query.isEmpty()) {
                    if (isBlockSearchActive) {
                        isBlockSearchActive = false;
                        extraPaletteBlock.setBlock(lastSelectedPaletteId, lastSelectedPaletteColor);
                    }
                } else {
                    pendingSearchRunnable = () -> {
                        isBlockSearchActive = true;
                        extraPaletteBlock.searchAllBlocks(query);
                    };
                    handler.postDelayed(pendingSearchRunnable, 300);
                }
            }
        });
        canvasSearchBar = findViewById(R.id.canvas_search_bar);
        canvasSearchInput = findViewById(R.id.canvas_search_input);
        canvasSearchCount = findViewById(R.id.canvas_search_count);
        canvasSearchBackCallback = new OnBackPressedCallback(false) {
            @Override
            public void handleOnBackPressed() {
                closeCanvasSearch();
            }
        };
        getOnBackPressedDispatcher().addCallback(this, canvasSearchBackCallback);
        findViewById(R.id.canvas_search_close).setOnClickListener(v -> closeCanvasSearch());
        findViewById(R.id.canvas_search_prev).setOnClickListener(v -> navigateCanvasSearch(-1));
        findViewById(R.id.canvas_search_next).setOnClickListener(v -> navigateCanvasSearch(1));
        canvasSearchInput.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {}
            @Override
            public void afterTextChanged(Editable s) {
                if (suppressCanvasSearchTextChange) return;
                if (pendingCanvasSearchRunnable != null) {
                    handler.removeCallbacks(pendingCanvasSearchRunnable);
                }
                String query = s.toString().trim();
                if (query.isEmpty()) {
                    performCanvasSearch("");
                } else {
                    pendingCanvasSearchRunnable = () -> performCanvasSearch(query);
                    handler.postDelayed(pendingCanvasSearchRunnable, 300);
                }
            }
        });

        extraPaletteBlock = new ExtraPaletteBlock(this, isViewBindingEnabled);

        svgUtils = new SvgUtils(this);
        
		
		    // Initialize syntax check UI
        syntaxCheckContainer = findViewById(R.id.syntax_check_container);
        syntaxCheckIcon = findViewById(R.id.syntax_check_icon);
        syntaxCheckText = findViewById(R.id.syntax_check_text);
        syntaxCheckContainer.setOnClickListener(v -> {
            LogicSyntaxChecker.SyntaxResult result = (LogicSyntaxChecker.SyntaxResult) v.getTag();
            if (result != null && !result.isValid) {
                // إنشاء TextView قابل للتمرير ويدعم تحديد النص
                android.widget.ScrollView scrollView = new android.widget.ScrollView(this);
                int padding = (int) (16 * getResources().getDisplayMetrics().density);
                scrollView.setPadding(padding, padding, padding, padding);
    
                TextView messageView = new TextView(this);
                messageView.setText(result.errorMessage);
                messageView.setTextIsSelectable(true);
                messageView.setTextSize(14f);
                messageView.setTextColor(pro.sketchware.util.ThemeUtils.getColor(this, com.google.android.material.R.attr.colorOnSurface));
                
                scrollView.addView(messageView);
    
                new MaterialAlertDialogBuilder(this)
                    .setTitle("Syntax Error Details")
                    .setView(scrollView)
                    .setPositiveButton(R.string.common_word_ok, null)
                    .setNeutralButton("نسخ", (dialog, which) -> {
                        ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                        if (clipboard != null) {
                            clipboard.setPrimaryClip(ClipData.newPlainText("Syntax Error", result.errorMessage));
                            Toast.makeText(this, "تم نسخ النص بنجاح", Toast.LENGTH_SHORT).show();
                        }
                    })
                    .setNegativeButton("ترجمة", (dialog, which) -> {
                            String encodedText;
                        try {
                            encodedText = java.net.URLEncoder.encode(result.errorMessage, java.nio.charset.StandardCharsets.UTF_8.name());
                        } catch (Exception e) {
                            // إذا فشل الترميز ببساطة نستخدم النص الأصلي كنسخة احتياطية
                            encodedText = result.errorMessage;
                        }
                        openGoogleTranslate(encodedText);
                            
                            
                    })
                    .show();
            }
        });

    }

    @Override
    public void onPostCreate(Bundle bundle) {
        super.onPostCreate(bundle);
        showLoadingDialog();
        blockPane.setVisibility(View.INVISIBLE);

        String title;
        if (eventName.equals("moreBlock")) {
            title = Helper.getResString(R.string.root_spec_common_define) + " " + ReturnMoreblockManager.getLogicEditorTitle(ProjectDataManager.getProjectDataManager(scId).getMoreBlockSpec(projectFile.getJavaName(), id));
        } else if (id.equals("_fab")) {
            title = StringResource.getInstance().getRootSpecTranslation(getContext(), "fab", eventName);
        } else {
            title = StringResource.getInstance().getRootSpecTranslation(getContext(), id, eventName);
        }
        String headerTitle = title;

        long pc0 = System.currentTimeMillis();
        blockPane.createHeaderBlock(headerTitle, eventName);
        long pc1 = System.currentTimeMillis();
        android.util.Log.d("BlockLoad", "PC rootBlock: " + (pc1 - pc0) + "ms");

        ArrayList<String> spec = FormatUtil.parseBlockSpec(headerTitle);
        int blockId = 0;
        for (int i = 0; i < spec.size(); i++) {
            String specBit = spec.get(i);
            if (specBit.charAt(0) == '%') {
                BlockView block = BlockUtil.getVariableBlock(getContext(), blockId + 1, specBit, "getArg");
                if (block != null) {
                    block.setBlockType(1);
                    blockPane.addView(block);
                    blockPane.getRoot().replaceParameter((BaseBlockView) blockPane.getRoot().childViews.get(blockId), block);
                    block.setOnTouchListener(this);
                    blockId++;
                }
            }
        }
        long pc2 = System.currentTimeMillis();
        android.util.Log.d("BlockLoad", "PC varBlocks: " + (pc2 - pc1) + "ms");

        blockPane.getRoot().layoutChain();
        long pc3 = System.currentTimeMillis();
        android.util.Log.d("BlockLoad", "PC rootK: " + (pc3 - pc2) + "ms");

        handleOrientationChange(getResources().getConfiguration().orientation);
        long pc4 = System.currentTimeMillis();
        android.util.Log.d("BlockLoad", "PC orient: " + (pc4 - pc3) + "ms");

        LoadEventBlocksTask loadEventBlocksTask = new LoadEventBlocksTask(this);
        loadEventBlocksTask.execute();
        long pc5 = System.currentTimeMillis();
        android.util.Log.d("BlockLoad", "PC taskExec: " + (pc5 - pc4) + "ms total=" + (pc5 - pc0) + "ms");
        // loadBlockCollections() deferred to onComplete so it runs after blocks are visible
        triggerSyntaxCheck();
    }

    @Override
    public void onResume() {
        super.onResume();
        if (!super.isStoragePermissionGranted()) {
            finish();
        }
    }
    
    // إضافة onDestroy لتنظيف الـ Activity بالكامل
	@Override
	public void onDestroy() {
		super.onDestroy();
		if (syntaxExecutor != null && !syntaxExecutor.isShutdown()) {
			syntaxExecutor.shutdownNow();
		}
		if (activeAiRequest != null) {
			activeAiRequest.cancel();
		}
	}

    @Override
    public void onSaveInstanceState(Bundle bundle) {
        bundle.putString("sc_id", scId);
        bundle.putString("id", id);
        bundle.putString("event", eventName);
        bundle.putString("scroll_to_block_id", pendingScrollBlockId);
        bundle.putParcelable("project_file", projectFile);
        super.onSaveInstanceState(bundle);
        if (blockPane == null || blockPane.getRoot() == null) return;
        ArrayList<BlockBean> blocks = blockPane.getBlocks();
        ProjectDataStore projectDataStore = ProjectDataManager.getProjectDataManager(scId);
        String javaName = projectFile.getJavaName();
        projectDataStore.putBlocks(javaName, id + "_" + eventName, blocks);
        CompletableFuture.runAsync(() -> {
            synchronized (projectDataStore) {
                projectDataStore.saveAllBackup();
            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.logic_menu, menu);
        menu.findItem(R.id.menu_logic_redo).setEnabled(projectFile != null && BlockHistoryManager.getInstance(scId).canRedo(buildHistoryKey()));
        menu.findItem(R.id.menu_logic_undo).setEnabled(projectFile != null && BlockHistoryManager.getInstance(scId).canUndo(buildHistoryKey()));
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem menuItem) {
        int itemId = menuItem.getItemId();

        if (itemId == R.id.menu_block_helper) {
            togglePaletteVisibility(false);
            toggleDrawerVisibility(!isDrawerVisible);
        } else if (itemId == R.id.menu_logic_redo) {
            redo();
        } else if (itemId == R.id.menu_logic_undo) {
            undo();
        } else if (itemId == R.id.menu_logic_showsource) {
            new MaterialAlertDialogBuilder(this)
			.setTitle(R.string.title_source_code)
			.setItems(new CharSequence[]{
				getString(R.string.option_view_source_code),
				getString(R.string.option_code_to_blocks),
				getString(R.string.option_generate_with_ai)
			}, (dialog, which) -> {
				if (which == 0)      showSourceCode();
				else if (which == 1) showCodeToBlocksDialog();
				else                  showAiCodePromptDialog();
			})
			.setNegativeButton(R.string.btn_cancel, null)
			.show();
        } else if (itemId == R.id.menu_logic_search) {
            toggleCanvasSearch();
        }

        return super.onOptionsItemSelected(menuItem);
    }

    @Override
    public void onSelected(MoreBlockCollectionBean moreBlockCollectionBean) {
        new MoreblockImporter(this, scId, projectFile).importMoreblock(moreBlockCollectionBean, () -> onBlockSizeChanged(8, ContextCompat.getColor(this, R.color.palette_more_block)));
    }

    @Override
    public boolean onTouch(View v, MotionEvent event) {
        int actionMasked = event.getActionMasked();
        if (event.getPointerId(event.getActionIndex()) > 0) {
            return true;
        }
        if (actionMasked == MotionEvent.ACTION_DOWN) {
            isDragged = false;
            handler.postDelayed(longPressed, ViewConfiguration.getLongPressTimeout() / 2);
            int[] locationOnScreen = new int[2];
            v.getLocationOnScreen(locationOnScreen);
            touchOriginX = locationOnScreen[0];
            touchOriginY = locationOnScreen[1];
            posInitX = event.getRawX();
            posInitY = event.getRawY();
            currentTouchedView = v;
            return true;
        }
        if (actionMasked == MotionEvent.ACTION_MOVE) {
            if (!isDragged) {
                if (Math.abs(posInitX - touchOriginX - event.getX()) >= minDist || Math.abs(posInitY - touchOriginY - event.getY()) >= minDist) {
                    currentTouchedView = null;
                    handler.removeCallbacks(longPressed);
                }
                return false;
            }
            handler.removeCallbacks(longPressed);
            float rawX = event.getRawX();
            float rawY = event.getRawY();
            dummy.updateDummyPosition(v, rawX - touchOriginX, rawY - touchOriginY, posInitX - touchOriginX, posInitY - touchOriginY, dummyOffsetX, dummyOffsetY);
            if (hitTestIconDelete(event.getRawX(), event.getRawY())) {
                dummy.setAllow(true);
                activeIconDelete(true);
                setCopyActive(false);
                setFavoriteActive(false);
                setDetailActive(false);
                return true;
            }
            activeIconDelete(false);
            if (hitTestCopy(event.getRawX(), event.getRawY())) {
                dummy.setAllow(true);
                setCopyActive(true);
                setFavoriteActive(false);
                setDetailActive(false);
                return true;
            }
            setCopyActive(false);
            if (hitTestFavorite(event.getRawX(), event.getRawY())) {
                dummy.setAllow(true);
                setFavoriteActive(true);
                setDetailActive(false);
                return true;
            }
            setFavoriteActive(false);
            if (hitTestDetail(event.getRawX(), event.getRawY())) {
                dummy.setAllow(true);
                setDetailActive(true);
                return true;
            }
            setDetailActive(false);
            dummy.getDummyLocation(this.locationBuffer);
            if (viewLogicEditor.hitTest(this.locationBuffer[0], this.locationBuffer[1])) {
                dummy.setAllow(true);
                blockPane.updateDragPreview((BlockView) currentTouchedView, this.locationBuffer[0], this.locationBuffer[1]);
            } else {
                dummy.setAllow(false);
                blockPane.hideActiveBlock();
            }
            return true;
        } else if (actionMasked == MotionEvent.ACTION_UP) {
            currentTouchedView = null;
            handler.removeCallbacks(longPressed);
            if (!isDragged) {
                if (v instanceof BlockView rs) {
                    if (rs.getBlockType() == 0) {
                        handleBlockFieldClick(rs, event.getX(), event.getY());
                    }
                }
                return false;
            }
            paletteBlock.setDragEnabled(true);
            viewLogicEditor.setScrollEnabled(true);
            editorDrawer.setDragEnabled(true);
            dummy.setDummyVisibility(View.GONE);
            if (!dummy.getAllow()) {
                BlockView restoredBlock = (BlockView) v;
                if (restoredBlock.getBlockType() == 0) {
                    blockPane.setBlockTreeVisibility(restoredBlock, 0);
                    if (dragSourceParent != null) {
                        if (dragConnectionType == 0) {
                            dragSourceParent.nextBlock = (Integer) v.getTag();
                        }
                        if (dragConnectionType == 2) {
                            dragSourceParent.subStack1 = (Integer) v.getTag();
                        }
                        if (dragConnectionType == 3) {
                            dragSourceParent.subStack2 = (Integer) v.getTag();
                        }
                        if (dragConnectionType == 5) {
                            dragSourceParent.replaceParameter((BaseBlockView) dragSourceParent.childViews.get(dragParameterIndex), restoredBlock);
                        }
                        restoredBlock.parentBlock = dragSourceParent;
                        dragSourceParent.getRootBlock().layoutChain();
                    } else {
                        restoredBlock.getRootBlock().layoutChain();
                    }
                }
                onBlockDropped();
            } else if (logicTopMenu.isDeleteActive) {
                BlockView deletedBlock = (BlockView) v;
                if (deletedBlock.getBlockType() == 2) {
                    activeIconDelete(false);
                    toggleDrawerVisibility(true);
                    showDeleteFavoriteDialog(((DefinitionBlockView) deletedBlock).getCollectionName());
                } else {
                    activeIconDelete(false);
                    int id;
                    try {
                        id = Integer.parseInt(deletedBlock.getBean().id);
                    } catch (NumberFormatException e) {
                        id = -1;
                    }
                    BlockBean prevParentData;
                    if (dragSourceParent != null && id != -1) {
                        BlockBean clone = dragSourceParent.getBean().clone();
                        if (dragConnectionType == 0) {
                            clone.nextBlock = id;
                        } else if (dragConnectionType == 2) {
                            clone.subStack1 = id;
                        } else if (dragConnectionType == 3) {
                            clone.subStack2 = id;
                        } else if (dragConnectionType == 5) {
                            clone.parameters.set(dragParameterIndex, "@" + id);
                        }
                        prevParentData = clone;
                    } else {
                        prevParentData = null;
                    }
                    ArrayList<BlockBean> removedBlocks = new ArrayList<>();
                    for (BlockView allChild : deletedBlock.getAllChildren()) {
                        removedBlocks.add(allChild.getBean().clone());
                    }
                    deleteBlock(deletedBlock);
                    BlockBean currentParentData = null;
                    if (dragSourceParent != null) {
                        currentParentData = dragSourceParent.getBean().clone();
                    }
                    int[] oLocationOnScreen = new int[2];
                    blockPane.getLocationOnScreen(oLocationOnScreen);
                    BlockHistoryManager.getInstance(scId).recordRemove(buildHistoryKey(), removedBlocks, ((int) touchOriginX) - oLocationOnScreen[0], ((int) touchOriginY) - oLocationOnScreen[1], prevParentData, currentParentData);
                    refreshOptionsMenu();
                }
            } else if (logicTopMenu.isFavoriteActive) {
                setFavoriteActive(false);
                BlockView favoritedBlock = (BlockView) v;
                blockPane.setBlockTreeVisibility(favoritedBlock, 0);
                if (dragSourceParent != null) {
                    if (dragConnectionType == 0) {
                        dragSourceParent.nextBlock = (Integer) v.getTag();
                    }
                    if (dragConnectionType == 2) {
                        dragSourceParent.subStack1 = (Integer) v.getTag();
                    }
                    if (dragConnectionType == 3) {
                        dragSourceParent.subStack2 = (Integer) v.getTag();
                    }
                    if (dragConnectionType == 5) {
                        dragSourceParent.replaceParameter((BaseBlockView) dragSourceParent.childViews.get(dragParameterIndex), favoritedBlock);
                    }
                    favoritedBlock.parentBlock = dragSourceParent;
                    dragSourceParent.getRootBlock().layoutChain();
                } else {
                    favoritedBlock.getRootBlock().layoutChain();
                }
                showSaveToFavorites(favoritedBlock);
            } else if (logicTopMenu.isDetailActive) {
                setDetailActive(false);
                if (v instanceof DefinitionBlockView) {
                    showBlockCollection(((DefinitionBlockView) v).getCollectionName());
                }
            } else if (logicTopMenu.isCopyActive) {
                setCopyActive(false);
                BlockView copiedBlock = (BlockView) v;
                blockPane.setBlockTreeVisibility(copiedBlock, 0);
                if (dragSourceParent != null) {
                    if (dragConnectionType == 0) {
                        dragSourceParent.nextBlock = (Integer) v.getTag();
                    }
                    if (dragConnectionType == 2) {
                        dragSourceParent.subStack1 = (Integer) v.getTag();
                    }
                    if (dragConnectionType == 3) {
                        dragSourceParent.subStack2 = (Integer) v.getTag();
                    }
                    if (dragConnectionType == 5) {
                        dragSourceParent.replaceParameter((BaseBlockView) dragSourceParent.childViews.get(dragParameterIndex), copiedBlock);
                    }
                    copiedBlock.parentBlock = dragSourceParent;
                    dragSourceParent.getRootBlock().layoutChain();
                } else {
                    // somehow the blocks is moving to the last position
                    // commenting it to fix it too
                    // copiedBlock.getRootBlock().layoutChain();
                }
                ArrayList<BlockBean> clonedBeans = new ArrayList<>();
                for (BlockView rs : copiedBlock.getAllChildren()) {
                    BlockBean clonedBean = rs.getBean().clone();
                    int id;
                    try {
                        id = Integer.parseInt(clonedBean.id);
                    } catch (NumberFormatException e) {
                        id = -1;
                    }
                    if (id != -1) {
                        clonedBean.id = String.valueOf(id + 99000000);
                        if (clonedBean.nextBlock > 0) {
                            clonedBean.nextBlock = clonedBean.nextBlock + 99000000;
                        }
                        if (clonedBean.subStack1 > 0) {
                            clonedBean.subStack1 = clonedBean.subStack1 + 99000000;
                        }
                        if (clonedBean.subStack2 > 0) {
                            clonedBean.subStack2 = clonedBean.subStack2 + 99000000;
                        }
                        for (int i = 0; i < clonedBean.parameters.size(); i++) {
                            String parameter = clonedBean.parameters.get(i);
                            if (parameter != null && !parameter.isEmpty() && parameter.charAt(0) == '@') {
                                clonedBean.parameters.set(i, "@" + (Integer.parseInt(parameter.substring(1)) + 99000000));
                            }
                        }
                        clonedBeans.add(clonedBean);
                    }
                }
                int[] nLocationOnScreen = new int[2];
                viewLogicEditor.getLocationOnScreen(nLocationOnScreen);
                int width = nLocationOnScreen[0] + (viewLogicEditor.getWidth() / 2);
                int dropY = nLocationOnScreen[1] + ((int) ViewUtil.dpToPx(getContext(), 4.0f));
                ArrayList<BlockBean> addedBlocks = addBlockBeans(clonedBeans, width, dropY, true);
                int[] oLocationOnScreen = new int[2];
                blockPane.getLocationOnScreen(oLocationOnScreen);
                BlockHistoryManager.getInstance(scId).recordAddMultiple(buildHistoryKey(), addedBlocks, width - oLocationOnScreen[0], dropY - oLocationOnScreen[1], null, null);
                refreshOptionsMenu();
            } else if (v instanceof BlockView paletteBlock) {
                dummy.getDummyLocation(this.locationBuffer);
                if (paletteBlock.getBlockType() == 1) {
                    int addTargetId = blockPane.getAddTargetId();
                    BlockBean prevAddTargetClone = addTargetId >= 0 ? blockPane.findBlockById(addTargetId).getBean().clone() : null;
                    BlockView droppedBlock = dropBlockOnPane(paletteBlock, this.locationBuffer[0], this.locationBuffer[1], false);
                    BlockBean currentParentData = null;
                    if (addTargetId >= 0) {
                        currentParentData = blockPane.findBlockById(addTargetId).getBean().clone();
                    }
                    int[] locationOnScreen = new int[2];
                    blockPane.getLocationOnScreen(locationOnScreen);
                    BlockHistoryManager.getInstance(scId).recordAdd(buildHistoryKey(), droppedBlock.getBean().clone(), this.locationBuffer[0] - locationOnScreen[0], this.locationBuffer[1] - locationOnScreen[1], prevAddTargetClone, currentParentData);
                    if (prevAddTargetClone != null) {
                        prevAddTargetClone.print();
                    }
                    if (currentParentData != null) {
                        currentParentData.print();
                    }
                } else if (paletteBlock.getBlockType() == 2) {
                    int defAddTargetId = blockPane.getAddTargetId();
                    BlockBean prevDefTargetClone = defAddTargetId >= 0 ? blockPane.findBlockById(defAddTargetId).getBean().clone() : null;
                    ArrayList<BlockBean> data = ((DefinitionBlockView) v).getData();
                    ArrayList<BlockBean> addedBlocks = addBlockBeans(data, this.locationBuffer[0], this.locationBuffer[1], true);
                    if (!addedBlocks.isEmpty()) {
                        BlockView firstAddedBlock = blockPane.findBlockByString(addedBlocks.get(0).id);
                        dropBlockOnPane(firstAddedBlock, this.locationBuffer[0], this.locationBuffer[1], true);
                        BlockBean currentParentData = null;
                        if (defAddTargetId >= 0) {
                            currentParentData = blockPane.findBlockById(defAddTargetId).getBean().clone();
                        }
                        int[] locationOnScreen = new int[2];
                        blockPane.getLocationOnScreen(locationOnScreen);
                        BlockHistoryManager.getInstance(scId).recordAddMultiple(buildHistoryKey(), addedBlocks, this.locationBuffer[0] - locationOnScreen[0], this.locationBuffer[1] - locationOnScreen[1], prevDefTargetClone, currentParentData);
                    }
                    blockPane.clearSnapState();
                } else {
                    blockPane.setBlockTreeVisibility(paletteBlock, 0);
                    int id = Integer.parseInt(paletteBlock.getBean().id);
                    BlockBean blockBean;
                    if (dragSourceParent != null) {
                        blockBean = dragSourceParent.getBean().clone();
                        if (dragConnectionType == 0) {
                            blockBean.nextBlock = id;
                        } else if (dragConnectionType == 2) {
                            blockBean.subStack1 = id;
                        } else if (dragConnectionType == 3) {
                            blockBean.subStack2 = id;
                        } else if (dragConnectionType == 5) {
                            blockBean.parameters.set(dragParameterIndex, "@" + id);
                        }
                    } else {
                        blockBean = null;
                    }
                    BlockView targetBlock = blockPane.findBlockById(blockPane.getAddTargetId());
                    BlockBean prevMoveTargetClone = targetBlock != null ? targetBlock.getBean().clone() : null;
                    ArrayList<BlockView> blockChildren = paletteBlock.getAllChildren();
                    ArrayList<BlockBean> beansBeforeMove = new ArrayList<>();
                    for (BlockView rs : blockChildren) {
                        beansBeforeMove.add(rs.getBean().clone());
                    }
                    dropBlockOnPane(paletteBlock, this.locationBuffer[0], this.locationBuffer[1], true);
                    ArrayList<BlockBean> beansAfterMove = new ArrayList<>();
                    for (BlockView rs : blockChildren) {
                        beansAfterMove.add(rs.getBean().clone());
                    }
                    BlockBean prevDragSourceClone = dragSourceParent != null ? dragSourceParent.getBean().clone() : null;
                    BlockBean currentParentData = null;
                    if (targetBlock != null) {
                        currentParentData = targetBlock.getBean().clone();
                    }
                    if (blockBean == null || prevDragSourceClone == null || !blockBean.isEqual(prevDragSourceClone)) {
                        int[] locationOnScreen = new int[2];
                        blockPane.getLocationOnScreen(locationOnScreen);
                        int x = locationOnScreen[0];
                        int y = locationOnScreen[1];
                        BlockHistoryManager.getInstance(scId).recordMove(buildHistoryKey(), beansBeforeMove, beansAfterMove, ((int) touchOriginX) - x, ((int) touchOriginY) - y, this.locationBuffer[0] - x, this.locationBuffer[1] - y, blockBean, prevDragSourceClone, prevMoveTargetClone, currentParentData);
                    }
                    blockPane.clearSnapState();
                }
                refreshOptionsMenu();
                blockPane.clearSnapState();
            }
            dummy.setAllow(false);
            toggleTopMenuVisibility(false);
            isDragged = false;
            return true;
        } else if (actionMasked == MotionEvent.ACTION_CANCEL) {
            handler.removeCallbacks(longPressed);
            isDragged = false;
            return false;
        } else if (actionMasked == MotionEvent.ACTION_SCROLL) {
            handler.removeCallbacks(longPressed);
            isDragged = false;
            return false;
        } else {
            return true;
        }
    }

    public boolean isTopMenuEnabled() {
        return true;
    }

    public void onBlockDropped() {
    }

    private void startDragMode() {
        if (currentTouchedView != null) {
            paletteBlock.setDragEnabled(false);
            viewLogicEditor.setScrollEnabled(false);
            editorDrawer.setDragEnabled(false);
            if (isDrawerVisible) {
                toggleDrawerVisibility(false);
            }

            if (isVibrationEnabled) {
                vibrator.vibrate(100L);
            }

            isDragged = true;
            if (((BlockView) currentTouchedView).getBlockType() == 0) {
                trackDragSource((BlockView) currentTouchedView);
                toggleLayoutVisibility(true);
                toggleTopMenuVisibility(true);
                dummy.setBlockTypeImage((BlockView) currentTouchedView);
                blockPane.setBlockTreeVisibility((BlockView) currentTouchedView, 8);
                blockPane.detachFromParent((BlockView) currentTouchedView);
                blockPane.computeSnapPoints((BlockView) currentTouchedView);
            } else if (((BlockView) currentTouchedView).getBlockType() == 2) {
                toggleLayoutVisibility(false);
                toggleTopMenuVisibility(true);
                dummy.setBlockTypeImage((BlockView) currentTouchedView);
                blockPane.computeSnapPointsForBlocks((BlockView) currentTouchedView, ((DefinitionBlockView) currentTouchedView).getData());
            } else {
                dummy.setBlockTypeImage((BlockView) currentTouchedView);
                blockPane.computeSnapPoints((BlockView) currentTouchedView);
            }

            float deltaX = posInitX - touchOriginX;
            float deltaY = posInitY - touchOriginY;
            dummy.updateDummyPosition(currentTouchedView, deltaX, deltaY, deltaX, deltaY, dummyOffsetX, dummyOffsetY);
            dummy.getDummyLocation(locationBuffer);
            if (viewLogicEditor.hitTest(locationBuffer[0], locationBuffer[1])) {
                dummy.setAllow(true);
                blockPane.updateDragPreview((BlockView) currentTouchedView, locationBuffer[0], locationBuffer[1]);
            } else {
                dummy.setAllow(false);
                blockPane.hideActiveBlock();
            }
        }
    }

    public final String buildHistoryKey() {
        return BlockHistoryManager.buildKey(projectFile.getJavaName(), id, eventName);
    }

    public void showSourceCode() {
        ProjectFilePaths projectFilePaths = new ProjectFilePaths(this, scId);
        projectFilePaths.initializeMetadata(ProjectDataManager.getLibraryManager(scId), ProjectDataManager.getFileManager(scId), ProjectDataManager.getProjectDataManager(scId));
        String code = new BlockInterpreter(projectFile.getActivityName(), projectFilePaths.buildConfig, blockPane.getBlocks(), isViewBindingEnabled, projectFile.getXmlName()).interpretBlocks();
        var intent = new Intent(this, CodeViewerActivity.class);
        intent.putExtra("code", code);
        intent.putExtra("sc_id", scId);
        intent.putExtra("scheme", CodeViewerActivity.SCHEME_JAVA);
        startActivity(intent);
    }
    
    private void triggerSyntaxCheck() {
		syntaxCheckHandler.removeCallbacks(syntaxCheckRunnable);
		syntaxCheckHandler.postDelayed(syntaxCheckRunnable, 500);
	}
	
	
	private void runSyntaxCheck() {
		if (blockPane == null || blockPane.getBlocks().isEmpty()) {
			syntaxCheckContainer.setVisibility(View.GONE);
			return;
		}
		
		ProjectFilePaths projectFilePaths = new ProjectFilePaths(this, scId);
        projectFilePaths.initializeMetadata(ProjectDataManager.getLibraryManager(scId), ProjectDataManager.getFileManager(scId), ProjectDataManager.getProjectDataManager(scId));
		
		
		syntaxExecutor.execute(() -> {
			LogicSyntaxChecker.SyntaxResult result = LogicSyntaxChecker.check(
                projectFile.getActivityName(),
                projectFilePaths.buildConfig,
                blockPane.getBlocks(),
                isViewBindingEnabled
            );
			
			runOnUiThread(() -> {
				if (isFinishing() || isDestroyed()) return;
				syntaxCheckContainer.setVisibility(View.VISIBLE);
				syntaxCheckContainer.setTag(result);
				if (result.isValid) {
					syntaxCheckIcon.setImageResource(R.drawable.ic_check);
					syntaxCheckIcon.setColorFilter(ContextCompat.getColor(this, R.color.scolor_green_normal));
					syntaxCheckText.setText(R.string.logic_editor_syntax_ok);
					syntaxCheckText.setTextColor(ContextCompat.getColor(this, R.color.scolor_green_normal));
				} else {
					syntaxCheckIcon.setImageResource(R.drawable.ic_remove_grey600_24dp);
					syntaxCheckIcon.setColorFilter(ContextCompat.getColor(this, R.color.scolor_red_01));
					syntaxCheckText.setText(R.string.logic_editor_syntax_error_details);
					syntaxCheckText.setTextColor(ContextCompat.getColor(this, R.color.scolor_red_01));
				}
			});
		});
	}

    public void initDrawerAnimators() {
        drawerShowAnimator = ObjectAnimator.ofFloat(editorDrawer, View.TRANSLATION_X, 0.0f);
        drawerShowAnimator.setDuration(500L);
        drawerShowAnimator.setInterpolator(new DecelerateInterpolator());
        drawerHideAnimator = ObjectAnimator.ofFloat(editorDrawer, View.TRANSLATION_X, editorDrawer.getHeight());
        drawerHideAnimator.setDuration(300L);
        drawerHideAnimator.setInterpolator(new DecelerateInterpolator());
        drawerAnimatorsInitialized = true;
    }

    public void initTopMenuAnimators() {
        topMenuShowAnimator = ObjectAnimator.ofFloat(logicTopMenu, View.TRANSLATION_Y, 0.0f);
        topMenuShowAnimator.setDuration(500L);
        topMenuShowAnimator.setInterpolator(new DecelerateInterpolator());
        topMenuHideAnimator = ObjectAnimator.ofFloat(logicTopMenu, View.TRANSLATION_Y, logicTopMenu.getHeight() * (-1));
        topMenuHideAnimator.setDuration(300L);
        topMenuHideAnimator.setInterpolator(new DecelerateInterpolator());
        topMenuAnimatorsInitialized = true;
    }

    public void loadBlockCollections() {
        editorDrawer.clearAllBlocks();
        for (BlockCollectionBean next : BlockCollectionManager.getInstance().getBlocks()) {
            editorDrawer.addBlockCollection(next.name, next.blocks).setOnTouchListener(this);
        }
    }

    private static class ProjectSaver {
        private final WeakReference<LogicEditorActivity> activity;

        public ProjectSaver(LogicEditorActivity logicEditorActivity) {
            activity = new WeakReference<>(logicEditorActivity);
        }

        public void execute() {
            var act = activity.get();
            if (act == null) return;
            BackgroundTasks.runSerial(TaskHost.of(act), "LogicEditorActivity$ProjectSaver",
                    this::doWork, this::onSuccess, this::onError);
        }

        private void doWork() {
            var act = activity.get();
            if (act == null) return;
            act.saveBlocks();
        }

        private void onSuccess() {
            var act = activity.get();
            if (act == null) return;
            act.dismissLoadingDialog();
            act.finish();
        }

        private void onError(Throwable error) {
            var act = activity.get();
            if (act == null) return;
            Toast.makeText(act, R.string.common_error_failed_to_save, Toast.LENGTH_SHORT).show();
            act.dismissLoadingDialog();
            SketchToast.warning(act, buildErrorMessage(error), 1).show();
        }

        private String buildErrorMessage(Throwable error) {
            String errorMessage = error != null ? error.getMessage() : null;
            if (errorMessage == null || errorMessage.isEmpty()) {
                return Helper.getResString(R.string.common_error_an_error_occurred);
            }
            return Helper.getResString(R.string.common_error_an_error_occurred) + "[" + errorMessage + "]";
        }
    }

    public static class LoadEventBlocksTask {
        private final WeakReference<LogicEditorActivity> activityRef;

        public LoadEventBlocksTask(LogicEditorActivity activity) {
            activityRef = new WeakReference<>(activity);
        }

        public void execute() {
            LogicEditorActivity activity = getActivity();
            if (activity == null) {
                return;
            }
            BackgroundTasks.runIoIfAlive(TaskHost.of(activity), "LogicEditorActivity$LoadEventBlocksTask", this::doInBackground, null, error -> {
                LogicEditorActivity currentActivity = getActivity();
                if (currentActivity != null) {
                    currentActivity.dismissLoadingDialog();
                }
            });
        }

        private void doInBackground() {
            LogicEditorActivity activity = getActivity();
            if (activity != null) {
                Runnable onComplete = () -> {
                    LogicEditorActivity a = getActivity();
                    if (a != null) {
                        a.blockPane.setVisibility(View.VISIBLE);
                        a.dismissLoadingDialog();
                        Choreographer.getInstance().postFrameCallback(ft -> {
                            LogicEditorActivity act = getActivity();
                            if (act != null) {
                                act.loadBlockCollections();
                                act.scrollToPendingBlock();
                            }
                        });
                    }
                };
                activity.loadEventBlocks(onComplete);
            }
        }

        private LogicEditorActivity getActivity() {
            return activityRef.get();
        }
    }

    public class ImagePickerAdapter extends RecyclerView.Adapter<ImagePickerAdapter.ViewHolder> {

        private final ArrayList<String> images;
        private final OnImageSelectedListener listener;
        private final ArrayList<String> filteredImages;
        private final Map<String, View> imageCache = new HashMap<>();
        private String selectedImage;

        public ImagePickerAdapter(ArrayList<String> images, String selectedImage, OnImageSelectedListener listener) {
            this.images = images;
            this.selectedImage = selectedImage;
            this.listener = listener;
            filteredImages = new ArrayList<>(images);
        }

        @NonNull
        @Override
        public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            ImagePickerItemBinding binding = ImagePickerItemBinding.inflate(LayoutInflater.from(parent.getContext()), parent, false);
            return new ViewHolder(binding);
        }

        @Override
        public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
            String image = filteredImages.get(position);

            holder.binding.textView.setText(image);

            View imageView = imageCache.get(image);
            if (imageView == null) {
                imageView = setImageViewContent(image);
                imageCache.put(image, imageView);
            }

            if (imageView.getParent() != null) {
                ((ViewGroup) imageView.getParent()).removeView(imageView);
            }

            holder.binding.layoutImg.removeAllViews();
            holder.binding.layoutImg.addView(imageView);

            holder.binding.radioButton.setChecked(image.equals(selectedImage));

            holder.binding.transparentOverlay.setOnClickListener(v -> {
                if (!image.equals(selectedImage)) {
                    selectedImage = image;
                    listener.onImageSelected(image);
                    notifyDataSetChanged();
                }
            });
        }

        @Override
        public int getItemCount() {
            return filteredImages.size();
        }

        public void filter(String query) {
            filteredImages.clear();
            if (query.isEmpty()) {
                filteredImages.addAll(images);
            } else {
                for (String image : images) {
                    if (image.toLowerCase().contains(query)) {
                        filteredImages.add(image);
                    }
                }
            }
            notifyDataSetChanged();
        }

        public interface OnImageSelectedListener {
            void onImageSelected(String image);
        }

        public static class ViewHolder extends RecyclerView.ViewHolder {
            public final ImagePickerItemBinding binding;

            public ViewHolder(@NonNull ImagePickerItemBinding binding) {
                super(binding.getRoot());
                this.binding = binding;
            }
        }
    }

    private void toggleCanvasSearch() {
        if (isCanvasSearchActive) {
            closeCanvasSearch();
        } else {
            isCanvasSearchActive = true;
            canvasSearchBackCallback.setEnabled(true);
            canvasSearchBar.setVisibility(View.VISIBLE);
            canvasSearchInput.requestFocus();
            android.view.inputmethod.InputMethodManager imm =
                    (android.view.inputmethod.InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
            if (imm != null) imm.showSoftInput(canvasSearchInput, 0);
            if (isPaletteVisible) togglePaletteVisibility(false);
        }
    }

    private void closeCanvasSearch() {
        isCanvasSearchActive = false;
        canvasSearchBackCallback.setEnabled(false);
        canvasSearchBar.setVisibility(View.GONE);
        canvasSearchMatches.clear();
        canvasSearchIndex = -1;
        canvasSearchCount.setText("");
        blockPane.clearSearchHighlight();
        suppressCanvasSearchTextChange = true;
        canvasSearchInput.setText("");
        suppressCanvasSearchTextChange = false;
        android.view.inputmethod.InputMethodManager imm =
                (android.view.inputmethod.InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
        if (imm != null) imm.hideSoftInputFromWindow(canvasSearchInput.getWindowToken(), 0);
    }

    private void performCanvasSearch(String query) {
        canvasSearchIndex = -1;
        if (query.isEmpty()) {
            blockPane.clearSearchHighlight();
            canvasSearchCount.setText("");
            return;
        }
        canvasSearchMatches = blockPane.searchBlocks(query);
        if (canvasSearchMatches.isEmpty()) {
            blockPane.clearSearchHighlight();
            canvasSearchCount.setText(getString(R.string.search_canvas_no_results));
        } else {
            canvasSearchIndex = 0;
            blockPane.highlightSearchResults(canvasSearchMatches, canvasSearchMatches.get(0));
            scrollToBlock(canvasSearchMatches.get(0));
            updateCanvasSearchCount();
        }
    }

    private void navigateCanvasSearch(int direction) {
        if (canvasSearchMatches.isEmpty()) return;
        canvasSearchIndex += direction;
        if (canvasSearchIndex < 0) canvasSearchIndex = canvasSearchMatches.size() - 1;
        if (canvasSearchIndex >= canvasSearchMatches.size()) canvasSearchIndex = 0;
        BlockView current = canvasSearchMatches.get(canvasSearchIndex);
        blockPane.highlightSearchResults(canvasSearchMatches, current);
        scrollToBlock(current);
        updateCanvasSearchCount();
    }

    private void updateCanvasSearchCount() {
        canvasSearchCount.setText(getString(R.string.search_canvas_count,
                canvasSearchIndex + 1, canvasSearchMatches.size()));
    }

    public void scrollToBlock(BlockView target) {
        int scrollX = (int) target.getX() - viewLogicEditor.getWidth() / 2 + target.getWidth() / 2;
        int scrollY = (int) target.getY() - viewLogicEditor.getHeight() / 2 + target.getHeight() / 2;
        viewLogicEditor.scrollTo(Math.max(0, scrollX), Math.max(0, scrollY));
    }

    private void scrollToPendingBlock() {
        if (pendingScrollBlockId == null) return;
        String blockIdStr = pendingScrollBlockId;
        pendingScrollBlockId = null;
        BlockView blockView = blockPane.findBlockByString(blockIdStr);
        if (blockView != null) {
            blockPane.clearSearchHighlight();
            ArrayList<BlockView> single = new ArrayList<>();
            single.add(blockView);
            blockPane.highlightSearchResults(single, blockView);
            scrollToBlock(blockView);
        }
    }

    public void navigateToEvent(String targetId, String targetEventName, String blockId) {
        saveBlocks();
        Intent intent = new Intent(this, LogicEditorActivity.class);
        intent.putExtra("sc_id", scId);
        intent.putExtra("id", targetId);
        intent.putExtra("event", targetEventName);
        intent.putExtra("project_file", projectFile);
        intent.putExtra("event_text", targetId + " : " + targetEventName);
        if (blockId != null) {
            intent.putExtra("scroll_to_block_id", blockId);
        }
        startActivity(intent);
    }

    private static FirebaseCrashlytics getFirebaseCrashlytics() {
        try {
            return FirebaseCrashlytics.getInstance();
        } catch (IllegalStateException e) {
            return null;
        }
    }
    
    private String buildViewContext() {
		StringBuilder sb = new StringBuilder();
		java.util.ArrayList<pro.sketchware.beans.ViewBean> views = ProjectDataManager.getProjectDataManager(scId).getViews(projectFile.getXmlName());
		if (views == null) return "";
		for (pro.sketchware.beans.ViewBean view : views) {
			if (view.id == null || view.id.isEmpty()) continue;
			sb.append(view.id)
			.append(": ")
			.append(pro.sketchware.beans.ViewBean.getViewTypeName(view.type))
			.append("\n");
		}
		return sb.toString();
	}
	
	private String buildExistingEventCode() {
		try {
    		ProjectFilePaths projectFilePaths = new ProjectFilePaths(this, scId);
            projectFilePaths.initializeMetadata(ProjectDataManager.getLibraryManager(scId), ProjectDataManager.getFileManager(scId), ProjectDataManager.getProjectDataManager(scId));
            String code = new BlockInterpreter(projectFile.getActivityName(), projectFilePaths.buildConfig, blockPane.getBlocks(), isViewBindingEnabled, projectFile.getXmlName()).interpretBlocks();
		    return code == null ? "" : code.trim();
		} catch (Exception e) {
			return "";
		}
	}
	
	/**
* يعرض حوار إدخال حيث يكتب المستخدم وصف ما يريد توليده، ثم يبدأ التوليد.
*/	
    private void showAiCodePromptDialog() {
		int dp24 = (int) (24 * getResources().getDisplayMetrics().density);
		int dp16 = (int) (16 * getResources().getDisplayMetrics().density);
		int dp8 = (int) (8 * getResources().getDisplayMetrics().density);
		
		LinearLayout root = new LinearLayout(this);
		root.setOrientation(LinearLayout.VERTICAL);
		root.setPadding(dp24, dp24, dp24, dp8);
		
		TextView title = new TextView(this);
		title.setText(R.string.option_generate_with_ai);
		title.setTextSize(20);
		title.setTypeface(null, android.graphics.Typeface.BOLD);
		title.setTextColor(pro.sketchware.util.ThemeUtils.getColor(this, com.google.android.material.R.attr.colorOnSurface));
		root.addView(title);
		
		TextView subtitle = new TextView(this);
		subtitle.setText(getString(R.string.ai_code_subtitle_format, eventName));
		subtitle.setTextSize(14);
		subtitle.setTextColor(pro.sketchware.util.ThemeUtils.getColor(this, com.google.android.material.R.attr.colorOnSurfaceVariant));
		LinearLayout.LayoutParams subParams = new LinearLayout.LayoutParams(-1, -2);
		subParams.setMargins(0, dp8, 0, dp16);
		subtitle.setLayoutParams(subParams);
		root.addView(subtitle);
		
		com.google.android.material.card.MaterialCardView card = new com.google.android.material.card.MaterialCardView(this);
		card.setCardElevation(0);
		card.setRadius(dp8);
		card.setStrokeWidth((int) (1 * getResources().getDisplayMetrics().density));
		card.setStrokeColor(pro.sketchware.util.ThemeUtils.getColor(this, com.google.android.material.R.attr.colorOutlineVariant));
		card.setCardBackgroundColor(pro.sketchware.util.ThemeUtils.getColor(this, com.google.android.material.R.attr.colorSurfaceVariant));
		
		EditText editText = new EditText(this);
		editText.setHint(R.string.ai_code_hint);
		editText.setBackground(null);
		editText.setPadding(dp16, dp16, dp16, dp16);
		editText.setInputType(android.text.InputType.TYPE_CLASS_TEXT
		| android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE
		| android.text.InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
		editText.setMinLines(4);
		editText.setMaxLines(10);
		editText.setGravity(android.view.Gravity.TOP | android.view.Gravity.START);
		editText.setTextColor(pro.sketchware.util.ThemeUtils.getColor(this, com.google.android.material.R.attr.colorOnSurface));
		editText.setHintTextColor(pro.sketchware.util.ThemeUtils.getColor(this, com.google.android.material.R.attr.colorOutline));
		
		card.addView(editText, new ViewGroup.LayoutParams(-1, -2));
		root.addView(card, new LinearLayout.LayoutParams(-1, -2));
		
		new com.google.android.material.dialog.MaterialAlertDialogBuilder(this)
		.setView(root)
		.setNegativeButton(R.string.btn_cancel, null)
		.setPositiveButton(R.string.btn_generate, (dialog, which) -> {
			String userIntent = editText.getText() == null ? "" : editText.getText().toString().trim();
			if (userIntent.isEmpty()) {
				pro.sketchware.util.SketchwareUtil.toastError(getString(R.string.ai_toast_enter_description));
				return;
			}
			generateCodeWithAi(userIntent);
		})
		.show();
	}
	
	/**
* يطلب من نموذج AI توليد كود Java حسب الوصف (userIntent).
* التنفيذ في خيط خلفي؛ عند النجاح يعرض حوار يسمح للمستخدم بنسخ/حفظ/إدراج الكود.
*/	
	
	public void generateCodeWithAi(String userIntent) {
		if (userIntent == null || userIntent.trim().isEmpty()) {
			Toast.makeText(this, getString(R.string.ai_toast_enter_description_alt), Toast.LENGTH_SHORT).show();
			return;
		}
		
		String viewContext = buildViewContext();
		String existingCode = buildExistingEventCode();
		String activityName = projectFile.getActivityName();
		
		// الآن استعمل LogicGenTask
		LogicGenTask task = new LogicGenTask(getApplicationContext(), userIntent, eventName, activityName, viewContext, existingCode);
		
		// بناء Material dialog مع ProgressBar (مثال: استخدم layout ai_progress_dialog.xml كما اقترحت سابقاً)
		MaterialAlertDialogBuilder dialogBuilder = new MaterialAlertDialogBuilder(this);
		dialogBuilder.setTitle(R.string.ai_dialog_generating);
		View progressView = LayoutInflater.from(this).inflate(R.layout.ai_progress_dialog, null, false);
		dialogBuilder.setView(progressView);
		dialogBuilder.setCancelable(true);
		final androidx.appcompat.app.AlertDialog progressDialog = dialogBuilder.create();
		progressDialog.show();
		
		// ابدأ المهمة وخذ الـ handle
		activeAiRequest = task.start(new AiProviderService.StreamListener() {
			@Override
			public void onContent(String delta) { }
			
			@Override
			public void onReasoning(String delta) { }
			
			@Override
			public void onToolCall(String name, String arguments, String id) { }
			
			@Override
			public void onFinalMessage(String fullContent, String fullReasoning) {
				try { progressDialog.dismiss(); } catch (Exception ignored) {}
				String code = fullContent == null ? "" : fullContent;
				if (code.trim().isEmpty()) {
					Toast.makeText(LogicEditorActivity.this, getString(R.string.ai_toast_no_result), Toast.LENGTH_SHORT).show();
					return;
				}
				runConversion(code, () -> BlocksConverter.convert(code));
			}
			
			@Override
			public void onDebug(String message) { /* optional */ }
			
			@Override
			public void onError(String message, Throwable t) {
				try { progressDialog.dismiss(); } catch (Exception ignored) {}
				if (t != null) {
					Toast.makeText(LogicEditorActivity.this, getString(R.string.ai_toast_generation_failed, t.getMessage()), Toast.LENGTH_LONG).show();
				} else {
					Toast.makeText(LogicEditorActivity.this, getString(R.string.ai_toast_request_error, message), Toast.LENGTH_LONG).show();
				}
			}
		});
		
		// ربط إلغاء الحوار بإلغاء الطلب
		progressDialog.setOnCancelListener(d -> {
			if (activeAiRequest != null) activeAiRequest.cancel();
		});
		progressDialog.getButton(android.app.AlertDialog.BUTTON_NEGATIVE); // optional if you added button
		
	}
	
	
	
	
	/**
* يعرض الشيفرة في CodeViewerActivity ثم يظهر حوار مع خيارات (Copy / Save to app / Close).
* استعمل هذا بدلاً من AlertDialog.setMessage لكود طويل.
*/	
	private void openCodeInViewerWithActions(String code) {
		// افتح viewer المدمج في المشروع لعرض الشيفرة مع تمييز/تمرير
		try {
			Intent intent = new Intent(this, CodeViewerActivity.class);
			intent.putExtra("code", code);
			intent.putExtra("sc_id", scId);
			intent.putExtra("scheme", CodeViewerActivity.SCHEME_JAVA);
			startActivity(intent);
		} catch (Exception e) {
			// إن لم يتوفر CodeViewerActivity لأي سبب، نواصل دون فشل
			if (crashlytics != null) crashlytics.recordException(e);
		}
		
		// عرض حوار إجراءاتٍ إضافية
		new AlertDialog.Builder(this)
		.setTitle("AI Result")
		.setMessage("The generated code is opened in the viewer. You can copy it or save it to the app storage.")
		.setPositiveButton("Copy", (dialog, which) -> {
			ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
			if (cm != null) {
				cm.setPrimaryClip(ClipData.newPlainText("generated_java", code));
				Toast.makeText(this, "Copied to clipboard", Toast.LENGTH_SHORT).show();
			} else {
				Toast.makeText(this, "Clipboard not available", Toast.LENGTH_SHORT).show();
			}
		})
		.setNegativeButton("Save to app", (dialog, which) -> {
			boolean ok = saveGeneratedCodeToFile("generated_ai_code_" + System.currentTimeMillis() + ".java", code);
			Toast.makeText(this, ok ? "Saved to internal storage" : "Save failed", Toast.LENGTH_SHORT).show();
		})
		.setNeutralButton("Close", null)
		.show();
	}
	
	
	/** حفظ ابتدائي داخل مجلد ملفات التطبيق */
	private boolean saveGeneratedCodeToFile(String fileName, String code) {
		if (fileName == null || fileName.trim().isEmpty() || code == null) return false;
		try {
			java.io.File dir = new java.io.File(getFilesDir(), "ai_generated_code");
			if (!dir.exists()) dir.mkdirs();
			java.io.File out = new java.io.File(dir, fileName);
			try (java.io.FileOutputStream fos = new java.io.FileOutputStream(out)) {
				fos.write(code.getBytes(java.nio.charset.StandardCharsets.UTF_8));
				fos.flush();
			}
			return true;
		} catch (Exception e) {
			try { if (crashlytics != null) crashlytics.recordException(e); } catch (Exception ignored) {}
			return false;
		}
	}
	
	private void showCodeToBlocksDialog() {
		int dp24 = (int) (24 * getResources().getDisplayMetrics().density);
		int dp16 = (int) (16 * getResources().getDisplayMetrics().density);
		int dp8 = (int) (8 * getResources().getDisplayMetrics().density);
		
		LinearLayout root = new LinearLayout(this);
		root.setOrientation(LinearLayout.VERTICAL);
		root.setPadding(dp24, dp24, dp24, dp8);
		
		TextView title = new TextView(this);
		title.setText(R.string.code_to_blocks_title);
		title.setTextSize(20);
		title.setTypeface(null, android.graphics.Typeface.BOLD);
		title.setTextColor(pro.sketchware.util.ThemeUtils.getColor(this, com.google.android.material.R.attr.colorOnSurface));
		root.addView(title);
		
		TextView subtitle = new TextView(this);
		subtitle.setText(R.string.code_to_blocks_subtitle);
		subtitle.setTextSize(14);
		subtitle.setTextColor(pro.sketchware.util.ThemeUtils.getColor(this, com.google.android.material.R.attr.colorOnSurfaceVariant));
		LinearLayout.LayoutParams subParams = new LinearLayout.LayoutParams(-1, -2);
		subParams.setMargins(0, dp8, 0, dp16);
		subtitle.setLayoutParams(subParams);
		root.addView(subtitle);
		
		com.google.android.material.card.MaterialCardView card = new com.google.android.material.card.MaterialCardView(this);
		card.setCardElevation(0);
		card.setRadius(dp8);
		card.setStrokeWidth((int)(1 * getResources().getDisplayMetrics().density));
		card.setStrokeColor(pro.sketchware.util.ThemeUtils.getColor(this, com.google.android.material.R.attr.colorOutlineVariant));
		card.setCardBackgroundColor(pro.sketchware.util.ThemeUtils.getColor(this, com.google.android.material.R.attr.colorSurfaceVariant));
		
		EditText editText = new EditText(this);
		editText.setHint(R.string.code_to_blocks_hint);
		editText.setBackground(null); // Transparent background
		editText.setPadding(dp16, dp16, dp16, dp16);
		editText.setInputType(android.text.InputType.TYPE_CLASS_TEXT 
		| android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE 
		| android.text.InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
		editText.setMinLines(8);
		editText.setMaxLines(18);
		editText.setGravity(android.view.Gravity.TOP | android.view.Gravity.START);
		editText.setVerticalScrollBarEnabled(true);
		editText.setTypeface(android.graphics.Typeface.MONOSPACE);
		editText.setTextColor(pro.sketchware.util.ThemeUtils.getColor(this, com.google.android.material.R.attr.colorOnSurface));
		editText.setHintTextColor(pro.sketchware.util.ThemeUtils.getColor(this, com.google.android.material.R.attr.colorOutline));
		
		card.addView(editText, new ViewGroup.LayoutParams(-1, -2));
		root.addView(card, new LinearLayout.LayoutParams(-1, -2));
		
		new com.google.android.material.dialog.MaterialAlertDialogBuilder(this)
		.setView(root)
		.setNegativeButton(R.string.btn_cancel, null)
		.setPositiveButton(R.string.btn_convert, (dialog, which) -> {
			String code = editText.getText() == null ? "" : editText.getText().toString().trim();
			
			if (code.isEmpty()) {
				pro.sketchware.util.SketchwareUtil.toastError(getString(R.string.code_to_blocks_error_empty));
				return;
			} else {
				runConversion(code, () -> BlocksConverter.convert(code));
			}
			
			
			
		})
		.show();
	}
	
	private void runConversion(String code, java.util.function.Supplier<BlocksConverter.ConversionResult> converterCall) {
		BlocksConverter.ConversionResult result;
		try {
			result = converterCall.get();
		} catch (Throwable t) {
			pro.sketchware.util.SketchwareUtil.toastError(getString(R.string.converter_error_failed, t.getMessage()));
			return;
		}
		
		if (result == null || result.error != null) {
			String detail = result == null ? getString(R.string.converter_no_result) : result.error;
			pro.sketchware.util.SketchwareUtil.toastError(getString(R.string.converter_error_could_not_convert, detail));
			return;
		}
		
		int total    = result.blocks.size();
		int rec      = result.recognizedCount;
		int fallback = result.fallbackCount;
		
		String blockWord = getString(total == 1 ? R.string.word_block : R.string.word_blocks);
		String recBlockWord = getString(rec == 1 ? R.string.word_block : R.string.word_blocks);
		String fallbackBlockWord = getString(fallback == 1 ? R.string.word_block : R.string.word_blocks);

		String msg = getString(R.string.conversion_summary_msg, rec, recBlockWord, fallback, fallbackBlockWord, total, blockWord);
		
		new MaterialAlertDialogBuilder(this)
		.setTitle(R.string.conversion_dialog_title)
		.setMessage(msg)
		.setNegativeButton(R.string.conversion_btn_go_back, null)
		.setPositiveButton(R.string.conversion_btn_insert, (d2, w2) -> insertConvertedBlocks(result.blocks))
		.show();
	}
	
	private void insertConvertedBlocks(java.util.ArrayList<pro.sketchware.beans.BlockBean> blocks) {
        if (blocks == null || blocks.isEmpty()) {
            pro.sketchware.util.SketchwareUtil.toastError(getString(R.string.blocks_toast_no_blocks));
            return;
        }
        int[] oLoc = new int[2];
        blockPane.getLocationOnScreen(oLoc);
        int insertX = oLoc[0] + pro.sketchware.util.SketchwareUtil.dpToPx(16);
        int insertY = oLoc[1] + pro.sketchware.util.SketchwareUtil.dpToPx(80);
    
        java.util.ArrayList<pro.sketchware.beans.BlockBean> inserted = addBlockBeans(blocks, insertX, insertY, true);
        BlockHistoryManager.getInstance(scId).recordAddMultiple(buildHistoryKey(), inserted, insertX - oLoc[0], insertY - oLoc[1], null, null);
        refreshOptionsMenu();
    
        String insertedBlockWord = getString(inserted.size() != 1 ? R.string.word_blocks : R.string.word_block);
        pro.sketchware.util.SketchwareUtil.toast(
            getString(R.string.blocks_toast_inserted, inserted.size(), insertedBlockWord));
    }
    
    public void openGoogleTranslate(String text) {
    	try {
    		// محاولة فتح الترجمة كنافذة عائمة (Process Text)
    		Intent i = new Intent();
    		i.setAction(Intent.ACTION_PROCESS_TEXT);
    		i.setType("text/plain");
    		i.putExtra(Intent.EXTRA_PROCESS_TEXT, text);
    		i.putExtra(Intent.EXTRA_PROCESS_TEXT_READONLY, false);
    		i.setPackage("com.google.android.apps.translate");
    		startActivity(i);
    	} catch (Exception e) {
    		try {
    			// إذا فشل، نفتح التطبيق كإرسال عادي (Send) كما في Apktool M
    			Intent i = new Intent(Intent.ACTION_SEND);
    			i.setType("text/plain");
    			i.putExtra(Intent.EXTRA_TEXT, text);
    			i.setPackage("com.google.android.apps.translate");
    			startActivity(i);
    		} catch (Exception e2) {
    			Toast.makeText(this, "تعذر فتح متصفح الترجمة", Toast.LENGTH_SHORT).show();
    		}
    	}
    }
}

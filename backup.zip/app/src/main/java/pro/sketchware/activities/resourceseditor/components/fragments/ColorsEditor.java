package pro.sketchware.activities.resourceseditor.components.fragments;

import static pro.sketchware.util.UI.animateLayoutChanges;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import pro.sketchware.widgets.ColorPickerDialog;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.IdentityHashMap;
import java.util.Objects;

import pro.sketchware.util.Helper;
import pro.sketchware.util.ProjectFile;
import pro.sketchware.R;
import pro.sketchware.activities.resourceseditor.ResourcesEditorActivity;
import pro.sketchware.activities.resourceseditor.components.adapters.ColorsAdapter;
import pro.sketchware.activities.resourceseditor.components.utils.ColorsEditorManager;
import pro.sketchware.core.resources.ColorModel;
import pro.sketchware.databinding.ColorEditorAddBinding;
import pro.sketchware.databinding.ResourcesEditorFragmentBinding;
import pro.sketchware.util.FileUtil;
import pro.sketchware.util.PropertiesUtil;
import pro.sketchware.util.SketchwareUtil;
import pro.sketchware.util.XmlUtil;

public class ColorsEditor extends Fragment {

    public static String contentPath;
    public final ArrayList<ColorModel> colorList = new ArrayList<>();
    public final HashMap<String, String> defaultColors = new HashMap<>();
    private ResourcesEditorActivity activity;
    public ColorsAdapter adapter;
    public boolean hasUnsavedChanges;
    public ColorsEditorManager colorsEditorManager;
    private ResourcesEditorFragmentBinding binding;
    private boolean isNightVariant;
    private HashMap<Integer, String> notesMap = new HashMap<>();

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        activity = (ResourcesEditorActivity) getActivity();
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        binding = ResourcesEditorFragmentBinding.inflate(inflater, container, false);
        initialize();
        return binding.getRoot();
    }

    public void updateColorsList(String filePath, int updateMode, boolean hasUnsavedChangesStatus) {
        hasUnsavedChanges = hasUnsavedChangesStatus;
        contentPath = filePath;
        colorsEditorManager.contentPath = contentPath;

        boolean isSkippingMode = updateMode == 1;
        boolean isMergeAndReplace = updateMode == 2;
        colorsEditorManager.isDefaultVariant = activity.variant.isEmpty();
        isNightVariant = activity.variant.contains("night");
        ArrayList<ColorModel> existingColors = new ArrayList<>(colorList);
        HashMap<Integer, String> existingNotes = new HashMap<>(notesMap);

        ArrayList<ColorModel> defaultColors = new ArrayList<>();

        if ((activity.variant.isEmpty() || hasUnsavedChanges) && !FileUtil.isExistFile(contentPath)) {
            String generatedContent = activity.projectFilePaths.getXMLColor();
            colorsEditorManager.parseColorsXML(defaultColors, generatedContent);
        } else {
            colorsEditorManager.parseColorsXML(defaultColors, FileUtil.readFileIfExist(contentPath));
        }
        HashMap<Integer, String> defaultNotes = new HashMap<>(colorsEditorManager.notesMap);

        if (isSkippingMode) {
            HashSet<String> existingColorNames = new HashSet<>();
            for (ColorModel existingModel : colorList) {
                existingColorNames.add(existingModel.getColorName());
            }

            for (ColorModel colorModel : defaultColors) {
                if (!existingColorNames.contains(colorModel.getColorName())) {
                    colorList.add(colorModel);
                }
            }
        } else {
            if (isMergeAndReplace) {
                HashSet<String> newColorNames = new HashSet<>();
                for (ColorModel color : defaultColors) {
                    newColorNames.add(color.getColorName());
                }

                colorList.removeIf(existingColor -> newColorNames.contains(existingColor.getColorName()));
            } else {
                colorList.clear();
            }
            colorList.addAll(defaultColors);
        }

        activity.runOnUiThread(() -> {
            if (!isAdded() || getActivity() == null || binding == null || activity.isFinishing() || activity.isDestroyed()) return;
            notesMap = rebuildNotesMap(existingColors, existingNotes, defaultColors, defaultNotes, colorList);
            adapter = new ColorsAdapter(colorsEditorManager, colorList, activity, notesMap);
            binding.recyclerView.setAdapter(adapter);
            activity.checkForInvalidResources();
            updateNoContentLayout();
            if (hasUnsavedChanges) {
                contentPath = activity.colorsFilePath;
            }
        });
    }

    private void updateNoContentLayout() {
        if (colorList.isEmpty()) {
            binding.noContentLayout.setVisibility(View.VISIBLE);
            binding.noContentTitle.setText(String.format(Helper.getResString(R.string.resource_manager_no_list_title), Helper.getResString(R.string.resource_type_color)));
            binding.noContentBody.setText(String.format(Helper.getResString(R.string.resource_manager_no_list_body), Helper.getResString(R.string.resource_type_color_lower)));
        } else {
            binding.noContentLayout.setVisibility(View.GONE);
        }
    }

    private void initialize() {

        defaultColors.put("colorAccent", ProjectFile.COLOR_ACCENT);
        defaultColors.put("colorPrimary", ProjectFile.COLOR_PRIMARY);
        defaultColors.put("colorPrimaryDark", ProjectFile.COLOR_PRIMARY_DARK);
        defaultColors.put("colorControlHighlight", ProjectFile.COLOR_CONTROL_HIGHLIGHT);
        defaultColors.put("colorControlNormal", ProjectFile.COLOR_CONTROL_NORMAL);

        colorsEditorManager = new ColorsEditorManager(activity.sc_id);
        colorsEditorManager.defaultColors = defaultColors;
    }

    public void showColorEditDialog(ColorModel colorModel, int position) {
        MaterialAlertDialogBuilder dialog = new MaterialAlertDialogBuilder(activity);
        ColorEditorAddBinding dialogBinding = ColorEditorAddBinding.inflate(getLayoutInflater());
        int originalIndex = colorModel != null ? colorList.indexOf(colorModel) : -1;

        if (colorModel != null) {
            dialogBinding.colorKeyInput.setText(colorModel.getColorName());
            dialogBinding.colorValueInput.setText(colorModel.getColorValue());
            if (defaultColors.containsKey(colorModel.getColorName())) {
                dialogBinding.colorKeyInput.setEnabled(false);
            }
            dialogBinding.stringHeaderInput.setText(originalIndex >= 0 ? notesMap.getOrDefault(originalIndex, "") : "");
            dialogBinding.colorPreview.setBackgroundColor(PropertiesUtil.parseColor(colorsEditorManager.getColorValue(activity.getApplicationContext(), colorModel.getColorValue(), 3, isNightVariant)));
            dialogBinding.importantNote.setVisibility(defaultColors.containsKey(colorModel.getColorName()) ? View.VISIBLE : View.GONE);

            dialog.setTitle(R.string.color_title_edit);

        } else {
            dialog.setTitle(R.string.color_title_create);
            dialogBinding.colorPreview.setBackgroundColor(0xFFFFFF);
        }

        dialogBinding.importantNote.setOnClickListener(view -> {
            animateLayoutChanges(dialogBinding.getRoot());
            dialogBinding.imgColorGuide.setVisibility(dialogBinding.imgColorGuide.getVisibility() == View.GONE ? View.VISIBLE : View.GONE);
        });

        dialogBinding.colorValueInput.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
            }

            @Override
            public void afterTextChanged(Editable s) {
                String value = s.toString();
                if (value.startsWith("#") && !PropertiesUtil.isHexColor(value)) {
                    dialogBinding.colorValueInputLayout.setError(Helper.getResString(R.string.error_invalid_hex_color_caps));
                    return;
                }
                dialogBinding.colorValueInput.setError(null);
                dialogBinding.colorPreview.setBackgroundColor(PropertiesUtil.parseColor(colorsEditorManager.getColorValue(activity.getApplicationContext(), s.toString(), 3, isNightVariant)));
            }
        });

        dialogBinding.colorKeyInput.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
            }

            @Override
            public void afterTextChanged(Editable s) {
                animateLayoutChanges(dialogBinding.getRoot());
                dialogBinding.importantNote.setVisibility(defaultColors.containsKey(s.toString()) ? View.VISIBLE : View.GONE);
            }
        });

        dialog.setPositiveButton(R.string.common_word_save, (v1, which) -> {
            String key = Objects.requireNonNull(dialogBinding.colorKeyInput.getText()).toString();
            String value = Objects.requireNonNull(dialogBinding.colorValueInput.getText()).toString();

            if (key.isEmpty() || value.isEmpty()) {
                SketchwareUtil.toastError(Helper.getResString(R.string.error_fill_all_fields), Toast.LENGTH_SHORT);
                return;
            }

            if (value.startsWith("#")) {
                if (!PropertiesUtil.isHexColor(value)) {
                    SketchwareUtil.toastError(Helper.getResString(R.string.error_invalid_hex_color));
                    return;
                }
            }

            if (colorModel != null) {
                int currentIndex = colorList.indexOf(colorModel);
                if (currentIndex < 0) {
                    SketchwareUtil.toastError(Helper.getResString(R.string.common_error_an_error_occurred));
                    return;
                }
                colorModel.setColorName(key);
                colorModel.setColorValue(value);

                String headerInput = Objects.requireNonNull(dialogBinding.stringHeaderInput.getText()).toString();
                if (headerInput.isEmpty()) {
                    notesMap.remove(currentIndex);
                } else {
                    notesMap.put(currentIndex, headerInput);
                }
                adapter = new ColorsAdapter(colorsEditorManager, colorList, activity, notesMap);
                binding.recyclerView.setAdapter(adapter);

            } else {
                addColor(key, value, Objects.requireNonNull(dialogBinding.stringHeaderInput.getText()).toString());
            }
            hasUnsavedChanges = true;
            updateNoContentLayout();
        });

        dialogBinding.colorPreviewCard.setOnClickListener(v -> {
            String inputColor = Objects.requireNonNull(dialogBinding.colorValueInput.getText()).toString().trim();
            String colorToPass = inputColor;
            
            // التحقق من صحة اللون إذا كان كود Hex لتجنب الانهيار
            if (inputColor.startsWith("#")) {
                try {
                    android.graphics.Color.parseColor(inputColor);
                } catch (Exception e) {
                    colorToPass = "#FFFFFF"; // تمرير لون افتراضي في حال كان الكود غير صالح أو غير مكتمل
                }
            } else if (inputColor.isEmpty()) {
                colorToPass = "#FFFFFF";
            }
            
            
            ColorPickerDialog colorPicker = new ColorPickerDialog(activity, Objects.requireNonNull(dialogBinding.colorValueInput.getText()).toString(), false, false, activity.sc_id);
            colorPicker.setColorPickerCallback(new ColorPickerDialog.OnColorPickedListener() {
                @Override
                public void onColorPicked(int colorInt) {
                    String selectedColorHex = String.format("#%06X", colorInt & 0x00FFFFFF);
                    dialogBinding.colorPreviewCard.setCardBackgroundColor(PropertiesUtil.parseColor(selectedColorHex));
                    dialogBinding.colorValueInput.setText(selectedColorHex);
                }

                @Override
                public void onResourceColorPicked(String var1, int var2) {
                }
            });
            colorPicker.materialColorAttr((attr, attrColor) -> dialogBinding.colorValueInput.setText("?" + attr));
            colorPicker.showAtLocation(v, Gravity.CENTER, 0, 0);
        });

        if (colorModel != null && !defaultColors.containsKey(colorModel.getColorName())) {
            dialog.setNeutralButton(R.string.common_word_delete, (v1, which) -> {
                int currentIndex = colorList.indexOf(colorModel);
                if (currentIndex >= 0) {
                    colorList.remove(colorModel);
                    notesMap.remove(currentIndex);
                    HashMap<Integer, String> reindexedNotes = new HashMap<>();
                    for (java.util.Map.Entry<Integer, String> entry : notesMap.entrySet()) {
                        int noteIndex = entry.getKey();
                        reindexedNotes.put(noteIndex > currentIndex ? noteIndex - 1 : noteIndex, entry.getValue());
                    }
                    notesMap.clear();
                    notesMap.putAll(reindexedNotes);
                } else {
                    SketchwareUtil.toastError(Helper.getResString(R.string.common_error_an_error_occurred));
                    return;
                }
                adapter = new ColorsAdapter(colorsEditorManager, colorList, activity, notesMap);
                binding.recyclerView.setAdapter(adapter);
                updateNoContentLayout();
                hasUnsavedChanges = true;
                v1.dismiss();
            });
        }

        dialog.setNegativeButton(Helper.getResString(R.string.cancel), null);
        dialog.setView(dialogBinding.getRoot());
        dialog.show();
    }

    private void addColor(String name, String value, String note) {
        ColorModel newItem = new ColorModel(name, value);
        for (int i = 0; i < colorList.size(); i++) {
            if (colorList.get(i).getColorName().equals(name)) {
                SketchwareUtil.toastError(String.format(Helper.getResString(R.string.error_key_already_exists), name));
                return;
            }
        }
        colorList.add(newItem);
        int notifyPosition = colorList.size() - 1;
        if (!note.isEmpty()) {
            notesMap.put(notifyPosition, note);
        }
        adapter = new ColorsAdapter(colorsEditorManager, colorList, activity, notesMap);
        binding.recyclerView.setAdapter(adapter);
        SketchwareUtil.toast(Helper.getResString(R.string.common_word_saved));
    }

    private <T> HashMap<Integer, String> rebuildNotesMap(ArrayList<T> existingItems,
                                                         HashMap<Integer, String> existingNotes,
                                                         ArrayList<T> importedItems,
                                                         HashMap<Integer, String> importedNotes,
                                                         ArrayList<T> finalItems) {
        IdentityHashMap<T, Integer> existingIndexes = new IdentityHashMap<>();
        for (int i = 0; i < existingItems.size(); i++) {
            existingIndexes.put(existingItems.get(i), i);
        }

        IdentityHashMap<T, Integer> importedIndexes = new IdentityHashMap<>();
        for (int i = 0; i < importedItems.size(); i++) {
            importedIndexes.put(importedItems.get(i), i);
        }

        HashMap<Integer, String> rebuiltNotes = new HashMap<>();
        for (int i = 0; i < finalItems.size(); i++) {
            T item = finalItems.get(i);

            Integer importedIndex = importedIndexes.get(item);
            if (importedIndex != null && importedNotes.containsKey(importedIndex)) {
                rebuiltNotes.put(i, importedNotes.get(importedIndex));
                continue;
            }

            Integer existingIndex = existingIndexes.get(item);
            if (existingIndex != null && existingNotes.containsKey(existingIndex)) {
                rebuiltNotes.put(i, existingNotes.get(existingIndex));
            }
        }

        return rebuiltNotes;
    }

    public void saveColorsFile() {
        if (hasUnsavedChanges) {
            XmlUtil.saveXml(contentPath, colorsEditorManager.convertListToXml(colorList, notesMap));
            hasUnsavedChanges = false;
        }
    }
}

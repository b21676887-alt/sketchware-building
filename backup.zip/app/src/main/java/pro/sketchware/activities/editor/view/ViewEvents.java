package pro.sketchware.activities.editor.view;

import android.content.Context;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.RecyclerView;

import pro.sketchware.beans.EventBean;
import pro.sketchware.beans.ProjectFileBean;
import pro.sketchware.beans.ViewBean;
import com.google.android.material.color.MaterialColors;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;

import java.util.ArrayList;

import pro.sketchware.core.callback.EventSelectedCallback;
import pro.sketchware.util.SketchToast;
import pro.sketchware.core.project.ProjectDataManager;
import pro.sketchware.core.codegen.EventRegistry;
import pro.sketchware.util.ViewUtil;
import pro.sketchware.util.Helper;
import pro.sketchware.R;
import pro.sketchware.databinding.EventGridItemBinding;

public class ViewEvents extends LinearLayout {
    private final ArrayList<EventBean> events = new ArrayList<>();
    private final EventAdapter eventAdapter = new EventAdapter();

    private String sc_id;
    private ProjectFileBean projectFileBean;
    private EventSelectedCallback onEventClickListener;

    public ViewEvents(Context context) {
        this(context, null);
    }

    public ViewEvents(Context context, AttributeSet attrs) {
        super(context, attrs);
        initialize(context);
    }

    private void initialize(Context context) {
        ViewUtil.inflateLayoutInto(context, this, R.layout.view_events);
        RecyclerView eventsList = findViewById(R.id.list_events);
        eventsList.setHasFixedSize(true);
        eventsList.setAdapter(eventAdapter);
        eventsList.setItemAnimator(new DefaultItemAnimator());
    }

    public void setOnEventClickListener(EventSelectedCallback listener) {
        onEventClickListener = listener;
    }

    void setData(String sc_id, ProjectFileBean projectFileBean, ViewBean viewBean) {
        this.sc_id = sc_id;
        this.projectFileBean = projectFileBean;

        String[] viewEvents = EventRegistry.getEventsForClass(viewBean.getClassInfo());
        events.clear();

        ArrayList<EventBean> alreadyAddedEvents = ProjectDataManager.getProjectDataManager(sc_id).getEvents(projectFileBean.getJavaName());
        for (String event : viewEvents) {
            boolean eventAlreadyInActivity = false;
            for (EventBean bean : alreadyAddedEvents) {
                if (bean.eventType == EventBean.EVENT_TYPE_VIEW && viewBean.id.equals(bean.targetId) && event.equals(bean.eventName)) {
                    eventAlreadyInActivity = true;
                    break;
                }
            }

            if (!event.equals("onBindCustomView") || !viewBean.customView.isEmpty() && !viewBean.customView.equals("none")) {
                EventBean eventBean = new EventBean(EventBean.EVENT_TYPE_VIEW, viewBean.type, viewBean.id, event);
                eventBean.isSelected = eventAlreadyInActivity;
                events.add(eventBean);
            }
        }

        eventAdapter.notifyDataSetChanged();
    }

    private void createEvent(int eventPosition) {
        EventBean eventBean = events.get(eventPosition);
        if (!eventBean.isSelected) {
            eventBean.isSelected = true;
            ProjectDataManager.getProjectDataManager(sc_id).addEventBean(projectFileBean.getJavaName(), eventBean);
            eventAdapter.notifyItemChanged(eventPosition);
            SketchToast.toast(getContext(), Helper.getResString(R.string.event_message_new_event), 0).show();
        }
        if (onEventClickListener != null) {
            onEventClickListener.onEventSelected(eventBean);
        }
    }

    private class EventAdapter extends RecyclerView.Adapter<EventAdapter.ViewHolder> {
        @Override
        public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
            EventBean eventBean = events.get(position);
            holder.bind(eventBean, position);
        }

        @Override
        @NonNull
        public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            LayoutInflater inflater = LayoutInflater.from(parent.getContext());
            EventGridItemBinding binding = EventGridItemBinding.inflate(inflater, parent, false);
            return new ViewHolder(binding);
        }

        @Override
        public int getItemCount() {
            return events.size();
        }

        private class ViewHolder extends RecyclerView.ViewHolder {
            public final EventGridItemBinding binding;

            public ViewHolder(EventGridItemBinding binding) {
                super(binding.getRoot());
                this.binding = binding;
            }

            public void bind(EventBean event, int position) {
                binding.container.setOnClickListener(v -> {
                    int pos = getLayoutPosition();
                    if (pos == RecyclerView.NO_POSITION) return;
                    createEvent(pos);
                });
                binding.imgIcon.setImageResource(EventRegistry.getEventIconResource(event.eventName));
                binding.tvTitle.setText(event.eventName);
                binding.tvTitle.setTextColor(MaterialColors.getColor(binding.tvTitle, event.isSelected ? com.google.android.material.R.attr.colorOnSurface : com.google.android.material.R.attr.colorOutline));
                binding.imgIcon.setColorFilter(MaterialColors.getColor(binding.tvTitle, event.isSelected ? com.google.android.material.R.attr.colorOnSurface : com.google.android.material.R.attr.colorOutline));
                binding.imgUsedEvent.setVisibility(event.isSelected ? View.GONE : View.VISIBLE);

                if (event.isSelected) {
                    binding.container.setOnLongClickListener(v -> {
                        MaterialAlertDialogBuilder dialog = new MaterialAlertDialogBuilder(itemView.getContext());
                        dialog.setIcon(R.drawable.delete_96);
                        dialog.setTitle(R.string.dialog_title_confirm_delete);
                        dialog.setMessage(R.string.dialog_msg_delete_event_confirm);

                        dialog.setPositiveButton(Helper.getResString(R.string.common_word_delete), (view, which) -> {
                            view.dismiss();
                            EventBean.deleteEvent(sc_id, event, projectFileBean);
                            SketchToast.toast(getContext(), Helper.getResString(R.string.common_message_complete_delete), 0).show();
                            event.isSelected = false;
                            eventAdapter.notifyItemChanged(position);
                        });
                        dialog.setNegativeButton(Helper.getResString(R.string.common_word_cancel), null);
                        dialog.show();
                        return true;
                    });
                }
            }
        }
    }
}

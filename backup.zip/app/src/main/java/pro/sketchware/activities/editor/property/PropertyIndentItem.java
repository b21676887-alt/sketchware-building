package pro.sketchware.activities.editor.property;

import android.annotation.SuppressLint;
import android.content.Context;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.google.android.material.dialog.MaterialAlertDialogBuilder;

import pro.sketchware.util.format.FormatUtil;
import pro.sketchware.core.callback.PropertyChangedCallback;
import pro.sketchware.util.UIHelper;
import pro.sketchware.util.ViewUtil;
import pro.sketchware.util.Helper;
import pro.sketchware.R;
import pro.sketchware.databinding.PropertyPopupInputIndentBinding;
import pro.sketchware.core.validation.MinMaxInputValidator;

@SuppressLint("ViewConstructor")
public class PropertyIndentItem extends RelativeLayout implements View.OnClickListener {

    /**
     * Left margin in dp
     */
    public int left;
    /**
     * Top margin in dp
     */
    public int top;
    /**
     * Right margin in dp
     */
    public int right;
    /**
     * Bottom margin in dp
     */
    public int bottom;
    private Context context;
    private String key = "";
    private View propertyItem;
    private View propertyMenuItem;
    private ImageView imgLeftIcon;
    private int icon;
    private TextView tvName;
    private TextView tvValue;
    private PropertyChangedCallback valueChangeListener;

    public PropertyIndentItem(Context context, boolean useAttrs) {
        super(context);
        initialize(context, useAttrs);
    }

    public String getKey() {
        return key;
    }

    public void setKey(String key) {
        this.key = key;
        int identifier = getResources().getIdentifier(key, "string", getContext().getPackageName());
        if (identifier > 0) {
            tvName.setText(Helper.getResString(identifier));
            switch (this.key) {
                case "property_padding":
                    icon = R.drawable.ic_mtrl_padding;
                    break;

                case "property_margin":
                    icon = R.drawable.ic_mtrl_margin;
                    break;
            }
            if (propertyMenuItem.getVisibility() == VISIBLE) {
                ((ImageView) findViewById(R.id.img_icon)).setImageResource(icon);
                ((TextView) findViewById(R.id.tv_title)).setText(Helper.getResString(identifier));
                return;
            }
            imgLeftIcon.setImageResource(icon);
        }
    }

    public String getValue() {
        return "";
    }

    @Override
    public void onClick(View v) {
        if (!UIHelper.isClickThrottled()) {
            switch (key) {
                case "property_padding":
                case "property_margin":
                    showDialog();
                    break;
            }
        }
    }

    public void setOnPropertyValueChangeListener(PropertyChangedCallback onPropertyValueChangeListener) {
        valueChangeListener = onPropertyValueChangeListener;
    }

    public void setOrientationItem(int orientationItem) {
        if (orientationItem == 0) {
            propertyItem.setVisibility(GONE);
            propertyMenuItem.setVisibility(VISIBLE);
            propertyItem.setOnClickListener(null);
            propertyMenuItem.setOnClickListener(this);
        } else {
            propertyItem.setVisibility(VISIBLE);
            propertyMenuItem.setVisibility(GONE);
            propertyItem.setOnClickListener(this);
            propertyMenuItem.setOnClickListener(null);
        }
    }

    private void initialize(Context context, boolean useAttrs) {
        this.context = context;
        ViewUtil.inflateLayoutInto(context, this, R.layout.property_input_item);
        tvName = findViewById(R.id.tv_name);
        tvValue = findViewById(R.id.tv_value);
        imgLeftIcon = findViewById(R.id.img_left_icon);
        propertyItem = findViewById(R.id.property_item);
        propertyMenuItem = findViewById(R.id.property_menu_item);
//        if (z) {
//            propertyMenuItem.setSoundEffectsEnabled(true);
//            propertyMenuItem.setOnClickListener(this);
//        }
    }

    public void setIndent(int left, int top, int right, int bottom) {
        this.left = left;
        this.top = top;
        this.right = right;
        this.bottom = bottom;
        tvValue.setText(Helper.getResString(R.string.property_indent_format, this.left, this.top, this.right, this.bottom));
    }

    private void showDialog() {
        String propertyType = Helper.getText(tvName);

        MaterialAlertDialogBuilder dialog = new MaterialAlertDialogBuilder(getContext());
        dialog.setTitle(propertyType);
        dialog.setIcon(icon);

        PropertyPopupInputIndentBinding binding = PropertyPopupInputIndentBinding.inflate(LayoutInflater.from(getContext()));
        View view = binding.getRoot();

        binding.tiAll.setHint(String.format(Helper.getResString(R.string.property_enter_value), propertyType.toLowerCase()));
        binding.chkPtyAll.setText(String.format(Helper.getResString(R.string.property_all_sides_format), propertyType));

        MinMaxInputValidator ti_all = new MinMaxInputValidator(context, binding.tiAll, 0, 999);
        MinMaxInputValidator ti_left = new MinMaxInputValidator(context, binding.tiLeft, 0, 999);
        MinMaxInputValidator ti_right = new MinMaxInputValidator(context, binding.tiRight, 0, 999);
        MinMaxInputValidator ti_top = new MinMaxInputValidator(context, binding.tiTop, 0, 999);
        MinMaxInputValidator ti_bottom = new MinMaxInputValidator(context, binding.tiBottom, 0, 999);

        ti_left.setText(String.valueOf(left));
        ti_top.setText(String.valueOf(top));
        ti_right.setText(String.valueOf(right));
        ti_bottom.setText(String.valueOf(bottom));

        if (left == top && top == right && right == bottom) { // All sides are equal
            ti_all.setText(String.valueOf(left));
            binding.chkPtyAll.setChecked(true);
        } else {
            binding.individualPaddingView.setVisibility(VISIBLE);
            binding.allPaddingView.setVisibility(GONE);
        }

        binding.chkPtyAll.setOnClickListener(v -> {
            if (binding.chkPtyAll.isChecked()) {
                binding.individualPaddingView.setVisibility(GONE);
                binding.allPaddingView.setVisibility(VISIBLE);
                binding.etLeft.setText(Helper.getText(binding.etAll));
                binding.etLeft.clearFocus();
                binding.etTop.clearFocus();
                binding.etRight.clearFocus();
                binding.etBottom.clearFocus();
            } else {
                binding.individualPaddingView.setVisibility(VISIBLE);
                binding.allPaddingView.setVisibility(GONE);
                binding.etAll.clearFocus();
            }
        });

        binding.etAll.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
            }

            @Override
            public void afterTextChanged(Editable s) {
                ti_left.setText(Helper.getText(binding.etAll));
                ti_top.setText(Helper.getText(binding.etAll));
                ti_right.setText(Helper.getText(binding.etAll));
                ti_bottom.setText(Helper.getText(binding.etAll));
            }
        });

        binding.tvDpAll.setVisibility(View.GONE);
        binding.tvDpBottom.setVisibility(View.GONE);
        binding.tvDpLeft.setVisibility(View.GONE);
        binding.tvDpRight.setVisibility(View.GONE);
        binding.tvDpTop.setVisibility(View.GONE);

        binding.tiAll.setSuffixText("dp");
        binding.tiBottom.setSuffixText("dp");
        binding.tiLeft.setSuffixText("dp");
        binding.tiRight.setSuffixText("dp");
        binding.tiTop.setSuffixText("dp");

        dialog.setView(view);
        dialog.setPositiveButton(Helper.getResString(R.string.common_word_save), (v, which) -> {
            if (binding.chkPtyAll.isChecked()) {
                if (ti_all.isValid() && ti_left.isValid() && ti_right.isValid() && ti_top.isValid() && ti_bottom.isValid()) {
                    int left = FormatUtil.safeParseInt(Helper.getText(binding.etLeft), 0);
                    int top = FormatUtil.safeParseInt(Helper.getText(binding.etTop), 0);
                    int right = FormatUtil.safeParseInt(Helper.getText(binding.etRight), 0);
                    int bottom = FormatUtil.safeParseInt(Helper.getText(binding.etBottom), 0);
                    setIndent(left, top, right, bottom);
                    if (valueChangeListener != null) {
                        valueChangeListener.onPropertyChanged(key, new int[]{left, top, right, bottom});
                    }
                    v.dismiss();
                }
            } else if (ti_left.isValid() && ti_right.isValid() && ti_top.isValid() && ti_bottom.isValid()) {
                int left = FormatUtil.safeParseInt(Helper.getText(binding.etLeft), 0);
                int top = FormatUtil.safeParseInt(Helper.getText(binding.etTop), 0);
                int right = FormatUtil.safeParseInt(Helper.getText(binding.etRight), 0);
                int bottom = FormatUtil.safeParseInt(Helper.getText(binding.etBottom), 0);
                setIndent(left, top, right, bottom);
                if (valueChangeListener != null) {
                    valueChangeListener.onPropertyChanged(key, new int[]{left, top, right, bottom});
                }
                v.dismiss();
            }
        });
        dialog.setNegativeButton(Helper.getResString(R.string.common_word_cancel), null);
        dialog.show();
    }
}

package pro.sketchware.activities.editor.property;


import pro.sketchware.util.Helper;
import pro.sketchware.util.format.FormatUtil;
import pro.sketchware.activities.editor.PropertyActivity;
import android.content.Context;
import android.util.Pair;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlPullParserFactory;

import java.io.IOException;
import java.io.StringReader;
import java.util.LinkedHashMap;
import java.util.stream.Collectors;

import pro.sketchware.beans.BlockBean;
import pro.sketchware.beans.EventBean;
import pro.sketchware.beans.LayoutBean;
import pro.sketchware.beans.ProjectFileBean;
import pro.sketchware.beans.ViewBean;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map.Entry;

import pro.sketchware.core.project.RecentHistoryManager;
import pro.sketchware.core.project.ClassInfo;
import pro.sketchware.core.callback.PropertyChangedCallback;
import pro.sketchware.core.callback.ViewBeanCallback;
import pro.sketchware.core.project.ViewHistoryManager;
import pro.sketchware.core.project.ProjectDataManager;
import pro.sketchware.util.UIHelper;
import pro.sketchware.core.codegen.EventRegistry;
import pro.sketchware.core.project.ProjectSettings;
import pro.sketchware.core.build.ViewBindingBuilder;
import pro.sketchware.beans.ViewBeans;
import pro.sketchware.R;

public class ViewPropertyItems extends LinearLayout implements PropertyChangedCallback, View.OnClickListener {
    private final boolean isEditMode = false;
    private final HashMap<String, View> propertyViewCache = new HashMap<>();
    private String sc_id;
    private ViewBean viewBean;
    private ViewBeanCallback viewBeanCallback;
    private ProjectFileBean projectFile;
    private ProjectSettings settings;

    public ViewPropertyItems(Context context) {
        super(context);
        RecentHistoryManager.getInstance().initialize(context);
    }

    public void setProjectId(String scId) {
        if (!isSameProject(sc_id, scId)) {
            propertyViewCache.clear();
            sc_id = scId;
        }
    }

    private boolean isSameProject(String firstId, String secondId) {
        return firstId == null ? secondId == null : firstId.equals(secondId);
    }

    private void setupViews() {
        LayoutParams params = new LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT);
        params.gravity = Gravity.CENTER;
        setLayoutParams(params);
        setGravity(Gravity.CENTER);
        TextView label = new TextView(getContext());
        label.setGravity(Gravity.CENTER);
        label.setPadding(8, 8, 8, 8);
        label.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
        label.setText(R.string.design_property_recent_message_nodata);
        addView(label);
    }
    
    private String getInjectedAttr(ViewBean bean, String attrName) {
        LinkedHashMap<String, String> attributes = parseInjectString(bean.inject);
        String value = attributes.get(attrName);
        return value == null ? "" : value;
    }

    private String setInjectedAttr(ViewBean bean, String attrName, String newValue) {
        LinkedHashMap<String, String> attributes = parseInjectString(bean.inject);
        if (newValue == null || newValue.isEmpty()) {
            attributes.remove(attrName);
        } else {
            attributes.put(attrName, newValue);
        }
        return attributes.entrySet().stream()
                .map(entry -> entry.getKey() + "=\"" + entry.getValue() + "\"")
                .collect(Collectors.joining("\n"));
    }
    
    private LinkedHashMap<String, String> parseInjectString(String inject) {
        LinkedHashMap<String, String> attributes = new LinkedHashMap<>();
        if (inject == null || inject.trim().isEmpty()) return attributes;
    
        try {
            XmlPullParserFactory factory = XmlPullParserFactory.newInstance();
            XmlPullParser parser = factory.newPullParser();
            parser.setInput(new StringReader("<tag " + inject + "></tag>"));
    
            int eventType = parser.getEventType();
            while (eventType != XmlPullParser.END_DOCUMENT) {
                if (eventType == XmlPullParser.START_TAG) {
                    for (int i = 0; i < parser.getAttributeCount(); i++) {
                        attributes.put(parser.getAttributeName(i), parser.getAttributeValue(i));
                    }
                }
                eventType = parser.next();
            }
        } catch (XmlPullParserException | IOException | RuntimeException ignored) {
        }
    
        return attributes;
    }

    private void addMarginAndGravityProperties(ViewBean bean) {
        if (getOrientation() == LinearLayout.VERTICAL) {
            addSubheader(Helper.getResString(R.string.property_header_layout));
        }

        addPropertyForBean(bean, "property_margin");
        addPropertyForBean(bean, "property_layout_gravity");
    }

    private void addPropertyForBean(ViewBean bean, String property) {
        boolean isNotAdview = !bean.getClassInfo().matchesType("AdView");
        boolean isGeneratedId = bean.id != null && !bean.id.isEmpty() && bean.id.charAt(0) == '_';

        switch (property) {
            case "property_id" -> {
                String id = isGeneratedId ? bean.id.substring(1) : bean.id;
                addInputProperty(property, id, isGeneratedId, null);
            }
            case "property_layout_width" -> addMeasureProperty(property, bean.layout.width, isNotAdview);
            case "property_layout_height" -> addMeasureProperty(property, bean.layout.height, isNotAdview);
            case "property_parent_attr" -> setupAttributes(property, bean.parentAttributes);
            case "property_margin" -> {
                LayoutBean layoutBean = bean.layout;
                addIndentProperty(property, layoutBean.marginLeft, layoutBean.marginTop, layoutBean.marginRight, layoutBean.marginBottom);
            }
            case "property_padding" -> {
                LayoutBean layoutBean = bean.layout;
                addIndentProperty("property_padding", layoutBean.paddingLeft, layoutBean.paddingTop, layoutBean.paddingRight, layoutBean.paddingBottom);
            }
            case "property_orientation" -> addSelectorProperty(property, bean.layout.orientation);
            case "property_weight_sum" -> addSimpleInputProperty(property, String.valueOf(bean.layout.weightSum));
            case "property_gravity" -> addGravityProperty(property, bean.layout.gravity);
            case "property_layout_gravity" -> addGravityProperty(property, bean.layout.layoutGravity);
            case "property_weight" -> addSimpleInputProperty(property, String.valueOf(bean.layout.weight));
            case "property_elevation" -> addSimpleInputProperty(property, String.valueOf(bean.layout.elevation));
            case "property_visibility" -> addSimpleInputProperty(property, getInjectedAttr(bean, "android:visibility"));
            case "property_text" -> addSimpleInputProperty(property, bean.text.text);
            case "property_text_size" -> addSimpleInputProperty(property, String.valueOf(bean.text.textSize));
            case "property_text_style" -> addSelectorProperty(property, bean.text.textType);
            case "property_text_color" -> addColorProperty(property, bean.text.resTextColor, bean.text.textColor);
            case "property_hint" -> addSimpleInputProperty(property, bean.text.hint);
            case "property_hint_color" -> addColorProperty(property, bean.text.resHintColor, bean.text.hintColor);
            case "property_single_line" -> addSwitchProperty(property, bean.text.singleLine);
            case "property_lines" -> addSimpleInputProperty(property, String.valueOf(bean.text.line));
            case "property_input_type" -> addSelectorProperty(property, bean.text.inputType);
            case "property_ime_option" -> addSelectorProperty(property, bean.text.imeOption);
            case "property_image" -> addResourceProperty(property, bean.image.resName, true);
            case "property_scale_type" -> addStringSelectorProperty(property, bean.image.scaleType);
            case "property_background_resource" ->
                    addResourceProperty(property, bean.layout.backgroundResource, false);
            case "property_background_color" ->
                    addColorProperty(property, bean.layout.backgroundResColor, bean.layout.backgroundColor);
            case "property_enabled" -> addSwitchProperty(property, bean.enabled);
            case "property_rotate" -> addSimpleInputProperty(property, String.valueOf(bean.image.rotate));
            case "property_alpha" -> addSimpleInputProperty(property, String.valueOf(bean.alpha));
            case "property_translation_x" -> addSimpleInputProperty(property, String.valueOf(bean.translationX));
            case "property_translation_y" -> addSimpleInputProperty(property, String.valueOf(bean.translationY));
            case "property_scale_x" -> addSimpleInputProperty(property, String.valueOf(bean.scaleX));
            case "property_scale_y" -> addSimpleInputProperty(property, String.valueOf(bean.scaleY));
            case "property_spinner_mode" -> addSelectorProperty(property, bean.spinnerMode);
            case "property_divider_height" -> addSizeProperty(property, bean.dividerHeight);
            case "property_custom_view_listview" -> addCustomViewProperty(property, bean.customView);
            case "property_checked" -> addSwitchProperty(property, bean.checked);
            case "property_max" -> addSimpleInputProperty(property, String.valueOf(bean.max));
            case "property_progress" -> addSimpleInputProperty(property, String.valueOf(bean.progress));
            case "property_first_day_of_week" -> addSelectorProperty(property, bean.firstDayOfWeek);
            case "property_ad_size" -> addStringSelectorProperty(property, bean.adSize);
            case "property_progressbar_style" -> addStringPairSelectorProperty(property, bean.progressStyle);
            case "property_indeterminate" -> addStringSelectorProperty(property, bean.indeterminate);
            case "property_inject" -> addSimpleInputProperty(property, bean.inject);
            case "property_convert" -> addTypedInputProperty(property, bean.convert, String.valueOf(bean.type));
        }
    }

    private void addSubheader(String header) {
        var sub = new PropertySubheader(getContext());
        sub.setHeaderName(header);
        addView(sub);
    }

    private void addSimpleColorProperty(String name, int value) {
        PropertyColorItem colorItem = propertyViewCache.get(name) instanceof PropertyColorItem c ? c : null;
        if (colorItem == null) {
            colorItem = new PropertyColorItem(getContext(), !isEditMode);
            colorItem.setOrientationItem(getOrientation());
            colorItem.setKey(name);
            colorItem.setValue(value);
            colorItem.setTag(name);
            colorItem.setOnPropertyValueChangeListener(this);
            propertyViewCache.put(name, colorItem);
        } else {
            colorItem.setValue(value);
        }

        addView(colorItem);
    }

    private void addIndentProperty(String key, int left, int top, int right, int bottom) {
        PropertyIndentItem indentItem = propertyViewCache.get(key) instanceof PropertyIndentItem c ? c : null;
        if (indentItem == null) {
            indentItem = new PropertyIndentItem(getContext(), !isEditMode);
            indentItem.setOrientationItem(getOrientation());
            indentItem.setKey(key);
            indentItem.setIndent(left, top, right, bottom);
            indentItem.setTag(key);
            indentItem.setOnPropertyValueChangeListener(this);
            propertyViewCache.put(key, indentItem);
        } else {
            indentItem.setIndent(left, top, right, bottom);
        }

        addView(indentItem);
    }

    private void addColorProperty(String name, String value, int value2) {
        PropertyColorItem colorItem = propertyViewCache.get(name) instanceof PropertyColorItem c ? c : null;
        if (colorItem == null) {
            colorItem = new PropertyColorItem(getContext(), !isEditMode, sc_id);
            colorItem.setOrientationItem(getOrientation());
            colorItem.setKey(name);
            colorItem.setValue(value2, value);
            colorItem.setTag(name);
            colorItem.setOnPropertyValueChangeListener(this);
            propertyViewCache.put(name, colorItem);
        } else {
            colorItem.setValue(value2, value);
        }
        addView(colorItem);
    }

    private void addMeasureProperty(String key, int value, boolean isEnable) {
        PropertyMeasureItem measureItem = propertyViewCache.get(key) instanceof PropertyMeasureItem c ? c : null;
        int isEnabled;
        if (isEnable) {
            isEnabled = 7;
        } else {
            isEnabled = 3;
        }

        if (measureItem == null) {
            measureItem = new PropertyMeasureItem(getContext(), !isEditMode);
            measureItem.setOrientationItem(getOrientation());
            measureItem.setItemEnabled(isEnabled);
            measureItem.setKey(key);
            measureItem.setValue(value);
            measureItem.setTag(key);
            measureItem.setOnPropertyValueChangeListener(this);
            propertyViewCache.put(key, measureItem);
        } else {
            measureItem.setItemEnabled(isEnabled);
            measureItem.setValue(value);
        }

        addView(measureItem);
    }

    private void addClickableSubheader(String header, OnClickListener listener) {
        PropertySubheader propertySubheader = new PropertySubheader(getContext());
        propertySubheader.setHeaderName(header);
        propertySubheader.setOnClickListener(listener);
        addView(propertySubheader);
    }

    public void initializeProperties(String scId, ViewBean bean) {
        setProjectId(scId);
        viewBean = bean;
        RecentHistoryManager.getInstance().loadFromDatabase(viewBean.getClassInfo().getClassName());
        removeAllViews();
        if (bean.id.equals("_fab")) {
            addFabProperties(bean);
        } else {
            if (getOrientation() == LinearLayout.VERTICAL) {
                addSimpleInputProperty("property_id", bean.id);
            }

            addInjectProperties(bean);
            addLayoutProperties(bean);
            addTextProperties(bean);
            addImageAndTransformProperties(bean);
            if (getOrientation() == LinearLayout.HORIZONTAL) {
                addSimpleInputProperty("property_id", bean.id);
            }
        }
    }

    @Override
    public void onPropertyChanged(String key, Object value) {
        RecentHistoryManager.getInstance().addRecentItem(viewBean.getClassInfo().getClassName(), key);
        if (viewBeanCallback != null) {
            ViewBean cloned = viewBean.clone();
            applyPropertyValues(viewBean);
            if (!isEditMode) {
                ViewHistoryManager.getInstance(sc_id).recordUpdate(projectFile.getXmlName(), cloned, viewBean.clone());
                viewBeanCallback.onViewBeanChanged(viewBean);
            }
        }
    }

    private void addCustomViewProperty(String key, String value) {
        PropertyCustomViewItem propertyCustomViewItem = propertyViewCache.get(key) instanceof PropertyCustomViewItem c ? c : null;
        if (propertyCustomViewItem == null) {
            propertyCustomViewItem = new PropertyCustomViewItem(getContext(), !isEditMode);
            propertyCustomViewItem.setOrientationItem(getOrientation());
            propertyCustomViewItem.setKey(key);
            propertyCustomViewItem.setTag(key);
            propertyCustomViewItem.setOnPropertyValueChangeListener(this);
            propertyViewCache.put(key, propertyCustomViewItem);
        }

        propertyCustomViewItem.setCustomView(ProjectDataManager.getFileManager(sc_id).getCustomViews());
        propertyCustomViewItem.setValue(value);
        addView(propertyCustomViewItem);
    }

    private void addInputProperty(String key, String value, boolean isMenuMode, String typeView) {
        PropertyInputItem inputItem = propertyViewCache.get(key) instanceof PropertyInputItem c ? c : null;
        if (inputItem == null) {
            inputItem = new PropertyInputItem(getContext(), !isMenuMode);
            inputItem.setOrientationItem(getOrientation());
            inputItem.setTypeView(typeView);
            inputItem.setProjectData(sc_id, projectFile);
            inputItem.setKey(key);
            inputItem.setValue(value);
            inputItem.setTag(key);
            inputItem.setOnPropertyValueChangeListener(this);
            propertyViewCache.put(key, inputItem);
        } else {
            inputItem.setTypeView(typeView);
            inputItem.setProjectData(sc_id, projectFile);
            inputItem.setValue(value);
        }
        inputItem.setBean(viewBean);

        addView(inputItem);
    }

    public void save() {
        RecentHistoryManager.getInstance().saveToDatabase();
    }

    private void addFabProperties(ViewBean bean) {
        if (getOrientation() == LinearLayout.VERTICAL) {
            addPropertyForBean(bean, "property_id");
        }

        addMarginAndGravityProperties(bean);
        addPropertyForBean(bean, "property_elevation");
        addImageTransformSection(bean);
        if (getOrientation() == LinearLayout.HORIZONTAL) {
            addPropertyForBean(bean, "property_id");
        }
    }

    private void addGravityProperty(String key, int value) {
        PropertyGravityItem gravityItem = (PropertyGravityItem) propertyViewCache.get(key);
        if (gravityItem == null) {
            gravityItem = new PropertyGravityItem(getContext(), !isEditMode);
            gravityItem.setOrientationItem(getOrientation());
            gravityItem.setKey(key);
            gravityItem.setValue(value);
            gravityItem.setTag(key);
            gravityItem.setOnPropertyValueChangeListener(this);
            propertyViewCache.put(key, gravityItem);
        } else {
            gravityItem.setValue(value);
        }

        addView(gravityItem);
    }

    private void addSimpleInputProperty(String key, String value) {
        addInputProperty(key, value, isEditMode, null);
    }

    private void addTypedInputProperty(String key, String value, String viewType) {
        addInputProperty(key, value, isEditMode, viewType);
    }

    private void addResourceProperty(String key, String value, boolean useDefaultImage) {
        PropertyResourceItem drawableItem = (PropertyResourceItem) propertyViewCache.get(key);
        if (drawableItem == null) {
            drawableItem = new PropertyResourceItem(getContext(), !isEditMode, sc_id, useDefaultImage);
            drawableItem.setOrientationItem(getOrientation());
            drawableItem.setKey(key);
            drawableItem.setValue(value);
            drawableItem.setTag(key);
            drawableItem.setOnPropertyValueChangeListener(this);
            propertyViewCache.put(key, drawableItem);
        } else {
            drawableItem.setValue(value);
        }
        addView(drawableItem);
    }

    private void addImageTransformSection(ViewBean bean) {
        if (getOrientation() == LinearLayout.VERTICAL) {
            addClickableSubheader(Helper.getResString(R.string.property_header_image), this);
        }

        addPropertyForBean(bean, "property_image");
        addPropertyForBean(bean, "property_rotate");
        addPropertyForBean(bean, "property_alpha");
        addPropertyForBean(bean, "property_translation_x");
        addPropertyForBean(bean, "property_translation_y");
        addPropertyForBean(bean, "property_scale_x");
        addPropertyForBean(bean, "property_scale_y");
    }

    private void addSelectorProperty(String key, int value) {
        PropertySelectorItem selectorItem = propertyViewCache.get(key) instanceof PropertySelectorItem c ? c : null;
        if (selectorItem == null) {
            selectorItem = new PropertySelectorItem(getContext(), !isEditMode);
            selectorItem.setOrientationItem(getOrientation());
            selectorItem.setKey(key);
            selectorItem.setValue(value);
            selectorItem.setTag(key);
            selectorItem.setOnPropertyValueChangeListener(this);
            propertyViewCache.put(key, selectorItem);
        } else {
            selectorItem.setValue(value);
        }

        addView(selectorItem);
    }

    private void addStringPairSelectorProperty(String key, String value) {
        PropertyStringPairSelectorItem pairSelectorItem = propertyViewCache.get(key) instanceof PropertyStringPairSelectorItem c ? c : null;
        if (pairSelectorItem == null) {
            pairSelectorItem = new PropertyStringPairSelectorItem(getContext(), !isEditMode);
            pairSelectorItem.setOrientationItem(getOrientation());
            pairSelectorItem.setKey(key);
            pairSelectorItem.setValue(value);
            pairSelectorItem.setTag(key);
            pairSelectorItem.setOnPropertyValueChangeListener(this);
            propertyViewCache.put(key, pairSelectorItem);
        } else {
            pairSelectorItem.setValue(value);
        }

        addView(pairSelectorItem);
    }

    public void addLayoutProperties(ViewBean bean) {
        if (getOrientation() == LinearLayout.VERTICAL) {
            addSubheader(Helper.getResString(R.string.property_header_layout));
        }

        ClassInfo classInfo = bean.getClassInfo();
        ClassInfo parentClassInfo = bean.getParentClassInfo();
        addPropertyForBean(bean, "property_layout_width");
        addPropertyForBean(bean, "property_layout_height");
        if (bean.parentType == ViewBean.VIEW_TYPE_LAYOUT_RELATIVE) {
            addPropertyForBean(bean, "property_parent_attr");
        }
        addPropertyForBean(bean, "property_padding");
        addPropertyForBean(bean, "property_margin");
        if (classInfo.matchesType("LinearLayout")) {
            addPropertyForBean(bean, "property_orientation");
            addPropertyForBean(bean, "property_weight_sum");
            addPropertyForBean(bean, "property_gravity");
        }

        if (classInfo.matchesType("TextView")) {
            addPropertyForBean(bean, "property_gravity");
        }

        if (parentClassInfo != null) {
            if (parentClassInfo.matchesType("LinearLayout")) {
                addPropertyForBean(bean, "property_layout_gravity");
                addPropertyForBean(bean, "property_weight");
            }

            if (parentClassInfo.matchesType("ScrollView") || parentClassInfo.matchesType("HorizontalScrollView")) {
                addPropertyForBean(bean, "property_layout_gravity");
            }
        }
    }

    private void addSizeProperty(String key, int value) {
        PropertySizeItem propertySizeItem = propertyViewCache.get(key) instanceof PropertySizeItem c ? c : null;
        if (propertySizeItem == null) {
            propertySizeItem = new PropertySizeItem(getContext(), !isEditMode);
            propertySizeItem.setOrientationItem(getOrientation());
            propertySizeItem.setKey(key);
            propertySizeItem.setValue(value);
            propertySizeItem.setTag(key);
            propertySizeItem.setOnPropertyValueChangeListener(this);
            propertyViewCache.put(key, propertySizeItem);
        } else {
            propertySizeItem.setValue(value);
        }

        addView(propertySizeItem);
    }

    private void addStringSelectorProperty(String key, String value) {
        PropertyStringSelectorItem stringSelectorItem = propertyViewCache.get(key) instanceof PropertyStringSelectorItem c ? c : null;
        if (stringSelectorItem == null) {
            stringSelectorItem = new PropertyStringSelectorItem(getContext(), !isEditMode);
            stringSelectorItem.setOrientationItem(getOrientation());
            stringSelectorItem.setKey(key);
            stringSelectorItem.setValue(value);
            stringSelectorItem.setTag(key);
            stringSelectorItem.setOnPropertyValueChangeListener(this);
            propertyViewCache.put(key, stringSelectorItem);
        } else {
            stringSelectorItem.setValue(value);
        }

        addView(stringSelectorItem);
    }

    public void setupRecentProperties(ViewBean bean) {
        viewBean = bean;
        removeAllViews();
        LayoutParams params = new LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT);
        params.gravity = Gravity.LEFT;
        setLayoutParams(params);
        setGravity(Gravity.LEFT);
        RecentHistoryManager.getInstance().loadFromDatabase(bean.getClassInfo().getClassName());
        ArrayList<String> items = RecentHistoryManager.getInstance().getRecentItems(bean.getClassInfo().getClassName());
        if (items == null) {
            setupViews();
        } else {
            for (String s : items) {
                addPropertyForBean(bean, s);
            }
        }
    }

    private void addSwitchProperty(String key, int value) {
        PropertySwitchSingleLineItem switchSingleLineItem = propertyViewCache.get(key) instanceof PropertySwitchSingleLineItem c ? c : null;
        boolean isEnabled = false;
        if (switchSingleLineItem == null) {
            switchSingleLineItem = new PropertySwitchSingleLineItem(getContext(), !isEditMode);
            switchSingleLineItem.setOrientationItem(getOrientation());
            switchSingleLineItem.setKey(key);
            if (value == 1) {
                isEnabled = true;
            }

            switchSingleLineItem.setValue(isEnabled);
            switchSingleLineItem.setTag(key);
            switchSingleLineItem.setOnPropertyValueChangeListener(this);
            propertyViewCache.put(key, switchSingleLineItem);
        } else {
            if (value == 1) {
                isEnabled = true;
            }

            switchSingleLineItem.setValue(isEnabled);
        }

        addView(switchSingleLineItem);
    }

    private void setupAttributes(String key, HashMap<String, String> value) {
        ArrayList<ViewBean> viewBeans = ProjectDataManager.getProjectDataManager(sc_id).getViews(projectFile.getXmlName());
        List<String> ids = new ArrayList<>();
        for (ViewBean bean : viewBeans) {
            if (!bean.id.equals(viewBean.id) && bean.parent.equals(viewBean.parent)) {
                ids.add(bean.id);
            }
        }
        PropertyAttributesItem item = (PropertyAttributesItem) propertyViewCache.get(key);
        if (item == null) {
            item = new PropertyAttributesItem(getContext(), !isEditMode);
            item.setOrientationItem(getOrientation());
            item.setKey(key);
            item.setValue(value);
            item.setTag(key);
            item.setOnPropertyValueChangeListener(this);
            propertyViewCache.put(key, item);
        } else {
            item.setValue(value);
        }
        item.setBean(viewBean);
        item.setBeans(viewBeans);
        item.setAvailableIds(ids);

        addView(item);
    }

    public void addInjectProperties(ViewBean bean) {
        if (!bean.id.equals("_fab")) {
            ClassInfo classInfo = bean.getClassInfo();
            addPropertyForBean(bean, "property_inject");
            addPropertyForBean(bean, "property_convert");
            if (classInfo.isExactType("Spinner")) {
                addPropertyForBean(bean, "property_spinner_mode");
            }

            if (classInfo.isExactType("ListView")) {
                addPropertyForBean(bean, "property_divider_height");
                addPropertyForBean(bean, "property_custom_view_listview");
            }

            if (classInfo.isExactType("GridView")) {
                addPropertyForBean(bean, "property_custom_view_listview");
            }

            if (classInfo.isExactType("RecyclerView")) {
                addPropertyForBean(bean, "property_custom_view_listview");
            }

            if (classInfo.isExactType("ViewPager")) {
                addPropertyForBean(bean, "property_custom_view_listview");
            }

            if (classInfo.isExactType("Spinner")) {
                addPropertyForBean(bean, "property_custom_view_listview");
            }

            if (classInfo.isExactType("AutoCompleteTextView")) {
                addPropertyForBean(bean, "property_hint");
                addPropertyForBean(bean, "property_hint_color");
            }

            if (classInfo.isExactType("MultiAutoCompleteTextView")) {
                addPropertyForBean(bean, "property_hint");
                addPropertyForBean(bean, "property_hint_color");
            }

            if (classInfo.isExactType("WaveSideBar")) {
                addSimpleInputProperty("property_text_size", String.valueOf(bean.text.textSize));
                addPropertyForBean(bean, "property_text_color");
            }

            if (classInfo.matchesType("CompoundButton") && getOrientation() == LinearLayout.VERTICAL) {
                addPropertyForBean(bean, "property_checked");
            }

            if (classInfo.isExactType("SeekBar")) {
                addPropertyForBean(bean, "property_max");
                addPropertyForBean(bean, "property_progress");
            }

            if (classInfo.isExactType("CalendarView")) {
                addPropertyForBean(bean, "property_first_day_of_week");
            }

            if (classInfo.isExactType("AdView")) {
                addPropertyForBean(bean, "property_ad_size");
            }

            if (classInfo.isExactType("ProgressBar")) {
                addPropertyForBean(bean, "property_max");
                addPropertyForBean(bean, "property_progress");
                addPropertyForBean(bean, "property_progressbar_style");
                addPropertyForBean(bean, "property_indeterminate");
            }
        }
    }

    public void addTextProperties(ViewBean bean) {
        ClassInfo classInfo = bean.getClassInfo();
        if (classInfo.matchesType("TextView")) {
            if (getOrientation() == LinearLayout.VERTICAL) {
                addSubheader(Helper.getResString(R.string.property_header_text));
            }

            addPropertyForBean(bean, "property_text");
            addSimpleInputProperty("property_text_size", String.valueOf(bean.text.textSize));
            addPropertyForBean(bean, "property_text_style");
            addPropertyForBean(bean, "property_text_color");
            if (classInfo.isExactType("EditText")) {
                addPropertyForBean(bean, "property_hint");
                addPropertyForBean(bean, "property_hint_color");
                if (getOrientation() == LinearLayout.VERTICAL) {
                    addPropertyForBean(bean, "property_single_line");
                }

                addPropertyForBean(bean, "property_lines");
                addPropertyForBean(bean, "property_input_type");
                addPropertyForBean(bean, "property_ime_option");
            }

            if (classInfo.isExactType("TextView")) {
                if (getOrientation() == LinearLayout.VERTICAL) {
                    addPropertyForBean(bean, "property_single_line");
                }

                addPropertyForBean(bean, "property_lines");
            }
        }
    }

    public void addImageAndTransformProperties(ViewBean bean) {
        ClassInfo classInfo = bean.getClassInfo();
        if (getOrientation() == LinearLayout.VERTICAL) {
            if (classInfo.matchesType("ImageView")) {
                addClickableSubheader(Helper.getResString(R.string.property_header_image), this);
                addPropertyForBean(bean, "property_image");
                addPropertyForBean(bean, "property_scale_type");
            } else {
                addSubheader(Helper.getResString(R.string.property_header_image));
            }
        } else if (classInfo.matchesType("ImageView")) {
            addPropertyForBean(bean, "property_image");
            addPropertyForBean(bean, "property_scale_type");
        }

        if (bean.type != ViewBean.VIEW_TYPE_WIDGET_MAPVIEW) {
            addPropertyForBean(bean, "property_background_resource");
            addPropertyForBean(bean, "property_background_color");
        }

        if (getOrientation() == LinearLayout.VERTICAL
                && !classInfo.isExactType("LinearLayout")
                && !classInfo.isExactType("ScrollView")
                && !classInfo.isExactType("HorizontalScrollView")
                && !classInfo.isExactType("ListView")
                && !classInfo.isExactType("FloatingActionButton")) {
            addPropertyForBean(bean, "property_enabled");
        }

        addPropertyForBean(bean, "property_elevation");
        addPropertyForBean(bean, "property_visibility");
        addPropertyForBean(bean, "property_rotate");
        addPropertyForBean(bean, "property_alpha");
        addPropertyForBean(bean, "property_translation_x");
        addPropertyForBean(bean, "property_translation_y");
        addPropertyForBean(bean, "property_scale_x");
        addPropertyForBean(bean, "property_scale_y");
    }

    public void applyPropertyValues(ViewBean bean) {
        int childCount = getChildCount();

        for (int i = 0; i < childCount; ++i) {
            View view = getChildAt(i);
            if (view instanceof PropertyInputItem inputItem) {
                switch (inputItem.getKey()) {
                    case "property_id" -> {
                        String currentId = bean.id;
                        bean.preId = currentId;
                        if (currentId != null && !currentId.isEmpty() && currentId.charAt(0) != '_') {
                            bean.id = inputItem.getValue();
                        }
                    }
                    case "property_convert" -> bean.convert = inputItem.getValue();
                    case "property_inject" -> bean.inject = inputItem.getValue();
                    case "property_text" -> bean.text.text = inputItem.getValue();
                    case "property_hint" -> bean.text.hint = inputItem.getValue();
                    case "property_text_size" -> bean.text.textSize = FormatUtil.safeParseInt(inputItem.getValue(), bean.text.textSize);
                    case "property_weight" ->
                            bean.layout.weight = FormatUtil.safeParseInt(inputItem.getValue(), bean.layout.weight);
                    case "property_weight_sum" ->
                            bean.layout.weightSum = FormatUtil.safeParseInt(inputItem.getValue(), bean.layout.weightSum);
                    case "property_elevation" ->
                            bean.layout.elevation = FormatUtil.safeParseInt(inputItem.getValue(), bean.layout.elevation);
                    case "property_visibility" ->
                            bean.inject = setInjectedAttr(bean, "android:visibility", inputItem.getValue());
                    case "property_rotate" ->
                            bean.image.rotate = FormatUtil.safeParseInt(inputItem.getValue(), bean.image.rotate);
                    case "property_alpha" -> bean.alpha = FormatUtil.safeParseFloat(inputItem.getValue(), bean.alpha);
                    case "property_translation_x" ->
                            bean.translationX = FormatUtil.safeParseFloat(inputItem.getValue(), bean.translationX);
                    case "property_translation_y" ->
                            bean.translationY = FormatUtil.safeParseFloat(inputItem.getValue(), bean.translationY);
                    case "property_scale_x" -> bean.scaleX = FormatUtil.safeParseFloat(inputItem.getValue(), bean.scaleX);
                    case "property_scale_y" -> bean.scaleY = FormatUtil.safeParseFloat(inputItem.getValue(), bean.scaleY);
                    case "property_lines" ->
                            bean.text.line = FormatUtil.safeParseInt(inputItem.getValue(), bean.text.line);
                    case "property_max" -> bean.max = FormatUtil.safeParseInt(inputItem.getValue(), bean.max);
                    case "property_progress" ->
                            bean.progress = FormatUtil.safeParseInt(inputItem.getValue(), bean.progress);
                }
            } else if (view instanceof PropertyMeasureItem measureItem) {
                if (measureItem.getKey().equals("property_layout_width")) {
                    bean.layout.width = measureItem.getValue();
                } else if (measureItem.getKey().equals("property_layout_height")) {
                    bean.layout.height = measureItem.getValue();
                }
            } else if (view instanceof PropertySelectorItem selectorItem) {
                switch (selectorItem.getKey()) {
                    case "property_orientation" ->
                            bean.layout.orientation = selectorItem.getValue();
                    case "property_text_style" -> bean.text.textType = selectorItem.getValue();
                    case "property_input_type" -> bean.text.inputType = selectorItem.getValue();
                    case "property_ime_option" -> bean.text.imeOption = selectorItem.getValue();
                    case "property_spinner_mode" -> bean.spinnerMode = selectorItem.getValue();
                    case "property_first_day_of_week" ->
                            bean.firstDayOfWeek = selectorItem.getValue();
                }
            } else if (view instanceof PropertyStringSelectorItem stringSelectorItem) {
                switch (stringSelectorItem.getKey()) {
                    case "property_scale_type" ->
                            bean.image.scaleType = stringSelectorItem.getValue();
                    case "property_ad_size" -> bean.adSize = stringSelectorItem.getValue();
                    case "property_indeterminate" ->
                            bean.indeterminate = stringSelectorItem.getValue();
                }
            } else if (view instanceof PropertyStringPairSelectorItem stringPairSelectorItem) {
                if (stringPairSelectorItem.getKey().equals("property_progressbar_style")) {
                    bean.progressStyle = stringPairSelectorItem.getValue();
                }
            } else if (view instanceof PropertyCustomViewItem listview_item) {
                if (listview_item.getKey().equals("property_custom_view_listview")) {
                    bean.customView = listview_item.getValue();
                }
            } else if (view instanceof PropertySwitchSingleLineItem switchSingleLineItem) {
                switch (switchSingleLineItem.getKey()) {
                    case "property_single_line" ->
                            bean.text.singleLine = switchSingleLineItem.getValue() ? 1 : 0;
                    case "property_enabled" ->
                            bean.enabled = switchSingleLineItem.getValue() ? 1 : 0;
                    case "property_clickable" ->
                            bean.clickable = switchSingleLineItem.getValue() ? 1 : 0;
                    case "property_checked" ->
                            bean.checked = switchSingleLineItem.getValue() ? 1 : 0;
                }
            } else if (view instanceof PropertyColorItem colorItem) {
                switch (colorItem.getKey()) {
                    case "property_text_color" -> {
                        bean.text.textColor = colorItem.getValue();
                        bean.text.resTextColor = colorItem.getResValue();
                    }
                    case "property_hint_color" -> {
                        bean.text.hintColor = colorItem.getValue();
                        bean.text.resHintColor = colorItem.getResValue();
                    }
                    case "property_background_color" -> {
                        bean.layout.backgroundResColor = colorItem.getResValue();
                        bean.layout.backgroundColor = colorItem.getValue();
                    }
                }
            } else if (view instanceof PropertyIndentItem indentItem) {
                if (indentItem.getKey().equals("property_margin")) {
                    LayoutBean layout = bean.layout;
                    layout.marginLeft = indentItem.left;
                    layout.marginTop = indentItem.top;
                    layout.marginRight = indentItem.right;
                    layout.marginBottom = indentItem.bottom;
                } else if (indentItem.getKey().equals("property_padding")) {
                    LayoutBean layout = bean.layout;
                    layout.paddingLeft = indentItem.left;
                    layout.paddingTop = indentItem.top;
                    layout.paddingRight = indentItem.right;
                    layout.paddingBottom = indentItem.bottom;
                }
            } else if (view instanceof PropertyGravityItem gravityItem) {
                if (gravityItem.getKey().equals("property_gravity")) {
                    bean.layout.gravity = gravityItem.getValue();
                } else if (gravityItem.getKey().equals("property_layout_gravity")) {
                    bean.layout.layoutGravity = gravityItem.getValue();
                }
            } else if (view instanceof PropertyResourceItem image_item) {
                if (image_item.getKey().equals("property_image")) {
                    bean.image.resName = image_item.getValue();
                } else if (image_item.getKey().equals("property_background_resource")) {
                    bean.layout.backgroundResource = image_item.getValue();
                }
            } else if (view instanceof PropertySizeItem sizeItem) {
                if (sizeItem.getKey().equals("property_divider_height")) {
                    bean.dividerHeight = sizeItem.getValue();
                }
            } else if (view instanceof PropertyAttributesItem item) {
                if (item.getKey().equals("property_parent_attr")) {
                    bean.parentAttributes = item.getValue();
                }
            }
        }

        if (!bean.id.equals(bean.preId)) {
            boolean viewBinding = settings != null && settings.getValue(ProjectSettings.SETTING_ENABLE_VIEWBINDING, "false").equals("true");
            for (ViewBean viewBean : ProjectDataManager.getProjectDataManager(sc_id).getViews(projectFile.getXmlName())) {
                if (viewBean.parent.equals(bean.preId)) {
                    viewBean.parent = bean.id;
                }
            }

            if (projectFile.fileType == ProjectFileBean.PROJECT_FILE_TYPE_ACTIVITY) {
                for (EventBean eventBean : ProjectDataManager.getProjectDataManager(sc_id).getEvents(projectFile.getJavaName())) {
                    if (eventBean.targetId.equals(bean.preId)) {
                        eventBean.targetId = bean.id;
                    }
                }

                HashMap<String, ArrayList<BlockBean>> beanMap = ProjectDataManager.getProjectDataManager(sc_id).getBlockMap(projectFile.getJavaName());

                for (String events : EventRegistry.getEventsForClass(bean.getClassInfo())) {
                    StringBuilder eventBodyBuilder = new StringBuilder();
                    eventBodyBuilder.append(bean.preId);
                    eventBodyBuilder.append("_");
                    eventBodyBuilder.append(events);
                    String body = eventBodyBuilder.toString();
                    if (beanMap.containsKey(body)) {
                        eventBodyBuilder = new StringBuilder();
                        eventBodyBuilder.append(bean.id);
                        eventBodyBuilder.append("_");
                        eventBodyBuilder.append(events);
                        beanMap.put(eventBodyBuilder.toString(), beanMap.get(body));
                        beanMap.remove(body);
                    }
                }

                ArrayList<String> events = new ArrayList<>();
                if (beanMap.containsKey("onCreate_initializeLogic")) {
                    events.add("onCreate_initializeLogic");
                }

                for (Pair<String, String> moreblocks : ProjectDataManager.getProjectDataManager(sc_id).getMoreBlocks(projectFile.getJavaName())) {
                    String key = moreblocks.first +
                            "_" +
                            "moreBlock";
                    if (beanMap.containsKey(key)) {
                        events.add(key);
                    }
                }

                for (EventBean eventBean : ProjectDataManager.getProjectDataManager(sc_id).getEvents(projectFile.getJavaName())) {
                    if (!eventBean.eventName.equals("onBindCustomView")) {
                        String eventKey = eventBean.getEventKey();
                        if (beanMap.containsKey(eventKey)) {
                            events.add(eventKey);
                        }
                    }
                }

                for (String event : events) {
                    ArrayList<BlockBean> blockBeans = beanMap.get(event);
                    if (blockBeans != null) {
                        for (BlockBean blockBean : blockBeans) {
                            ClassInfo classInfo = blockBean.getClassInfo();

                            if (classInfo != null && classInfo.isView() && blockBean.spec.equals(viewBinding ? "binding." + ViewBindingBuilder.generateParameterFromId(bean.preId) : bean.preId)) {
                                blockBean.spec = viewBinding ? "binding." + ViewBindingBuilder.generateParameterFromId(bean.id) : bean.id;
                            } else {
                                ArrayList<ClassInfo> classInfoList = blockBean.getParamClassInfo();
                                if (classInfoList != null && !classInfoList.isEmpty()) {
                                    for (int i = 0; i < classInfoList.size(); ++i) {
                                        if (classInfoList.get(i).isView() && blockBean.parameters.get(i).equals(viewBinding ? "binding." + ViewBindingBuilder.generateParameterFromId(bean.preId) : bean.preId)) {
                                            blockBean.parameters.set(i, viewBinding ? "binding." + ViewBindingBuilder.generateParameterFromId(bean.id) : bean.id);
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                ArrayList<Pair<String, String>> viewBeanItems = new ArrayList<>();

                for (ProjectFileBean projectFileBean : ProjectDataManager.getFileManager(sc_id).getActivities()) {
                    for (ViewBean viewBean : ProjectDataManager.getProjectDataManager(sc_id).getCustomViewBeans(projectFileBean.getXmlName())) {
                        if (viewBean.customView.equals(projectFile.fileName)) {
                            String javaName = projectFileBean.getJavaName();
                            String key = viewBean.id +
                                    "_" +
                                    "onBindCustomView";
                            viewBeanItems.add(new Pair<>(javaName, key));
                        }
                    }
                }

                for (Pair<String, String> viewBean : viewBeanItems) {
                    ArrayList<BlockBean> blockBeans = ProjectDataManager.getProjectDataManager(sc_id).getBlockMap(viewBean.first).get(viewBean.second);
                    if (blockBeans != null) {
                        for (BlockBean blockBean : blockBeans) {
                            ClassInfo classInfo = blockBean.getClassInfo();

                            if (classInfo != null && classInfo.isView() && blockBean.spec.equals(viewBinding ? "binding." + ViewBindingBuilder.generateParameterFromId(bean.preId) : bean.preId)) {
                                blockBean.spec = viewBinding ? "binding." + ViewBindingBuilder.generateParameterFromId(bean.id) : bean.id;
                            } else {
                                ArrayList<ClassInfo> classInfoList = blockBean.getParamClassInfo();
                                if (classInfoList != null && !classInfoList.isEmpty()) {
                                    for (int i = 0; i < classInfoList.size(); ++i) {
                                        if (classInfoList.get(i).isView() && blockBean.parameters.get(i).equals(viewBinding ? "binding." + ViewBindingBuilder.generateParameterFromId(bean.preId) : bean.preId)) {
                                            blockBean.parameters.set(i, viewBinding ? "binding." + ViewBindingBuilder.generateParameterFromId(bean.id) : bean.id);
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        if (projectFile.fileType == ProjectFileBean.PROJECT_FILE_TYPE_ACTIVITY && supportsCustomViewAdapter(bean.type)) {
            ViewBean viewBean = ProjectDataManager.getProjectDataManager(sc_id).getViewBean(projectFile.getXmlName(), bean.preId);
            String custom = bean.customView;
            if (custom != null && viewBean != null) {
                String customView = viewBean.customView;
                if (customView != null && !customView.equals(custom)) {
                    clearOnBindCustomViewEvent(bean.id);
                    if (bean.customView.isEmpty() || bean.customView.equals("none")) {
                        clearCustomViewDataBlocks(bean.id, getCustomViewDataOpcode(bean.type));
                    }
                }
            }
        }
    }

    private void clearCustomViewDataBlocks(String viewId, String opcode) {
        if (opcode.isEmpty()) {
            return;
        }
        Iterator<Entry<String, ArrayList<BlockBean>>> blocks = ProjectDataManager.getProjectDataManager(sc_id).getBlockMap(projectFile.getJavaName()).entrySet().iterator();

        while (blocks.hasNext()) {
            for (BlockBean blockBean : blocks.next().getValue()) {
                if (opcode.equals(blockBean.opCode) && !blockBean.parameters.isEmpty() && viewId.equals(blockBean.parameters.get(0))) {
                    blockBean.parameters.set(0, "");
                }
            }
        }
    }

    private void clearOnBindCustomViewEvent(String viewId) {
        ArrayList<EventBean> eventBeans = ProjectDataManager.getProjectDataManager(sc_id).getEvents(projectFile.getJavaName());
        for (int i = eventBeans.size() - 1; i >= 0; i--) {
            EventBean eventBean = eventBeans.get(i);
            if (eventBean.targetId.equals(viewId) && eventBean.eventName.equals("onBindCustomView")) {
                eventBeans.remove(i);
                HashMap<String, ArrayList<BlockBean>> blocks = ProjectDataManager.getProjectDataManager(sc_id).getBlockMap(projectFile.getJavaName());
                blocks.remove(eventBean.getEventKey());
            }
        }
    }

    private String getCustomViewDataOpcode(int viewType) {
        return switch (viewType) {
            case ViewBean.VIEW_TYPE_WIDGET_LISTVIEW -> "listSetCustomViewData";
            case ViewBean.VIEW_TYPE_WIDGET_SPINNER -> "spnSetCustomViewData";
            case ViewBeans.VIEW_TYPE_WIDGET_GRIDVIEW -> "gridSetCustomViewData";
            case ViewBeans.VIEW_TYPE_LAYOUT_VIEWPAGER -> "pagerSetCustomViewData";
            case ViewBeans.VIEW_TYPE_WIDGET_RECYCLERVIEW -> "recyclerSetCustomViewData";
            default -> "";
        };
    }

    private boolean supportsCustomViewAdapter(int viewType) {
        return switch (viewType) {
            case ViewBean.VIEW_TYPE_WIDGET_LISTVIEW,
                 ViewBean.VIEW_TYPE_WIDGET_SPINNER,
                 ViewBeans.VIEW_TYPE_WIDGET_GRIDVIEW,
                 ViewBeans.VIEW_TYPE_LAYOUT_VIEWPAGER,
                 ViewBeans.VIEW_TYPE_WIDGET_RECYCLERVIEW -> true;
            default -> false;
        };
    }

    public void setProjectSettings(ProjectSettings settings) {
        this.settings = settings;
    }

    public void setOnPropertyValueChangedListener(ViewBeanCallback listener) {
        viewBeanCallback = listener;
    }

    public void setProjectFileBean(ProjectFileBean fileBean) {
        projectFile = fileBean;
    }

    @Override
    public void onClick(View v) {
        if (!UIHelper.isClickThrottled() && !isEditMode) {
            if (getContext() instanceof PropertyActivity activity) {
                activity.openImageManager();
            }
        }
    }
}

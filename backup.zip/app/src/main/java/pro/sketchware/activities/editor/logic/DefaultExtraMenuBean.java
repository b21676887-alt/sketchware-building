package pro.sketchware.activities.editor.logic;

import android.net.Uri;
import android.util.Pair;

import pro.sketchware.beans.ComponentBean;
import pro.sketchware.activities.editor.LogicEditorActivity;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import pro.sketchware.core.block.view.FieldBlockView;
import pro.sketchware.core.project.ProjectDataStore;
import pro.sketchware.core.project.ProjectDataManager;
import pro.sketchware.core.project.BlockConstants;
import pro.sketchware.core.project.SketchwarePaths;
import pro.sketchware.activities.editor.makeblock.BlockMenu;
import pro.sketchware.util.Helper;
import pro.sketchware.R;
import pro.sketchware.util.MenuNameMapper;
import pro.sketchware.util.CustomVariableUtil;
import pro.sketchware.util.FileUtil;

public class DefaultExtraMenuBean {

    private final LogicEditorActivity logicEditor;
    private final ProjectDataStore projectDataManager;
    private final String sc_id;

    public DefaultExtraMenuBean(LogicEditorActivity logicEditor) {
        this.logicEditor = logicEditor;
        sc_id = logicEditor.scId;
        projectDataManager = ProjectDataManager.getProjectDataManager(sc_id);
    }

    public static String getName(String menuName) {
        return MenuNameMapper.getName(menuName);
    }

    public Pair<String, ArrayList<String>> getMenu(FieldBlockView menu) {
        var javaName = logicEditor.projectFile.getJavaName();
        var menuName = menu.getMenuName();
        ArrayList<String> menus = new ArrayList<>();
        String title;
        Pair<String, String[]> menuPair = BlockMenu.getMenu(menuName);
        title = menuPair.first;
        menus = new ArrayList<>(Arrays.asList(menuPair.second));
        for (String s : projectDataManager.getVariableNamesByType(javaName, ExtraMenuBean.VARIABLE_TYPE_CUSTOM_LEGACY)) {
            Matcher matcher2 = Pattern.compile("^(\\w+)[\\s]+(\\w+)").matcher(s);
            while (matcher2.find()) {
                if (menuName.equals(matcher2.group(1))) {
                    title = String.format(Helper.getResString(R.string.menu_select_variable_format), matcher2.group(1));
                    menus.add(matcher2.group(2));
                }
            }
        }
        for (String variable : projectDataManager.getVariableNamesByType(javaName, ExtraMenuBean.VARIABLE_TYPE_CUSTOM_DECLARATION)) {
            String variableType = CustomVariableUtil.getVariableType(variable);
            String variableName = CustomVariableUtil.getVariableName(variable);
            if (menuName.equals(variableType)) {
                title = String.format(Helper.getResString(R.string.menu_select_variable_format), variableType);
                menus.add(variableName);
            }
        }
        for (ComponentBean componentBean : projectDataManager.getComponents(javaName)) {
            if (componentBean.type > 36
                    && menuName.equals(ComponentBean.getComponentTypeName(componentBean.type))) {
                title = String.format(Helper.getResString(R.string.menu_select_component_format), ComponentBean.getComponentTypeName(componentBean.type));
                menus.add(componentBean.componentId);
            }
        }
        switch (menuName) {
            case "LayoutParam" -> {
                title = Helper.getResString(R.string.menu_select_layout_params);
                menus.addAll(Helper.createStringList("MATCH_PARENT", "WRAP_CONTENT"));
            }
            case "Command" -> {
                title = Helper.getResString(R.string.menu_select_command);
                menus.addAll(
                        Helper.createStringList(
                                "insert",
                                "add",
                                "replace",
                                "find-replace",
                                "find-replace-first",
                                "find-replace-all"));
            }
            // This is meant to be a built-in menu including the cases below, but Aldi implemented it as a file, which is why, in some cases, certain menus appear empty.
            //start
            case "menu", "layout", "anim", "drawable" -> {
                String path = getPath(sc_id, menuName);
                title = String.format(Helper.getResString(R.string.menu_select_format), menuName);
                if (menuName.equals("layout")) {
                    for (String name : ProjectDataManager.getFileManager(sc_id).getXmlNames()) {
                        menus.add(name.substring(0, name.indexOf(".xml")));
                    }
                }
                for (String file : FileUtil.listFiles(path, ".xml")) {
                    menus.add(getFilename(file, ".xml"));
                }
            }
            case "image" -> {
                String path = getPath(sc_id, "drawable-xhdpi");
                title = Helper.getResString(R.string.menu_select_image);
                for (String drawable_xhdpi : FileUtil.listFiles(path, "")) {
                    if (drawable_xhdpi.contains(".png") || drawable_xhdpi.contains(".jpg")) {
                        menus.add(
                                getFilename(
                                        drawable_xhdpi,
                                        drawable_xhdpi.contains(".png") ? ".png" : ".jpg"));
                    }
                }
            }
            case "til_box_mode" -> {
                title = Helper.getResString(R.string.menu_select_box_mode);
                menus.addAll(Arrays.asList(BlockConstants.TIL_BOX_MODE));
            }
            case "fabsize" -> {
                title = Helper.getResString(R.string.menu_select_fab_size);
                menus.addAll(Arrays.asList(BlockConstants.FAB_SIZE));
            }
            case "fabvisible" -> {
                title = Helper.getResString(R.string.menu_select_fab_visibility);
                menus.addAll(Arrays.asList(BlockConstants.FAB_VISIBLE));
            }
            case "menuaction" -> {
                title = Helper.getResString(R.string.menu_select_menu_action);
                menus.addAll(Arrays.asList(BlockConstants.MENU_ACTION));
            }
            case "porterduff" -> {
                title = Helper.getResString(R.string.menu_select_porterduff_mode);
                menus.addAll(Arrays.asList(BlockConstants.PORTER_DUFF));
            }
            case "transcriptmode" -> {
                title = Helper.getResString(R.string.menu_select_transcript_mode);
                menus.addAll(Arrays.asList(BlockConstants.TRANSCRIPT_MODE));
            }
            // Used by the legacy ListView scroll-state blocks.
            case "listscrollparam" -> {
                title = Helper.getResString(R.string.menu_select_scroll_param);
                menus.addAll(Arrays.asList(BlockConstants.LIST_SCROLL_STATES));
            }
            // Used by RecyclerView and ViewPager scroll-state blocks.
            case "recyclerscrollparam", "pagerscrollparam" -> {
                title = Helper.getResString(R.string.menu_select_scroll_param);
                menus.addAll(Arrays.asList(BlockConstants.RECYCLER_SCROLL_STATES));
            }
            case "gridstretchmode" -> {
                title = Helper.getResString(R.string.menu_select_stretch_mode);
                menus.addAll(Arrays.asList(BlockConstants.GRID_STRETCH_MODE));
            }
            case "gravity_v" -> {
                title = Helper.getResString(R.string.menu_select_gravity_vertical);
                menus.addAll(Arrays.asList(BlockConstants.GRAVITY_VERTICAL));
            }
            case "gravity_h" -> {
                title = Helper.getResString(R.string.menu_select_gravity_horizontal);
                menus.addAll(Arrays.asList(BlockConstants.GRAVITY_HORIZONTAL));
            }
            case "gravity_t" -> {
                title = Helper.getResString(R.string.menu_select_gravity_toast);
                menus.addAll(Arrays.asList(BlockConstants.GRAVITY_TOAST));
            }
            case "patternviewmode" -> {
                title = Helper.getResString(R.string.menu_select_patternview_mode);
                menus.addAll(Arrays.asList(BlockConstants.PATTERNVIEW_MODE));
            }
            case "styleprogress" -> {
                title = Helper.getResString(R.string.menu_select_progress_style);
                menus.addAll(Arrays.asList(BlockConstants.PROGRESS_STYLE));
            }
            case "cv_theme" -> {
                title = Helper.getResString(R.string.menu_select_theme);
                menus.addAll(Arrays.asList(BlockConstants.CODEVIEW_THEME));
            }
            case "cv_language" -> {
                title = Helper.getResString(R.string.menu_select_language);
                menus.addAll(Arrays.asList(BlockConstants.CODEVIEW_LANGUAGE));
            }
            case "import" -> {
                title = Helper.getResString(R.string.menu_select_language);
                menus.addAll(Arrays.asList(BlockConstants.IMPORT_CLASS_PATH));
            }
            //end
        }
        return new Pair<>(title, menus);
    }

    private String getPath(String sc_id, String name) {
        return SketchwarePaths.getProjectResourceDirectoryPath(sc_id, name);
    }

    private String getFilename(String filePath, String filenameExtensionToCutOff) {
        String lastPathSegment = Uri.parse(filePath).getLastPathSegment();
        if (lastPathSegment == null) return "";
        int extIndex = lastPathSegment.indexOf(filenameExtensionToCutOff);
        if (extIndex < 0) return lastPathSegment;
        return lastPathSegment.substring(0, extIndex);
    }
}

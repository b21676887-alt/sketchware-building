package pro.sketchware.activities.editor;

import androidx.activity.OnBackPressedCallback;
import android.annotation.SuppressLint;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;

import androidx.core.content.FileProvider;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.animation.OvershootInterpolator;
import android.widget.Button;
import android.widget.PopupMenu;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import pro.sketchware.activities.base.BaseAppCompatActivity;
import com.bumptech.glide.Glide;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;

import org.jetbrains.annotations.NotNull;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import dev.pranav.filepicker.FilePickerCallback;
import dev.pranav.filepicker.FilePickerDialogFragment;
import dev.pranav.filepicker.FilePickerOptions;
import dev.pranav.filepicker.SelectionMode;
import pro.sketchware.graphics.VectorDrawableLoader;
import pro.sketchware.activities.editor.code.SrcCodeEditor;
import pro.sketchware.util.Helper;
import pro.sketchware.util.LogUtil;
import pro.sketchware.R;
import pro.sketchware.databinding.DialogCreateNewFileLayoutBinding;
import pro.sketchware.databinding.DialogInputLayoutBinding;
import pro.sketchware.databinding.ManageFileBinding;
import pro.sketchware.databinding.ManageJavaItemHsBinding;
import pro.sketchware.util.FilePathUtil;
import pro.sketchware.core.project.FileResConfig;
import pro.sketchware.util.FileUtil;
import pro.sketchware.util.SketchwareUtil;

@SuppressLint("SetTextI18n")
public class ManageResourceActivity extends BaseAppCompatActivity {

    private CustomAdapter adapter;
    private FilePickerDialogFragment dialog;
    private FilePathUtil fpu;
    private FileResConfig frc;
    private String numProj;
    private String temp;

    private ManageFileBinding binding;

    public static String getLastDirectory(String path) {
        // Get the index of the last occurrence of '/' character
        int lastSlashIndex = path.lastIndexOf('/');

        // Get the substring from the start to the lastSlashIndex
        String parentPath = path.substring(0, lastSlashIndex);

        // Get the index of the last occurrence of '/' in the parentPath
        lastSlashIndex = parentPath.lastIndexOf('/');

        // Extract the last directory name
        return parentPath.substring(lastSlashIndex + 1);
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        enableEdgeToEdgeNoContrast();
        super.onCreate(savedInstanceState);
        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                try {
                    temp = temp.substring(0, temp.lastIndexOf("/"));
                    if (temp.contains("resource")) {
                        handleAdapter(temp);
                        handleFab();
                        return;
                    }
                } catch (IndexOutOfBoundsException e) {
                    LogUtil.w("ManageResourceActivity", "Resource index out of bounds", e);
                }
                setResult(RESULT_OK);
                finish();
            }
        });
        binding = ManageFileBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        numProj = getIntent().getStringExtra("sc_id");
        if (numProj == null) {
            finish();
            return;
        }
        frc = new FileResConfig(numProj);
        fpu = new FilePathUtil();
        setupDialog();
        checkDir();
        initToolbar();
    }

    private void checkDir() {
        if (!FileUtil.isExistFile(fpu.getPathResource(numProj))) {
            FileUtil.makeDir(fpu.getPathResource(numProj));
            FileUtil.makeDir(fpu.getPathResource(numProj) + "/anim");
            FileUtil.makeDir(fpu.getPathResource(numProj) + "/drawable");
            FileUtil.makeDir(fpu.getPathResource(numProj) + "/drawable-xhdpi");
            FileUtil.makeDir(fpu.getPathResource(numProj) + "/layout");
            FileUtil.makeDir(fpu.getPathResource(numProj) + "/menu");
            FileUtil.makeDir(fpu.getPathResource(numProj) + "/values");
        }
        temp = fpu.getPathResource(numProj);
        handleAdapter(temp);
        handleFab();
    }

    private void handleAdapter(String resourceType) {
        ArrayList<String> resourceFile = frc.getResourceFile(resourceType);
        //noinspection Java8ListSort
        Collections.sort(resourceFile, String.CASE_INSENSITIVE_ORDER);
        adapter = new CustomAdapter(resourceFile);
        binding.filesListRecyclerView.setAdapter(adapter);

        binding.noContentLayout.setVisibility(resourceFile.isEmpty() ? View.VISIBLE : View.GONE);
    }

    private boolean isInMainDirectory() {
        return temp.equals(fpu.getPathResource(numProj));
    }

    private void handleFab() {
        var optionsButton = binding.showOptionsButton;
        if (isInMainDirectory()) {
            optionsButton.setText(Helper.getResString(R.string.resource_create_new));
            hideShowOptionsButton(true);
        } else {
            optionsButton.setText(Helper.getResString(R.string.resource_create_or_import));
        }
    }

    private void initToolbar() {
        binding.topAppBar.setTitle(R.string.manager_resource_title);
        binding.topAppBar.setNavigationOnClickListener(v -> getOnBackPressedDispatcher().onBackPressed());
        binding.showOptionsButton.setOnClickListener(view -> {
            if (isInMainDirectory()) {
                createNewDialog(true);
                return;
            }
            hideShowOptionsButton(false);
        });
        binding.closeButton.setOnClickListener(view -> hideShowOptionsButton(true));
        binding.createNewButton.setOnClickListener(v -> {
            createNewDialog(isInMainDirectory());
            hideShowOptionsButton(true);
        });
        binding.importNewButton.setOnClickListener(v -> {
            dialog.show(getSupportFragmentManager(), "filePicker");
            hideShowOptionsButton(true);
        });

    }

    private void hideShowOptionsButton(boolean isHide) {
        binding.optionsLayout.animate()
                .translationY(isHide ? 300 : 0)
                .alpha(isHide ? 0 : 1)
                .setInterpolator(new OvershootInterpolator());

        binding.showOptionsButton.animate()
                .translationY(isHide ? 0 : 300)
                .alpha(isHide ? 1 : 0)
                .setInterpolator(new OvershootInterpolator());
    }

    @Override
    public void onResume() {
        super.onResume();
        binding.filesListRecyclerView.getAdapter().notifyDataSetChanged();
    }

    private void createNewDialog(boolean isFolder) {
        DialogCreateNewFileLayoutBinding dialogBinding = DialogCreateNewFileLayoutBinding.inflate(getLayoutInflater());
        var inputText = dialogBinding.inputText;

        var dialog = new MaterialAlertDialogBuilder(this)
                .setView(dialogBinding.getRoot())
                .setTitle(isFolder ? R.string.manager_create_folder : R.string.manager_create_file)
                .setMessage(Helper.getResString(R.string.create_enter_name_format, getString(isFolder ? R.string.common_word_folder : R.string.common_word_file)))
                .setNegativeButton(R.string.common_word_cancel, (dialogInterface, i) -> dialogInterface.dismiss())
                .setPositiveButton(R.string.common_word_create, null)
                .create();

        dialogBinding.chipGroupTypes.setVisibility(View.GONE);
        if (!isFolder) {
            dialogBinding.inputText.setText(".xml");
        }

        dialog.setOnShowListener(dialogInterface -> {
            Button positiveButton = ((androidx.appcompat.app.AlertDialog) dialogInterface).getButton(DialogInterface.BUTTON_POSITIVE);
            positiveButton.setOnClickListener(view -> {
                if (Helper.getText(inputText).isEmpty()) {
                    SketchwareUtil.toastError(Helper.getResString(R.string.error_invalid_name_short));
                    return;
                }

                String name = Helper.getText(inputText);
                String path;
                if (isFolder) {
                    path = fpu.getPathResource(numProj) + "/" + name;
                } else {
                    path = new File(temp + File.separator + name).getAbsolutePath();
                }

                if (FileUtil.isExistFile(path)) {
                    SketchwareUtil.toastError(Helper.getResString(R.string.error_file_exists));
                    return;
                }
                if (isFolder) {
                    FileUtil.makeDir(path);
                } else {
                    FileUtil.writeFile(path, "<?xml version=\"1.0\" encoding=\"utf-8\"?>");
                }
                handleAdapter(temp);
                SketchwareUtil.toast(Helper.getResString(R.string.toast_created_file));
                dialog.dismiss();
            });

            dialog.setView(dialogBinding.getRoot());
            dialog.show();

            dialog.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE);
            inputText.requestFocus();

            if (!isFolder) {
                inputText.setSelection(0);
            }
        });

        dialog.show();
    }

    private void setupDialog() {
        FilePickerOptions options = new FilePickerOptions();
        options.setSelectionMode(SelectionMode.BOTH);
        options.setMultipleSelection(true);
        options.setTitle(Helper.getResString(R.string.manager_resource_select_files));

        FilePickerCallback callback = new FilePickerCallback() {
            @Override
            public void onFilesSelected(@NotNull List<? extends File> files) {
                if (files.isEmpty()) {
                    SketchwareUtil.toastError(Helper.getResString(R.string.error_no_files_selected));
                    return;
                }
                for (File file : files) {
                    try {
                        FileUtil.copyDirectory(file, new File(temp + File.separator + file.getName()));
                    } catch (IOException e) {
                        SketchwareUtil.toastError(String.format(Helper.getResString(R.string.error_import_resource), e.getMessage()));
                    }
                }
                handleAdapter(temp);
                handleFab();
            }
        };

        dialog = new FilePickerDialogFragment(options, callback);
    }

    private void showRenameDialog(String path) {
        DialogInputLayoutBinding dialogBinding = DialogInputLayoutBinding.inflate(getLayoutInflater());

        var inputText = dialogBinding.inputText;

        var dialog = new MaterialAlertDialogBuilder(this)
                .setTitle(R.string.common_word_rename)
                .setView(dialogBinding.getRoot())
                .setNegativeButton(R.string.common_word_cancel, (dialogInterface, i) -> dialogInterface.dismiss())
                .setPositiveButton(R.string.common_word_rename, (dialogInterface, i) -> {
                    if (!Helper.getText(inputText).isEmpty()) {
                        if (FileUtil.renameFile(path, path.substring(0, path.lastIndexOf("/")) + "/" + Helper.getText(inputText))) {
                            SketchwareUtil.toast(Helper.getResString(R.string.toast_renamed_successfully));
                        } else {
                            SketchwareUtil.toastError(Helper.getResString(R.string.nativelib_error_rename_failed));
                        }
                        handleAdapter(temp);
                        handleFab();
                    }
                    dialogInterface.dismiss();
                })
                .create();


        try {
            inputText.setText(path.substring(path.lastIndexOf("/") + 1));
        } catch (IndexOutOfBoundsException e) {
            inputText.setText(path);
        }

        dialog.setView(dialogBinding.getRoot());
        dialog.show();

        dialog.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE);
        inputText.requestFocus();
    }

    private void showDeleteDialog(int position) {
        new MaterialAlertDialogBuilder(this)
                .setTitle(Helper.getResString(R.string.common_word_delete) + " " + new File(adapter.getItem(position)).getName() + "?")
                .setMessage(Helper.getResString(R.string.delete_confirm_format,
                        getString(FileUtil.isDirectory(adapter.getItem(position)) ? R.string.common_word_folder : R.string.common_word_file), ""))
                .setPositiveButton(R.string.common_word_delete, (dialog, which) -> {
                    FileUtil.deleteFile(frc.listFileResource.get(position));
                    handleAdapter(temp);
                    SketchwareUtil.toast(Helper.getResString(R.string.nativelib_toast_deleted));
                })
                .setNegativeButton(R.string.common_word_cancel, null)
                .create()
                .show();
    }

    private void goEdit(int position) {
        if (frc.listFileResource.get(position).endsWith("xml")) {
            Intent intent = new Intent();
            intent.setClass(getApplicationContext(), SrcCodeEditor.class);
            intent.putExtra("title", Uri.parse(frc.listFileResource.get(position)).getLastPathSegment());
            intent.putExtra("content", frc.listFileResource.get(position));
            intent.putExtra("xml", "");
            if (getIntent().hasExtra("sc_id")) {
                intent.putExtra("sc_id", getIntent().getStringExtra("sc_id"));
            }
            startActivity(intent);
        } else {
            SketchwareUtil.toast(Helper.getResString(R.string.toast_only_xml_editable));
        }
    }

    private void goEdit2(int position) {
        if (frc.listFileResource.get(position).endsWith("xml")) {
            Intent intent = new Intent();
            intent.setClass(getApplicationContext(), SrcCodeEditor.class);
            intent.putExtra("title", Uri.parse(frc.listFileResource.get(position)).getLastPathSegment());
            intent.putExtra("content", frc.listFileResource.get(position));
            intent.putExtra("xml", "");
            if (getIntent().hasExtra("sc_id")) {
                intent.putExtra("sc_id", getIntent().getStringExtra("sc_id"));
            }
            startActivity(intent);
        } else {
            SketchwareUtil.toast(Helper.getResString(R.string.toast_only_xml_editable));
        }
    }

    private class CustomAdapter extends RecyclerView.Adapter<CustomAdapter.ViewHolder> {

        private final ArrayList<String> data;

        public CustomAdapter(ArrayList<String> arrayList) {
            data = arrayList;
        }

        @NonNull
        @Override
        public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            ManageJavaItemHsBinding binding = ManageJavaItemHsBinding.inflate(LayoutInflater.from(parent.getContext()), parent, false);
            return new ViewHolder(binding);
        }

        @Override
        public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
            String path = data.get(position);
            var binding = holder.binding;

            binding.more.setVisibility(FileUtil.isDirectory(path) ? View.GONE : View.VISIBLE);
            binding.title.setText(Uri.parse(path).getLastPathSegment());

            // Clear previous load to prevent stale images when views are recycled
            Glide.with(ManageResourceActivity.this).clear(binding.icon);
            binding.icon.setImageDrawable(null);

            if (FileUtil.isDirectory(path)) {
                binding.icon.setImageResource(R.drawable.ic_mtrl_folder);
            } else {
                try {
                    if (FileUtil.isImageFile(path)) {
                        Glide.with(ManageResourceActivity.this).load(new File(path)).into(binding.icon);
                    } else if (path.endsWith(".xml") && "drawable".equals(getLastDirectory(path))) {
                        new VectorDrawableLoader().setImageVectorFromFile(binding.icon, path, numProj);
                    } else {
                        binding.icon.setImageResource(R.drawable.ic_mtrl_file);
                    }
                } catch (Exception ignored) {
                    binding.icon.setImageResource(R.drawable.ic_mtrl_file);
                }
            }

            binding.more.setOnClickListener(v -> {
                PopupMenu popupMenu = new PopupMenu(ManageResourceActivity.this, v);
                popupMenu.inflate(R.menu.popup_menu_double);
                popupMenu.getMenu().getItem(0).setVisible(false);
                popupMenu.setOnMenuItemClickListener(item -> {
                    int id = item.getItemId();
                    if (id == R.id.edit_with) {
                        if (frc.listFileResource.get(position).endsWith("xml")) {
                            try {
                                Intent intent = new Intent(Intent.ACTION_VIEW);
                                File file = new File(frc.listFileResource.get(position));
                                Uri uri = FileProvider.getUriForFile(getApplicationContext(), getPackageName() + ".provider", file);
                                intent.setDataAndType(uri, "text/plain");
                                intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                                startActivity(intent);
                            } catch (android.content.ActivityNotFoundException ignored) {
                            }
                        } else {
                            SketchwareUtil.toast(Helper.getResString(R.string.toast_only_xml_editable));
                        }
                    } else if (id == R.id.edit) {
                        goEdit2(position);
                    } else if (id == R.id.delete) {
                        showDeleteDialog(position);
                    } else if (id == R.id.rename) {
                        showRenameDialog(frc.listFileResource.get(position));
                    } else {
                        return false;
                    }
                    return true;
                });
                popupMenu.show();
            });

            binding.getRoot().setOnLongClickListener(v -> {
                if (FileUtil.isDirectory(frc.listFileResource.get(position))) {
                    PopupMenu popupMenu = new PopupMenu(ManageResourceActivity.this, binding.more);
                    popupMenu.getMenu().add(0, R.id.delete, 0, R.string.common_word_delete);
                    popupMenu.setOnMenuItemClickListener(item -> {
                        showDeleteDialog(position);
                        return true;
                    });
                    popupMenu.show();
                } else {
                    binding.more.performClick();
                }
                return true;
            });
            binding.getRoot().setOnClickListener(view -> {
                if (FileUtil.isDirectory(frc.listFileResource.get(position))) {
                    temp = frc.listFileResource.get(position);
                    handleAdapter(temp);
                    handleFab();
                    return;
                }
                goEdit(position);
            });
        }

        public String getItem(int position) {
            return data.get(position);
        }

        @Override
        public int getItemCount() {
            return data.size();
        }

        static class ViewHolder extends RecyclerView.ViewHolder {
            private final ManageJavaItemHsBinding binding;

            public ViewHolder(ManageJavaItemHsBinding binding) {
                super(binding.getRoot());
                this.binding = binding;
            }
        }
    }
}

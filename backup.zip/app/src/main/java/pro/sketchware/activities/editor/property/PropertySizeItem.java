package pro.sketchware.activities.editor.property;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.google.android.material.dialog.MaterialAlertDialogBuilder;

import pro.sketchware.util.format.FormatUtil;
import pro.sketchware.core.callback.PropertyChangedCallback;
import pro.sketchware.util.UIHelper;
import pro.sketchware.util.ViewUtil;
import pro.sketchware.util.Helper;
import pro.sketchware.R;
import pro.sketchware.core.validation.MinMaxInputValidator;

@SuppressLint("ViewConstructor")
public class PropertySizeItem extends RelativeLayout implements View.OnClickListener {

    private Context context;
    private String key = "";
    private int value = 1;
    private TextView tvName;
    private TextView tvValue;
    private ImageView imgLeftIcon;
    private int icon;
    private View propertyItem;
    private View propertyMenuItem;
    private PropertyChangedCallback valueChangeListener;

    public PropertySizeItem(Context context, boolean useAttrs) {
        super(context);
        initialize(context, useAttrs);
    }

    public String getKey() {
        return key;
    }

    public void setKey(String propertyKey) {
        key = propertyKey;
        int identifier = getResources().getIdentifier(propertyKey, "string", getContext().getPackageName());
        if (identifier > 0) {
            tvName.setText(Helper.getResString(identifier));
            icon = R.drawable.ic_mtrl_expand;
            if (propertyMenuItem.getVisibility() == VISIBLE) {
                ((ImageView) findViewById(R.id.img_icon)).setImageResource(icon);
                ((TextView) findViewById(R.id.tv_title)).setText(Helper.getResString(identifier));
            } else {
                imgLeftIcon.setImageResource(icon);
            }
        }
    }

    public int getValue() {
        return value;
    }

    public void setValue(int value) {
        this.value = value;
        TextView textView = tvValue;
        textView.setText(this.value + " dp");
    }

    @Override
    public void onClick(View v) {
        if (!UIHelper.isClickThrottled()) {
            if (key.equals("property_divider_height")) {
                showDialog();
            }
        }
    }

    public void setOnPropertyValueChangeListener(PropertyChangedCallback onPropertyValueChangeListener) {
        valueChangeListener = onPropertyValueChangeListener;
    }

    public void setOrientationItem(int orientationItem) {
        if (orientationItem == 0) {
            propertyItem.setVisibility(GONE);
            propertyMenuItem.setVisibility(VISIBLE);
            propertyItem.setOnClickListener(null);
            propertyMenuItem.setOnClickListener(this);
        } else {
            propertyItem.setVisibility(VISIBLE);
            propertyMenuItem.setVisibility(GONE);
            propertyItem.setOnClickListener(this);
            propertyMenuItem.setOnClickListener(null);
        }
    }

    private void initialize(Context context, boolean useAttrs) {
        this.context = context;
        ViewUtil.inflateLayoutInto(context, this, R.layout.property_input_item);
        tvName = findViewById(R.id.tv_name);
        tvValue = findViewById(R.id.tv_value);
        imgLeftIcon = findViewById(R.id.img_left_icon);
        propertyItem = findViewById(R.id.property_item);
        propertyMenuItem = findViewById(R.id.property_menu_item);
//        if (z) {
//            propertyMenuItem.setSoundEffectsEnabled(true);
//            propertyMenuItem.setOnClickListener(this);
//        }
    }

    private void showDialog() {
        MaterialAlertDialogBuilder dialog = new MaterialAlertDialogBuilder(getContext());
        dialog.setTitle(Helper.getText(tvName));
        dialog.setIcon(icon);
        View view = ViewUtil.inflateLayout(getContext(), R.layout.property_popup_input_size);
        EditText input = view.findViewById(R.id.et_input);
        MinMaxInputValidator validator = new MinMaxInputValidator(context, view.findViewById(R.id.ti_input), 0, 999);
        validator.setText(String.valueOf(value));
        dialog.setView(view);
        dialog.setPositiveButton(Helper.getResString(R.string.common_word_save), (v, which) -> {
            if (validator.isValid()) {
                setValue(FormatUtil.safeParseInt(Helper.getText(input), value));
                if (valueChangeListener != null) {
                    valueChangeListener.onPropertyChanged(key, value);
                }
                v.dismiss();
            }
        });
        dialog.setNegativeButton(Helper.getResString(R.string.common_word_cancel), null);
        dialog.show();
    }
}

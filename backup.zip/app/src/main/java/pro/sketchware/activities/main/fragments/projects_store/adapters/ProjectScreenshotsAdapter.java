package pro.sketchware.activities.main.fragments.projects_store.adapters;

import static pro.sketchware.util.UI.loadImageFromUrl;

import android.view.LayoutInflater;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

import pro.sketchware.databinding.ViewStoreProjectScreenshotBinding;

public class ProjectScreenshotsAdapter extends RecyclerView.Adapter<ProjectScreenshotsAdapter.ViewHolder> {

    public interface OnScreenshotClickListener {
        void onScreenshotClick(int position);
    }

    private final List<String> screenshots;
    private final OnScreenshotClickListener listener;

    public ProjectScreenshotsAdapter(List<String> screenshots, OnScreenshotClickListener listener) {
        this.screenshots = screenshots;
        this.listener = listener;
    }

    @NonNull
    @Override
    public ProjectScreenshotsAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        ViewStoreProjectScreenshotBinding binding = ViewStoreProjectScreenshotBinding.inflate(inflater, parent, false);
        return new ProjectScreenshotsAdapter.ViewHolder(binding);
    }

    @Override
    public void onBindViewHolder(ProjectScreenshotsAdapter.ViewHolder holder, int position) {
        String screenshot = screenshots.get(position);
        loadImageFromUrl(holder.binding.screenshot, screenshot);
        holder.binding.getRoot().setOnClickListener(v -> {
            int adapterPosition = holder.getBindingAdapterPosition();
            if (listener != null && adapterPosition != RecyclerView.NO_POSITION) {
                listener.onScreenshotClick(adapterPosition);
            }
        });
    }

    @Override
    public int getItemCount() {
        if (screenshots == null) {
            return 0;
        }
        return screenshots.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        private final ViewStoreProjectScreenshotBinding binding;

        public ViewHolder(ViewStoreProjectScreenshotBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
        }
    }

}

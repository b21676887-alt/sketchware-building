package pro.sketchware.activities.design;

import android.content.Context;

import pro.sketchware.beans.BlockBean;
import pro.sketchware.beans.ProjectFileBean;
import com.google.gson.Gson;
import com.google.gson.JsonSyntaxException;
import com.google.gson.reflect.TypeToken;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;

import pro.sketchware.core.project.ProjectDataStore;
import pro.sketchware.core.project.ProjectFileManager;
import pro.sketchware.core.project.ProjectDataManager;
import pro.sketchware.core.codegen.BlockColorMapper;
import pro.sketchware.core.project.SketchwarePaths;
import pro.sketchware.core.codegen.ExtraBlockFile;
import pro.sketchware.core.codegen.ExtraBlockInfo;
import pro.sketchware.core.codegen.BlockLoader;
import pro.sketchware.util.Helper;
import pro.sketchware.util.LogUtil;
import pro.sketchware.R;
import pro.sketchware.util.FileUtil;
import pro.sketchware.util.SketchwareUtil;

public class CustomBlocksManager {
    private final Context context;
    final String sc_id;
    ArrayList<BlockBean> blocks;
    ArrayList<ExtraBlockInfo> custom_blocks;

    public CustomBlocksManager(Context context, String sc_id) {
        this.context = context;
        this.sc_id = sc_id;

        load();
    }

    public ArrayList<BlockBean> getUsedBlocks() {
        ArrayList<BlockBean> filteredCustomBlocks = new ArrayList<>();
        for (BlockBean bean : blocks) {
            if (!isBuildInBlock(bean.opCode)) {
                filteredCustomBlocks.add(bean);
            }
        }
        return filteredCustomBlocks;
    }

    private boolean isBuildInBlock(String blockName) {
        if (ExtraBlockFile.buildInBlocks.isEmpty()) {
            BlockLoader.refresh();
        }
        for (HashMap<String, Object> block : ExtraBlockFile.buildInBlocks) {
            if (blockName.equals(String.valueOf(block.get("name")))) {
                return true;
            }
        }
        return false;
    }

    public ExtraBlockInfo getExtraBlockInfo(String name) {
        return getExtraBlockInfoByName(name).orElse(null);
    }

    public boolean contains(String name) {
        return getExtraBlockInfoByName(name).isPresent();
    }

    private Optional<ExtraBlockInfo> getExtraBlockInfoByName(String name) {
        if (custom_blocks != null && !custom_blocks.isEmpty()) {
            for (ExtraBlockInfo info : custom_blocks) {
                if (info.getName().equals(name)) {
                    return Optional.of(info);
                }
            }
        }
        return Optional.empty();
    }

    private void load() {
        blocks = new ArrayList<>();

        ArrayList<String> usedBlocks = new ArrayList<>();

        ProjectFileManager hc = ProjectDataManager.getFileManager(sc_id);
        ProjectDataStore ec = ProjectDataManager.getProjectDataManager(sc_id);

        for (ProjectFileBean bean : hc.getActivities()) {
            for (Map.Entry<String, ArrayList<BlockBean>> entry : ec.getBlockMap(bean.getJavaName()).entrySet()) {
                for (BlockBean block : entry.getValue()) {
                    if (!(block.opCode.equals("definedFunc")
                            || block.opCode.equals("getVar")
                            || block.opCode.equals("getArg"))) {
                        if (BlockColorMapper.getBlockColor(context, block.opCode, block.type) == 0xff8a55d7) {
                            if (!usedBlocks.contains(block.opCode)) {
                                usedBlocks.add(block.opCode);

                                blocks.add(block);
                            }
                        }
                    }
                }
            }
        }

        File customBlocksConfig = new File(SketchwarePaths.getProjectCustomBlocksPath(sc_id));
        if (customBlocksConfig.exists()) {
            try {
                custom_blocks = new Gson().fromJson(
                        FileUtil.readFile(customBlocksConfig.getAbsolutePath()),
                        new TypeToken<ArrayList<ExtraBlockInfo>>() {
                        }.getType());
            } catch (JsonSyntaxException e) {
                SketchwareUtil.toastError(String.format(Helper.getResString(R.string.error_get_custom_blocks), e.getMessage()));
            }
        }

    }

    public String getCustomBlockCode(String opCode) {
        try {
            for (ExtraBlockInfo info : custom_blocks) {
                if (info.getName().equals(opCode)) {
                    return info.getCode();
                }
            }
        } catch (NullPointerException e) {
            LogUtil.e("CustomBlocksManager", "Failed to get code for custom block: " + opCode, e);
        }
        return "";
    }

    public String getCustomBlockSpec2(String opCode) {
        try {
            for (ExtraBlockInfo info : custom_blocks) {
                if (info.getName().equals(opCode)) {
                    return info.getSpec2();
                }
            }
        } catch (NullPointerException e) {
            LogUtil.e("CustomBlocksManager", "Failed to get spec2 for custom block: " + opCode, e);
        }
        return "";
    }
}

package pro.sketchware.activities.editor.manifest;

import static pro.sketchware.util.GsonUtils.getGson;
import static pro.sketchware.util.SketchwareUtil.dpToPx;

import com.google.gson.JsonSyntaxException;
import androidx.appcompat.app.AlertDialog;
import pro.sketchware.util.SketchwareUtil;
import android.content.Intent;
import android.os.Bundle;
import android.text.SpannableString;
import android.text.style.ForegroundColorSpan;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.LinearLayout;
import android.widget.TextView;

import pro.sketchware.activities.base.BaseAppCompatActivity;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;

import java.util.ArrayList;
import java.util.HashMap;

import pro.sketchware.activities.editor.code.SrcCodeEditor;
import pro.sketchware.util.Helper;
import pro.sketchware.widgets.CustomAttributeView;
import pro.sketchware.R;
import pro.sketchware.core.project.SketchwarePaths;
import pro.sketchware.databinding.ActivityManageCustomAttributeBinding;
import pro.sketchware.databinding.CustomDialogAttributeBinding;
import pro.sketchware.databinding.DialogCreateNewFileLayoutBinding;
import pro.sketchware.util.FileUtil;
import pro.sketchware.util.ThemeUtils;

public class AndroidManifestInjectionDetails extends BaseAppCompatActivity {

    private String attributesFilePath;
    private final ArrayList<HashMap<String, Object>> listMap = new ArrayList<>();
    private String src_id;
    private String activityName;
    private String type;
    private String constant;

    private ActivityManageCustomAttributeBinding binding;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityManageCustomAttributeBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        if (getIntent().hasExtra("sc_id") && getIntent().hasExtra("file_name") && getIntent().hasExtra("type")) {
            src_id = getIntent().getStringExtra("sc_id");
            activityName = getIntent().getStringExtra("file_name").replace(".java", "");
            type = getIntent().getStringExtra("type");
        } else {
            finish();
            return;
        }
        attributesFilePath = SketchwarePaths.getAndroidManifestAttributesPath(src_id);
        setupConst();
        setToolbar();
        setupViews();
    }

    private void setupConst() {
        switch (type) {
            case "all":
                constant = "_apply_for_all_activities";
                break;

            case "application":
                constant = "_application_attrs";
                break;

            case "permission":
                constant = "_application_permissions";
                break;

            default:
                constant = activityName;
                break;
        }
    }

    private void setupViews() {
        binding.addAttrFab.setContentDescription(getString(type.equals("permission")
                ? R.string.manifest_add_permission : R.string.manifest_add_attribute));
        binding.addAttrFab.setOnClickListener(v -> showAddDial());
        refreshList();
    }

    private void refreshList() {
        listMap.clear();
        ArrayList<HashMap<String, Object>> data;
        if (FileUtil.isExistFile(attributesFilePath)) {
            try {
                data = getGson().fromJson(FileUtil.readFile(attributesFilePath), Helper.TYPE_MAP_LIST);
            } catch (JsonSyntaxException e) {
                return;
            }
            if (data == null) {
                return;
            }
            for (HashMap<String, Object> item : data) {
                if (item == null) continue;
                Object itemName = item.get("name");
                if (itemName != null && constant.equals(itemName.toString())) {
                    listMap.add(item);
                }
            }
            binding.addAttrListview.setAdapter(new ListAdapter(listMap));
            ((BaseAdapter) binding.addAttrListview.getAdapter()).notifyDataSetChanged();
        }
    }

    private void setToolbar() {
        String title = switch (type) {
            case "all" -> Helper.getResString(R.string.manifest_attrs_all_activities);
            case "application" -> Helper.getResString(R.string.manifest_attrs_application);
            case "permission" -> Helper.getResString(R.string.manifest_attrs_permissions);
            default -> activityName;
        };
        binding.toolbar.setTitle(title);

        binding.toolbar.setNavigationOnClickListener(Helper.getBackPressedClickListener(this));

        if (!type.equals("all") && !type.equals("application") && !type.equals("permission")) {
            binding.toolbar.setOnMenuItemClickListener(item -> {
                if (item.getItemId() == R.id.asd_components) {
                    Intent intent = new Intent(this, SrcCodeEditor.class);
                    intent.putExtra(SrcCodeEditor.FLAG_FROM_ANDROID_MANIFEST, true);
                    intent.putExtra("title", String.format(Helper.getResString(R.string.manifest_components_title_format), activityName));
                    intent.putExtra("sc_id", src_id);
                    intent.putExtra("activity_name", activityName);
                    startActivity(intent);
                    return true;
                }
                return false;
            });
        } else {
            binding.toolbar.getMenu().clear();
        }
    }

    private void showDial(int pos) {
        DialogCreateNewFileLayoutBinding input = DialogCreateNewFileLayoutBinding.inflate(getLayoutInflater());
        input.chipGroupTypes.setVisibility(View.GONE);
        Object value = listMap.get(pos).get("value");
        input.inputText.setText(value != null ? value.toString() : "");
        input.inputText.setHint(R.string.manifest_hint_attr_value);
        AlertDialog dialog = new MaterialAlertDialogBuilder(this)
                .setTitle(R.string.manifest_edit_value).setView(input.getRoot())
                .setPositiveButton(R.string.common_word_save, null).create();
        dialog.setOnShowListener(ignored -> dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            String updatedValue = Helper.getText(input.inputText);
            if (updatedValue.trim().isEmpty()) {
                input.inputText.setError(getString(R.string.manifest_required));
                return;
            }
            ArrayList<HashMap<String, Object>> updated = new ArrayList<>(listMap);
            HashMap<String, Object> entry = new HashMap<>(updated.get(pos));
            entry.put("value", updatedValue);
            updated.set(pos, entry);
            if (applyChange(updated)) dialog.dismiss();
        }));
        dialog.show();
    }

    private void showAddDial() {
        CustomDialogAttributeBinding input = CustomDialogAttributeBinding.inflate(getLayoutInflater());
        if (type.equals("permission")) {
            input.inputRes.setText("android");
            input.inputAttr.setText("name");
            input.inputLayoutValue.setHint(R.string.manifest_hint_permission);
        }
        AlertDialog dialog = new MaterialAlertDialogBuilder(this)
                .setTitle(type.equals("permission") ? R.string.manifest_add_permission : R.string.manifest_add_attribute)
                .setView(input.getRoot()).setPositiveButton(R.string.common_word_save, null)
                .setNegativeButton(R.string.common_word_cancel, null).create();
        dialog.setOnShowListener(ignored -> dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v -> {
            String namespace = Helper.getText(input.inputRes).trim();
            String attribute = Helper.getText(input.inputAttr).trim();
            String value = Helper.getText(input.inputValue).trim();
            if (namespace.isEmpty()) {
                input.inputRes.setError(getString(R.string.manifest_required));
                return;
            }
            if (attribute.isEmpty()) {
                input.inputAttr.setError(getString(R.string.manifest_required));
                return;
            }
            if (type.equals("permission") && value.isEmpty()) {
                input.inputValue.setError(getString(R.string.manifest_required));
                return;
            }
            HashMap<String, Object> entry = new HashMap<>();
            entry.put("name", constant);
            entry.put("value", namespace + ":" + attribute + "=\"" + value + "\"");
            ArrayList<HashMap<String, Object>> updated = new ArrayList<>(listMap);
            updated.add(entry);
            if (applyChange(updated)) dialog.dismiss();
        }));
        dialog.show();
    }

    private boolean applyChange(ArrayList<HashMap<String, Object>> updated) {
        ArrayList<HashMap<String, Object>> data = new ArrayList<>();
        if (FileUtil.isExistFile(attributesFilePath)) {
            try {
                data = getGson().fromJson(FileUtil.readFile(attributesFilePath), Helper.TYPE_MAP_LIST);
            } catch (JsonSyntaxException e) {
                SketchwareUtil.toastError(getString(R.string.manifest_attributes_read_error));
                return false;
            }
            if (data == null) {
                SketchwareUtil.toastError(getString(R.string.manifest_attributes_read_error));
                return false;
            }
            data.removeIf(item -> item != null && constant.equals(item.get("name")));
        }
        data.addAll(updated);
        FileUtil.writeFile(attributesFilePath, getGson().toJson(data));
        refreshList();
        return true;
    }

    private TextView newText(String text, float size, int color, int width, int height, float weight) {
        TextView temp_card = new TextView(this);
        temp_card.setLayoutParams(new LinearLayout.LayoutParams(width, height, weight));
        temp_card.setPadding(dpToPx(4), dpToPx(4), dpToPx(4), dpToPx(4));
        temp_card.setTextColor(color);
        temp_card.setText(text);
        temp_card.setTextSize(size);
        return temp_card;
    }

    private class ListAdapter extends BaseAdapter {
        private final ArrayList<HashMap<String, Object>> _data;

        public ListAdapter(ArrayList<HashMap<String, Object>> _arr) {
            _data = _arr;
        }

        @Override
        public int getCount() {
            return _data.size();
        }

        @Override
        public HashMap<String, Object> getItem(int position) {
            return _data.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            CustomAttributeView attributeView = new CustomAttributeView(parent.getContext());

            try {
                int violet = ThemeUtils.getColor(attributeView, R.attr.colorViolet);
                int onSurface = ThemeUtils.getColor(attributeView, R.attr.colorOnSurface);
                int green = ThemeUtils.getColor(attributeView, R.attr.colorGreen);
                Object valueObj = _data.get(position).get("value");
                String value = valueObj != null ? valueObj.toString() : "";

                SpannableString spannableString = new SpannableString(value);
                spannableString.setSpan(new ForegroundColorSpan(violet), 0, value.indexOf(":"), 33);
                spannableString.setSpan(new ForegroundColorSpan(onSurface), value.indexOf(":"), value.indexOf("=") + 1, 33);
                spannableString.setSpan(new ForegroundColorSpan(green), value.indexOf("\""), value.length(), 33);
                attributeView.getTextView().setText(spannableString);
            } catch (Exception e) {
                Object fallbackValue = _data.get(position).get("value");
                attributeView.getTextView().setText(fallbackValue != null ? fallbackValue.toString() : "");
            }

            attributeView.getImageView().setVisibility(View.GONE);
            attributeView.setOnClickListener(v -> showDial(position));
            attributeView.setOnLongClickListener(v -> {
                new MaterialAlertDialogBuilder(AndroidManifestInjectionDetails.this)
                        .setTitle(R.string.manifest_delete_attr_title)
                        .setMessage(R.string.manifest_delete_attr_msg)
                        .setPositiveButton(R.string.common_word_delete, (dialog, which) -> {
                            ArrayList<HashMap<String, Object>> updated = new ArrayList<>(listMap);
                            updated.remove(position);
                            applyChange(updated);
                        })
                        .setNegativeButton(R.string.common_word_cancel, null)
                        .show();

                return true;
            });

            return attributeView;
        }
    }
}
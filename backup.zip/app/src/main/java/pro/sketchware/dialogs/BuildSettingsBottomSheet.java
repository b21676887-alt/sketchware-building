package pro.sketchware.dialogs;

import static pro.sketchware.core.build.BuildSettings.SETTING_ANDROID_JAR_PATH;
import static pro.sketchware.core.build.BuildSettings.SETTING_CLASSPATH;
import static pro.sketchware.core.build.BuildSettings.SETTING_DEXER;
import static pro.sketchware.core.build.BuildSettings.SETTING_ENABLE_LOGCAT;
import static pro.sketchware.core.build.BuildSettings.SETTING_JAVA_VERSION;
import static pro.sketchware.core.build.BuildSettings.SETTING_JAVA_VERSION_10;
import static pro.sketchware.core.build.BuildSettings.SETTING_JAVA_VERSION_11;
import static pro.sketchware.core.build.BuildSettings.SETTING_JAVA_VERSION_1_7;
import static pro.sketchware.core.build.BuildSettings.SETTING_JAVA_VERSION_1_8;
import static pro.sketchware.core.build.BuildSettings.SETTING_JAVA_VERSION_1_9;
import static pro.sketchware.core.build.BuildSettings.SETTING_JAVA_VERSION_12;
import static pro.sketchware.core.build.BuildSettings.SETTING_JAVA_VERSION_13;
import static pro.sketchware.core.build.BuildSettings.SETTING_JAVA_VERSION_14;
import static pro.sketchware.core.build.BuildSettings.SETTING_JAVA_VERSION_15;
import static pro.sketchware.core.build.BuildSettings.SETTING_JAVA_VERSION_16;
import static pro.sketchware.core.build.BuildSettings.SETTING_JAVA_VERSION_17;
import static pro.sketchware.core.build.BuildSettings.SETTING_NO_HTTP_LEGACY;
import static pro.sketchware.core.build.BuildSettings.SETTING_NO_WARNINGS;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CompoundButton;
import android.widget.RadioButton;
import android.widget.RadioGroup;

import androidx.annotation.NonNull;

import pro.sketchware.util.Helper;
import pro.sketchware.R;

import com.google.android.material.bottomsheet.BottomSheetDialogFragment;

import pro.sketchware.core.build.BuildSettings;
import pro.sketchware.databinding.ProjectConfigLayoutBinding;
import pro.sketchware.util.SketchwareUtil;

public class BuildSettingsBottomSheet extends BottomSheetDialogFragment {
    public static final String TAG = BuildSettingsBottomSheet.class.getSimpleName();
    private static int totalViews = 0;

    private static final int VIEW_ANDROIR_JAR_PATH = totalViews++;
    private static final int VIEW_CLASS_PATH = totalViews++;
    private static final int VIEW_DEXER = totalViews++;
    private static final int VIEW_JAVA_VERSION = totalViews++;
    private static final int VIEW_NO_WARNINGS = totalViews++;
    private static final int VIEW_NO_HTTP_LEGACY = totalViews++;
    private static final int VIEW_ENABLE_LOGCAT = totalViews++;
    private View[] views;

    private ProjectConfigLayoutBinding binding;
    private BuildSettings projectSettings;

    public static BuildSettingsBottomSheet newInstance(String sc_id) {
        BuildSettingsBottomSheet sheet = new BuildSettingsBottomSheet();
        Bundle arguments = new Bundle();
        arguments.putString("sc_id", sc_id);
        sheet.setArguments(arguments);
        return sheet;
    }

    public static String[] getAvailableJavaVersions() {
        return new String[]{SETTING_JAVA_VERSION_1_7, SETTING_JAVA_VERSION_1_8, SETTING_JAVA_VERSION_1_9, SETTING_JAVA_VERSION_10, SETTING_JAVA_VERSION_11, SETTING_JAVA_VERSION_12, SETTING_JAVA_VERSION_13, SETTING_JAVA_VERSION_14, SETTING_JAVA_VERSION_15, SETTING_JAVA_VERSION_16,SETTING_JAVA_VERSION_17,};
    }

    
    public static void handleJavaVersionChange(String choice) {
    	if (choice.equals(SETTING_JAVA_VERSION_1_7)) {
    		SketchwareUtil.toast(Helper.getResString(R.string.toast_enable_java1_7_reminder));
    	}
    	else if (choice.equals(SETTING_JAVA_VERSION_1_8)) {
    		SketchwareUtil.toast(Helper.getResString(R.string.toast_enable_d8_reminder));
    	}
    	else if (choice.equals(SETTING_JAVA_VERSION_1_9) || choice.equals(SETTING_JAVA_VERSION_10) || choice.equals(SETTING_JAVA_VERSION_11) || choice.equals(SETTING_JAVA_VERSION_12) || choice.equals(SETTING_JAVA_VERSION_13) || choice.equals(SETTING_JAVA_VERSION_14) || choice.equals(SETTING_JAVA_VERSION_15) || choice.equals(SETTING_JAVA_VERSION_16) || choice.equals(SETTING_JAVA_VERSION_17)) {
    		for (int i = 0; i < binding.rgDexer.getChildCount(); i++) {
    			RadioButton rb = (RadioButton) binding.rgDexer.getChildAt(i);
    			if (rb.getText().toString().equals("D8")) {
    				rb.setChecked(true);
    				break;
    			}
    		}
    		SketchwareUtil.toastError(String.format(Helper.getResString(R.string.toast_dx_dose_notsupport_java), choice()));
    	}
    }


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        Bundle arguments = getArguments();
        if (arguments == null) {
            dismissAllowingStateLoss();
            return;
        }
        String scId = arguments.getString("sc_id");
        if (scId == null) {
            dismissAllowingStateLoss();
            return;
        }
        projectSettings = new BuildSettings(scId);
        views = new View[totalViews];
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        binding = ProjectConfigLayoutBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        if (projectSettings == null || views == null) {
            dismissAllowingStateLoss();
            return;
        }

        initializeViews();

        binding.noWarnings.setOnClickListener(v -> binding.cbNoWarnings.performClick());
        binding.noHttpLegacy.setOnClickListener(v -> binding.cbNoHttpLegacy.performClick());
        binding.enableLogcat.setOnClickListener(v -> binding.cbEnableLogcat.performClick());

        binding.tilAndroidJar.getEditText().setText(projectSettings.getValue(SETTING_ANDROID_JAR_PATH, ""));
        binding.tilClasspath.getEditText().setText(projectSettings.getValue(SETTING_CLASSPATH, ""));

        setRadioGroupOptions(binding.rgDexer, new String[]{"Dx", "D8"}, SETTING_DEXER, "Dx");
        setRadioGroupOptions(binding.rgJavaVersion, getAvailableJavaVersions(), SETTING_JAVA_VERSION, "1.7");

        setCheckboxValue(binding.cbNoWarnings, SETTING_NO_WARNINGS, true);
        setCheckboxValue(binding.cbNoHttpLegacy, SETTING_NO_HTTP_LEGACY, false);
        setCheckboxValue(binding.cbEnableLogcat, SETTING_ENABLE_LOGCAT, true);

        binding.btnCancel.setOnClickListener(v -> dismiss());
        binding.btnSave.setOnClickListener(v -> {
            projectSettings.setValues(views);
            dismiss();
        });
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

    private void initializeViews() {
        binding.tilAndroidJar.getEditText().setTag(SETTING_ANDROID_JAR_PATH);
        binding.tilClasspath.getEditText().setTag(SETTING_CLASSPATH);
        binding.rgDexer.setTag(SETTING_DEXER);
        binding.rgJavaVersion.setTag(SETTING_JAVA_VERSION);
        binding.cbNoWarnings.setTag(SETTING_NO_WARNINGS);
        binding.cbNoHttpLegacy.setTag(SETTING_NO_HTTP_LEGACY);
        binding.cbEnableLogcat.setTag(SETTING_ENABLE_LOGCAT);

        views[VIEW_ANDROIR_JAR_PATH] = binding.tilAndroidJar.getEditText();
        views[VIEW_CLASS_PATH] = binding.tilClasspath.getEditText();
        views[VIEW_DEXER] = binding.rgDexer;
        views[VIEW_ENABLE_LOGCAT] = binding.cbEnableLogcat;
        views[VIEW_JAVA_VERSION] = binding.rgJavaVersion;
        views[VIEW_NO_HTTP_LEGACY] = binding.cbNoHttpLegacy;
        views[VIEW_NO_WARNINGS] = binding.cbNoWarnings;
    }

    
    private void setRadioGroupOptions(RadioGroup radioGroup, String[] options, String key, String defaultValue) {
        radioGroup.removeAllViews();
        String value = projectSettings.getValue(key, defaultValue);
        for (String option : options) {
            RadioButton radioButton = new RadioButton(radioGroup.getContext());
            radioButton.setText(option);
            radioButton.setId(View.generateViewId());
            radioButton.setPadding(SketchwareUtil.dpToPx(8), SketchwareUtil.dpToPx(8), SketchwareUtil.dpToPx(8), SketchwareUtil.dpToPx(8));
            RadioGroup.LayoutParams params =
        new RadioGroup.LayoutParams(
                RadioGroup.LayoutParams.WRAP_CONTENT,
                RadioGroup.LayoutParams.WRAP_CONTENT);

radioButton.setLayoutParams(params);
            if (value.equals(option)) {
                radioButton.setChecked(true);
            }
            radioButton.setOnCheckedChangeListener((buttonView, isChecked) -> {
                if (!isChecked) return;
                if (key.equals(SETTING_JAVA_VERSION)) {
                    handleJavaVersionChange(option);
                } else if (key.equals(SETTING_DEXER)) {
                    String activeJava = projectSettings.getValue(SETTING_JAVA_VERSION, "1.8");
                    
                    boolean isJavaVersionAbove18 =
                        activeJava.equals(SETTING_JAVA_VERSION_1_9)
                                || activeJava.equals(SETTING_JAVA_VERSION_10)
                                || activeJava.equals(SETTING_JAVA_VERSION_11)
                                || activeJava.equals(SETTING_JAVA_VERSION_12)
                                || activeJava.equals(SETTING_JAVA_VERSION_13)
                                || activeJava.equals(SETTING_JAVA_VERSION_14)
                                || activeJava.equals(SETTING_JAVA_VERSION_15)
                                || activeJava.equals(SETTING_JAVA_VERSION_16)
                                || activeJava.equals(SETTING_JAVA_VERSION_17);
                    
                    if (option.equals("Dx") && isJavaVersionAbove18) {
                        SketchwareUtil.toastError(String.format(Helper.getResString(R.string.toast_dxcannot_used_with_java), activeJava()));
                        radioButton.setChecked(false);
                        for (int i = 0; i < radioGroup.getChildCount(); i++) {
                            RadioButton rb = (RadioButton) radioGroup.getChildAt(i);
                            if (rb.getText().toString().equals("D8")) rb.setChecked(true);
                        }
                    }
                }
            });
            radioGroup.addView(radioButton);
        }
    }

    private void setCheckboxValue(CompoundButton checkBox, String key, boolean defaultValue) {
        String value = projectSettings.getValue(key, defaultValue ? "true" : "false");
        checkBox.setChecked(value.equals("true"));

        checkBox.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (isChecked) {
                if (key.equals(SETTING_NO_HTTP_LEGACY)) {
                    SketchwareUtil.toast(Helper.getResString(R.string.toast_no_http_legacy_warning));
                }
            }
        });
    }
}

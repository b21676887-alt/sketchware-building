package pro.sketchware.util.library;

import static pro.sketchware.SketchApplication.getContext;

import android.content.Context;

import androidx.annotation.StyleRes;

import pro.sketchware.beans.ProjectLibraryBean;

import pro.sketchware.core.project.ProjectDataManager;
import pro.sketchware.R;
import pro.sketchware.util.ThemeUtils;

public class Material3LibraryManager {

    private final boolean isEditingState;
    private final boolean isAppCompatEnabled;
    private final ProjectLibraryBean appCombatLibraryBean;
    private final Context context;

    public Material3LibraryManager(String sc_id) {
        isEditingState = false;
        appCombatLibraryBean = ProjectDataManager.getLibraryManager(sc_id).getCompat();
        isAppCompatEnabled = appCombatLibraryBean.isEnabled();
        context = getContext();
    }

    public Material3LibraryManager(Context context, String sc_id) {
        this.context = context;
        isEditingState = false;
        appCombatLibraryBean = ProjectDataManager.getLibraryManager(sc_id).getCompat();
        isAppCompatEnabled = appCombatLibraryBean.isEnabled();
    }

    public Material3LibraryManager(ProjectLibraryBean projectLibraryBean) {
        context = getContext();
        isEditingState = true;
        appCombatLibraryBean = projectLibraryBean;
        isAppCompatEnabled = projectLibraryBean.isEnabled();
    }

    public boolean isAppCompatEnabled() {
        return isAppCompatEnabled;
    }

    public boolean isMaterial3Enabled() {
        return isAppCompatEnabled && safeGetBoolean("material3");
    }

    public boolean isDynamicColorsEnabled() {
        return (isMaterial3Enabled() || isEditingState) && safeGetBoolean("dynamic_colors");
    }

    public String getTheme() {
        return isMaterial3Enabled() || isEditingState ? safeGetString("theme") : "DayNight";
    }

    private String safeGetString(String key) {
        if (appCombatLibraryBean.configurations != null &&
                appCombatLibraryBean.configurations.containsKey(key) &&
                appCombatLibraryBean.configurations.get(key) instanceof String keyValue) {
            return keyValue;
        }
        return "";
    }

    private boolean safeGetBoolean(String key) {
        if (appCombatLibraryBean.configurations != null &&
                appCombatLibraryBean.configurations.containsKey(key) &&
                appCombatLibraryBean.configurations.get(key) instanceof Boolean keyValue) {
            return keyValue;
        }
        return false;
    }

    @StyleRes
    public int getViewEditorThemeOverlay() {
        if (!isMaterial3Enabled()) {
            return R.style.ThemeOverlay_SketchwarePro_ViewEditor;
        }
        boolean isDark = canUseNightVariantColors();

        if (isDynamicColorsEnabled()) {
            return isDark
                    ? R.style.ThemeOverlay_SketchwarePro_ViewEditor_Material3_Dark
                    : R.style.ThemeOverlay_SketchwarePro_ViewEditor_Material3_Light;
        } else {
            return isDark
                    ? R.style.ThemeOverlay_SketchwarePro_ViewEditor_Material3_NON_DYNAMIC_Dark
                    : R.style.ThemeOverlay_SketchwarePro_ViewEditor_Material3_NON_DYNAMIC_Light;
        }
    }

    public boolean canUseNightVariantColors() {
        if (!isMaterial3Enabled()) {
            return false;
        }

        return getTheme().equals("Dark") ||
                !getTheme().equals("Light") && ThemeUtils.isDarkThemeEnabled(context);
    }

    public ProjectLibraryBean getAppCombatLibraryBean() {
        return appCombatLibraryBean;
    }

}